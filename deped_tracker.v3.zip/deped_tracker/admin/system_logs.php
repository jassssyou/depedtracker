<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator'])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/
$search = trim($_GET['search'] ?? '');
$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');

$where = [];
$where[] = "1=1";

if ($search !== '') {
    $search_escaped = mysqli_real_escape_string($conn, $search);
    $where[] = "(u.fullname LIKE '%$search_escaped%' OR sl.activity LIKE '%$search_escaped%')";
}

if ($date_from !== '') {
    $where[] = "DATE(sl.log_time) >= '$date_from'";
}

if ($date_to !== '') {
    $where[] = "DATE(sl.log_time) <= '$date_to'";
}

$where_sql = implode(' AND ', $where);

/*
|--------------------------------------------------------------------------
| Fetch logs
|--------------------------------------------------------------------------
*/
$logs = mysqli_query($conn, "
    SELECT 
        sl.*,
        u.fullname
    FROM system_logs sl
    LEFT JOIN users u ON sl.user_id = u.user_id
    WHERE $where_sql
    ORDER BY sl.log_time DESC
");

/*
|--------------------------------------------------------------------------
| Summary
|--------------------------------------------------------------------------
*/
$total_logs = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM system_logs"))['total'] ?? 0;
$today_logs = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM system_logs WHERE DATE(log_time)=CURDATE()"))['total'] ?? 0;
?>

<div class="main-content">

    <style>
        .logs-hero {
            background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 55%, #3b82f6 100%);
            color: #ffffff;
            border-radius: 18px;
            padding: 24px 26px;
            box-shadow: 0 16px 30px rgba(29, 78, 216, 0.18);
            margin-bottom: 24px;
        }

        .logs-hero h2 {
            margin: 0 0 8px 0;
            font-size: 32px;
        }

        .logs-hero p {
            margin: 0;
            color: rgba(255,255,255,0.92);
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 18px;
            margin-bottom: 24px;
        }

        .summary-card {
            background: #ffffff;
            border-radius: 14px;
            padding: 18px;
            box-shadow: 0 6px 18px rgba(0,0,0,0.06);
        }

        .summary-label {
            font-size: 13px;
            color: #64748b;
        }

        .summary-value {
            font-size: 30px;
            font-weight: bold;
            color: #0f172a;
        }
    </style>

    <div class="logs-hero">
        <h2>System Logs</h2>
        <p>Monitor all system activities and user actions.</p>
    </div>

    <div class="summary-grid">
        <div class="summary-card">
            <div class="summary-label">Total Logs</div>
            <div class="summary-value"><?php echo $total_logs; ?></div>
        </div>

        <div class="summary-card">
            <div class="summary-label">Today</div>
            <div class="summary-value"><?php echo $today_logs; ?></div>
        </div>
    </div>

    <!-- FILTER -->
    <div class="page-card" style="margin-bottom:20px;">
        <form method="GET" style="display:grid; grid-template-columns:2fr 1fr 1fr 150px; gap:10px;">
            <input type="text" name="search" class="form-control"
                placeholder="Search user or activity"
                value="<?php echo e($search); ?>">

            <input type="date" name="date_from" class="form-control"
                value="<?php echo e($date_from); ?>">

            <input type="date" name="date_to" class="form-control"
                value="<?php echo e($date_to); ?>">

            <button class="btn btn-primary">Filter</button>
        </form>
    </div>

    <!-- TABLE -->
    <div class="page-card">
        <h3 style="margin-bottom:15px;">Activity Logs</h3>

        <?php if ($logs && mysqli_num_rows($logs) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>User</th>
                        <th>Activity</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($logs)): ?>
                        <tr>
                            <td><?php echo date('M d, Y h:i A', strtotime($row['log_time'])); ?></td>
                            <td><?php echo e($row['fullname'] ?? 'System'); ?></td>
                            <td><?php echo e($row['activity']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="color:#64748b;">No logs found.</p>
        <?php endif; ?>
    </div>

</div>

<?php include '../includes/footer.php'; ?>