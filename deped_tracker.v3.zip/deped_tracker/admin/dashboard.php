<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator'])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

/*
|--------------------------------------------------------------------------
| Fetch dashboard data
|--------------------------------------------------------------------------
*/

// Documents
$total_docs = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents"))['total'] ?? 0;
$received = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status='Received'"))['total'] ?? 0;
$forwarded = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status='Forwarded'"))['total'] ?? 0;
$in_process = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status='In Process'"))['total'] ?? 0;
$approved = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status='Approved'"))['total'] ?? 0;
$for_release = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status='For Releasing'"))['total'] ?? 0;
$released = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status='Released'"))['total'] ?? 0;

// Users & departments
$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE status='Active'"))['total'] ?? 0;
$total_departments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM departments WHERE status='Active'"))['total'] ?? 0;
$total_org = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM organization WHERE status='Active'"))['total'] ?? 0;

/*
|--------------------------------------------------------------------------
| Recent logs
|--------------------------------------------------------------------------
*/
$recent_logs = mysqli_query($conn, "
    SELECT 
        dl.*,
        d.reference_no,
        u.fullname
    FROM document_logs dl
    LEFT JOIN documents d ON dl.document_id = d.document_id
    LEFT JOIN users u ON dl.updated_by = u.user_id
    ORDER BY dl.action_datetime DESC
    LIMIT 8
");
?>

<div class="main-content">

    <!-- HEADER -->
    <div style="margin-bottom:10px;">
        <h2 style="margin:0; font-size:32px; color:#0f172a;">Administrator Dashboard</h2>
        <p style="margin-top:1px; color:#64748b;">
            Monitor system performance and manage core data of the document tracking system.
        </p>
    </div>

    <!-- TOP CARDS -->
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px,1fr)); gap:18px; margin-bottom:10px;">

        <div class="page-card" style="border-left:5px solid #1d4ed8;">
            <div style="color:#64748b;">Total Documents</div>
            <div style="font-size:32px; font-weight:bold;"><?php echo e($total_docs); ?></div>
        </div>

        <div class="page-card" style="border-left:5px solid #16a34a;">
            <div style="color:#64748b;">Active Users</div>
            <div style="font-size:32px; font-weight:bold;"><?php echo e($total_users); ?></div>
        </div>

        <div class="page-card" style="border-left:5px solid #8b5cf6;">
            <div style="color:#64748b;">Departments</div>
            <div style="font-size:32px; font-weight:bold;"><?php echo e($total_departments); ?></div>
        </div>

        <div class="page-card" style="border-left:5px solid #0ea5e9;">
            <div style="color:#64748b;">Organizations</div>
            <div style="font-size:32px; font-weight:bold;"><?php echo e($total_org); ?></div>
        </div>

    </div>

    <!-- STATUS BREAKDOWN -->
    <div class="page-card" style="margin-bottom:10px;">
        <h3 style="margin-bottom:3px;margin-top:1px;">Document Status Overview</h3>

        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px,1fr)); gap:10px;">

            <?php
            $statuses = [
                'Received' => $received,
                'Forwarded' => $forwarded,
                'In Process' => $in_process,
                'Approved' => $approved,
                'For Releasing' => $for_release,
                'Released' => $released
            ];

            foreach ($statuses as $label => $count):
            ?>
                <div style="background:#f8fafc; padding:14px; border-radius:10px;">
                    <div style="font-size:13px; color:#64748b;"><?php echo $label; ?></div>
                    <div style="font-size:22px; font-weight:bold;"><?php echo $count; ?></div>
                </div>
            <?php endforeach; ?>

        </div>
    </div>

    <div style="display:grid; grid-template-columns:2fr 1fr; gap:24px;">

        <!-- RECENT ACTIVITY -->
        <div class="page-card">
            <h3 style="margin-bottom:5px;margin-top:3px;">Recent Activity</h3>

            <?php if ($recent_logs && mysqli_num_rows($recent_logs) > 0): ?>
                <div style="display:flex; flex-direction:column; gap:12px;">
                    <?php while ($log = mysqli_fetch_assoc($recent_logs)): ?>
                        <div style="border-left:4px solid #1d4ed8; padding-left:10px;">
                            <div style="font-weight:bold;">
                                <?php echo e($log['reference_no']); ?>
                            </div>
                            <div style="font-size:13px; color:#374151;">
                                <?php echo e($log['status']); ?> — <?php echo e($log['remarks']); ?>
                            </div>
                            <div style="font-size:12px; color:#64748b;">
                                <?php echo formatDateTime($log['action_datetime']); ?> | <?php echo e($log['fullname'] ?: 'System'); ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div style="color:#64748b;">No activity yet.</div>
            <?php endif; ?>
        </div>

        <!-- QUICK ACTIONS -->
        <div class="page-card">
            <h3 style="margin-bottom:16px;">System Management</h3>

            <div style="display:flex; flex-direction:column; gap:10px;">

                <a href="users.php" class="btn btn-primary">Manage Users</a>
                <a href="departments.php" class="btn btn-secondary">Departments</a>
                <a href="organizations.php" class="btn btn-secondary">Organizations</a>
                <a href="document_types.php" class="btn btn-secondary">Document Types</a>
                <a href="../records/documents.php" class="btn btn-dark">View All Documents</a>
                <a href="../reports/reports.php" class="btn btn-dark">Reports</a>

            </div>
        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>