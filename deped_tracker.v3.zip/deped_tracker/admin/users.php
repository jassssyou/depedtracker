<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator'])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

/*
|--------------------------------------------------------------------------
| Handle status toggle
|--------------------------------------------------------------------------
*/
if (isset($_GET['toggle']) && isset($_GET['id'])) {
    $user_id = (int) $_GET['id'];

    if ($user_id > 0) {
        $get_user = mysqli_query($conn, "SELECT status FROM users WHERE user_id = '$user_id' LIMIT 1");
        if ($get_user && mysqli_num_rows($get_user) > 0) {
            $user = mysqli_fetch_assoc($get_user);
            $new_status = ($user['status'] === 'Active') ? 'Inactive' : 'Active';

            mysqli_query($conn, "UPDATE users SET status = '$new_status' WHERE user_id = '$user_id'");

            $admin_id = $_SESSION['user_id'];
            $activity = mysqli_real_escape_string($conn, "Updated user status to $new_status (User ID: $user_id)");
            mysqli_query($conn, "INSERT INTO system_logs (user_id, activity, log_time) VALUES ('$admin_id', '$activity', NOW())");
        }
    }

    header("Location: users.php");
    exit();
}

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/
$search = trim($_GET['search'] ?? '');
$role_filter = trim($_GET['role'] ?? '');
$status_filter = trim($_GET['status'] ?? '');

$where = [];
$where[] = "1=1";

if ($search !== '') {
    $search_escaped = mysqli_real_escape_string($conn, $search);
    $where[] = "(
        u.fullname LIKE '%$search_escaped%' OR
        u.username LIKE '%$search_escaped%' OR
        u.email LIKE '%$search_escaped%'
    )";
}

if ($role_filter !== '') {
    $role_escaped = mysqli_real_escape_string($conn, $role_filter);
    $where[] = "u.role = '$role_escaped'";
}

if ($status_filter !== '') {
    $status_escaped = mysqli_real_escape_string($conn, $status_filter);
    $where[] = "u.status = '$status_escaped'";
}

$where_sql = implode(' AND ', $where);

/*
|--------------------------------------------------------------------------
| Fetch users
|--------------------------------------------------------------------------
*/
$users = mysqli_query($conn, "
    SELECT
        u.*,
        d.department_name
    FROM users u
    LEFT JOIN departments d ON u.department_id = d.department_id
    WHERE $where_sql
    ORDER BY u.user_id DESC
");

/*
|--------------------------------------------------------------------------
| Summary counts
|--------------------------------------------------------------------------
*/
$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users"))['total'] ?? 0;
$active_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE status='Active'"))['total'] ?? 0;
$inactive_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM users WHERE status='Inactive'"))['total'] ?? 0;
?>

<div class="main-content">

    <style>
        .users-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 24px;
        }

        .users-hero {
            background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 55%, #3b82f6 100%);
            color: #ffffff;
            border-radius: 18px;
            padding: 24px 26px;
            box-shadow: 0 16px 30px rgba(29, 78, 216, 0.18);
            margin-bottom: 24px;
        }

        .users-hero h2 {
            margin: 0 0 8px 0;
            font-size: 32px;
        }

        .users-hero p {
            margin: 0;
            color: rgba(255,255,255,0.92);
            line-height: 1.6;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
            gap: 18px;
            margin-bottom: 24px;
        }

        .summary-card {
            background: #ffffff;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 8px 22px rgba(15, 23, 42, 0.07);
            border: 1px solid #e5e7eb;
            border-left: 5px solid var(--accent, #1d4ed8);
        }

        .summary-label {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .summary-value {
            font-size: 34px;
            font-weight: bold;
            color: #0f172a;
            line-height: 1;
        }

        .chip {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 600;
        }

        .chip-active {
            background: #dcfce7;
            color: #166534;
        }

        .chip-inactive {
            background: #fee2e2;
            color: #991b1b;
        }

        .role-badge {
            background: #eff6ff;
            color: #1d4ed8;
            padding: 6px 10px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 600;
        }
    </style>

    <div class="users-hero">
        <h2>User Management</h2>
        <p>
            Create, review, and manage system user accounts, roles, and department assignments.
        </p>
    </div>

    <div class="users-header">
        <div>
            <h3 style="margin:0; font-size:28px; color:#0f172a;">System Users</h3>
            <p style="margin:8px 0 0 0; color:#64748b;">
                Maintain administrator, records, and staff user accounts.
            </p>
        </div>

        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <a href="user_form.php" class="btn btn-primary">+ Add User</a>
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </div>
    </div>

    <div class="summary-grid">
        <div class="summary-card" style="--accent:#1d4ed8;">
            <div class="summary-label">Total Users</div>
            <div class="summary-value"><?php echo e($total_users); ?></div>
        </div>

        <div class="summary-card" style="--accent:#16a34a;">
            <div class="summary-label">Active Users</div>
            <div class="summary-value"><?php echo e($active_users); ?></div>
        </div>

        <div class="summary-card" style="--accent:#ef4444;">
            <div class="summary-label">Inactive Users</div>
            <div class="summary-value"><?php echo e($inactive_users); ?></div>
        </div>
    </div>

    <div class="page-card" style="margin-bottom:24px;">
        <form method="GET" style="display:grid; grid-template-columns:2fr 1fr 1fr 170px; gap:14px; align-items:end;">
            <div>
                <label class="label">Search</label>
                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="Name, username, or email"
                    value="<?php echo e($search); ?>"
                >
            </div>

            <div>
                <label class="label">Role</label>
                <select name="role" class="form-control">
                    <option value="">All Roles</option>
                    <option value="Administrator" <?php echo ($role_filter === 'Administrator') ? 'selected' : ''; ?>>Administrator</option>
                    <option value="Records Personnel" <?php echo ($role_filter === 'Records Personnel') ? 'selected' : ''; ?>>Records Personnel</option>
                    <option value="Accounting" <?php echo ($role_filter === 'Accounting') ? 'selected' : ''; ?>>Accounting</option>
                    <option value="Budget" <?php echo ($role_filter === 'Budget') ? 'selected' : ''; ?>>Budget</option>
                    <option value="Human Resource" <?php echo ($role_filter === 'Human Resource') ? 'selected' : ''; ?>>Human Resource</option>
                    <option value="Property" <?php echo ($role_filter === 'Property') ? 'selected' : ''; ?>>Property</option>
                    <option value="Administrative Officer" <?php echo ($role_filter === 'Administrative Officer') ? 'selected' : ''; ?>>Administrative Officer</option>
                    <option value="SDS Secretary" <?php echo ($role_filter === 'SDS Secretary') ? 'selected' : ''; ?>>SDS Secretary</option>
                    <option value="ASDS Secretary" <?php echo ($role_filter === 'ASDS Secretary') ? 'selected' : ''; ?>>ASDS Secretary</option>
                    <option value="SGOD Secretary" <?php echo ($role_filter === 'SGOD Secretary') ? 'selected' : ''; ?>>SGOD Secretary</option>
                    <option value="CID Secretary" <?php echo ($role_filter === 'CID Secretary') ? 'selected' : ''; ?>>CID Secretary</option>
                </select>
            </div>

            <div>
                <label class="label">Status</label>
                <select name="status" class="form-control">
                    <option value="">All Statuses</option>
                    <option value="Active" <?php echo ($status_filter === 'Active') ? 'selected' : ''; ?>>Active</option>
                    <option value="Inactive" <?php echo ($status_filter === 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>

            <div style="display:flex; gap:8px;">
                <button type="submit" class="btn btn-primary" style="width:100%;">Filter</button>
                <a href="users.php" class="btn btn-secondary" style="width:100%; text-align:center;">Reset</a>
            </div>
        </form>
    </div>

    <div class="page-card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
            <h3 style="margin:0; color:#0f172a;">User List</h3>
            <div style="font-size:14px; color:#64748b;">
                Total Result: <strong><?php echo ($users) ? mysqli_num_rows($users) : 0; ?></strong>
            </div>
        </div>

        <?php if ($users && mysqli_num_rows($users) > 0): ?>
            <div style="overflow-x:auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Full Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Department</th>
                            <th>Status</th>
                            <th>Created At</th>
                            <th style="min-width:220px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($users)): ?>
                            <tr>
                                <td><strong><?php echo e($row['fullname']); ?></strong></td>
                                <td><?php echo e($row['username']); ?></td>
                                <td><?php echo e($row['email']); ?></td>
                                <td><span class="role-badge"><?php echo e($row['role']); ?></span></td>
                                <td><?php echo e($row['department_name'] ?: 'N/A'); ?></td>
                                <td>
                                    <?php if ($row['status'] === 'Active'): ?>
                                        <span class="chip chip-active">Active</span>
                                    <?php else: ?>
                                        <span class="chip chip-inactive">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo formatDateTime($row['created_at']); ?></td>
                                <td>
                                    <div style="display:flex; flex-wrap:wrap; gap:8px;">
                                        <a href="user_form.php?id=<?php echo $row['user_id']; ?>"
                                           style="background:#dbeafe; color:#1d4ed8; padding:7px 12px; border-radius:8px; font-size:13px; font-weight:bold;">
                                            Edit
                                        </a>

                                        <a href="users.php?toggle=1&id=<?php echo $row['user_id']; ?>"
                                           onclick="return confirm('Are you sure you want to change this user status?')"
                                           style="background:#fef3c7; color:#92400e; padding:7px 12px; border-radius:8px; font-size:13px; font-weight:bold;">
                                            <?php echo ($row['status'] === 'Active') ? 'Deactivate' : 'Activate'; ?>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div style="padding:20px 0; color:#64748b;">
                No users found.
            </div>
        <?php endif; ?>
    </div>

</div>

<?php include '../includes/footer.php'; ?>