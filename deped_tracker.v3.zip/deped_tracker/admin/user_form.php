<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator'])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

$is_edit = false;
$user_id = 0;
$errors = [];
$success = '';

$fullname = '';
$username = '';
$email = '';
$role = '';
$department_id = '';
$status = 'Active';

/*
|--------------------------------------------------------------------------
| Fetch departments
|--------------------------------------------------------------------------
*/
$departments = mysqli_query($conn, "
    SELECT department_id, department_name
    FROM departments
    WHERE status = 'Active'
    ORDER BY department_name ASC
");

/*
|--------------------------------------------------------------------------
| Edit mode
|--------------------------------------------------------------------------
*/
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $user_id = (int) $_GET['id'];

    $user_query = mysqli_query($conn, "
        SELECT *
        FROM users
        WHERE user_id = '$user_id'
        LIMIT 1
    ");

    if ($user_query && mysqli_num_rows($user_query) > 0) {
        $is_edit = true;
        $user = mysqli_fetch_assoc($user_query);

        $fullname = $user['fullname'];
        $username = $user['username'];
        $email = $user['email'];
        $role = $user['role'];
        $department_id = $user['department_id'];
        $status = $user['status'];
    } else {
        echo "<script>alert('User not found.'); window.location='users.php';</script>";
        exit();
    }
}

/*
|--------------------------------------------------------------------------
| Handle form submit
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $department_id = (int) ($_POST['department_id'] ?? 0);
    $status = trim($_POST['status'] ?? 'Active');
    $password = trim($_POST['password'] ?? '');

    if ($fullname === '') {
        $errors[] = "Full name is required.";
    }

    if ($username === '') {
        $errors[] = "Username is required.";
    }

    if ($email === '') {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }

    if ($role === '') {
        $errors[] = "Role is required.";
    }

    if ($department_id <= 0) {
        $errors[] = "Please select a department.";
    }

    if (!$is_edit && $password === '') {
        $errors[] = "Password is required for new users.";
    }

    /*
    |--------------------------------------------------------------------------
    | Check duplicate username
    |--------------------------------------------------------------------------
    */
    if ($username !== '') {
        $username_escaped = mysqli_real_escape_string($conn, $username);

        $duplicate_username_sql = "
            SELECT user_id
            FROM users
            WHERE username = '$username_escaped'
        ";

        if ($is_edit) {
            $duplicate_username_sql .= " AND user_id != '$user_id'";
        }

        $duplicate_username_sql .= " LIMIT 1";

        $duplicate_username = mysqli_query($conn, $duplicate_username_sql);

        if ($duplicate_username && mysqli_num_rows($duplicate_username) > 0) {
            $errors[] = "Username already exists.";
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Check duplicate email
    |--------------------------------------------------------------------------
    */
    if ($email !== '') {
        $email_escaped = mysqli_real_escape_string($conn, $email);

        $duplicate_email_sql = "
            SELECT user_id
            FROM users
            WHERE email = '$email_escaped'
        ";

        if ($is_edit) {
            $duplicate_email_sql .= " AND user_id != '$user_id'";
        }

        $duplicate_email_sql .= " LIMIT 1";

        $duplicate_email = mysqli_query($conn, $duplicate_email_sql);

        if ($duplicate_email && mysqli_num_rows($duplicate_email) > 0) {
            $errors[] = "Email already exists.";
        }
    }

    if (empty($errors)) {
        $fullname_escaped = mysqli_real_escape_string($conn, $fullname);
        $username_escaped = mysqli_real_escape_string($conn, $username);
        $email_escaped = mysqli_real_escape_string($conn, $email);
        $role_escaped = mysqli_real_escape_string($conn, $role);
        $status_escaped = mysqli_real_escape_string($conn, $status);

        if ($is_edit) {
            if ($password !== '') {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $hashed_password_escaped = mysqli_real_escape_string($conn, $hashed_password);

                $update = mysqli_query($conn, "
                    UPDATE users
                    SET
                        fullname = '$fullname_escaped',
                        username = '$username_escaped',
                        email = '$email_escaped',
                        password = '$hashed_password_escaped',
                        role = '$role_escaped',
                        department_id = '$department_id',
                        status = '$status_escaped'
                    WHERE user_id = '$user_id'
                ");
            } else {
                $update = mysqli_query($conn, "
                    UPDATE users
                    SET
                        fullname = '$fullname_escaped',
                        username = '$username_escaped',
                        email = '$email_escaped',
                        role = '$role_escaped',
                        department_id = '$department_id',
                        status = '$status_escaped'
                    WHERE user_id = '$user_id'
                ");
            }

            if ($update) {
                $admin_id = $_SESSION['user_id'];
                $activity = mysqli_real_escape_string($conn, "Updated user account: $username");
                mysqli_query($conn, "
                    INSERT INTO system_logs (user_id, activity, log_time)
                    VALUES ('$admin_id', '$activity', NOW())
                ");

                echo "<script>alert('User updated successfully.'); window.location='users.php';</script>";
                exit();
            } else {
                $errors[] = "Failed to update user: " . mysqli_error($conn);
            }
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $hashed_password_escaped = mysqli_real_escape_string($conn, $hashed_password);

            $insert = mysqli_query($conn, "
                INSERT INTO users (
                    fullname,
                    username,
                    email,
                    password,
                    role,
                    department_id,
                    status,
                    created_at
                ) VALUES (
                    '$fullname_escaped',
                    '$username_escaped',
                    '$email_escaped',
                    '$hashed_password_escaped',
                    '$role_escaped',
                    '$department_id',
                    '$status_escaped',
                    NOW()
                )
            ");

            if ($insert) {
                $admin_id = $_SESSION['user_id'];
                $activity = mysqli_real_escape_string($conn, "Created new user account: $username");
                mysqli_query($conn, "
                    INSERT INTO system_logs (user_id, activity, log_time)
                    VALUES ('$admin_id', '$activity', NOW())
                ");

                echo "<script>alert('User created successfully.'); window.location='users.php';</script>";
                exit();
            } else {
                $errors[] = "Failed to create user: " . mysqli_error($conn);
            }
        }
    }
}
?>

<div class="main-content">

    <style>
        .form-hero {
            background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 55%, #3b82f6 100%);
            color: #ffffff;
            border-radius: 18px;
            padding: 24px 26px;
            box-shadow: 0 16px 30px rgba(29, 78, 216, 0.18);
            margin-bottom: 24px;
        }

        .form-hero h2 {
            margin: 0 0 8px 0;
            font-size: 32px;
        }

        .form-hero p {
            margin: 0;
            color: rgba(255,255,255,0.92);
            line-height: 1.6;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
            align-items: start;
        }

        @media (max-width: 980px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <div class="form-hero">
        <h2><?php echo $is_edit ? 'Edit User' : 'Add New User'; ?></h2>
        <p>
            <?php echo $is_edit ? 'Update account details, role, department, and status.' : 'Create a new system user account with the proper role and department assignment.'; ?>
        </p>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <strong>Please fix the following:</strong>
            <ul style="margin:10px 0 0 20px;">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="form-grid">

        <div class="page-card">
            <h3 style="margin:0 0 18px 0; color:#0f172a;"><?php echo $is_edit ? 'User Information' : 'New User Information'; ?></h3>

            <form method="POST">

                <div style="margin-bottom:18px;">
                    <label class="label">Full Name</label>
                    <input
                        type="text"
                        name="fullname"
                        class="form-control"
                        value="<?php echo e($fullname); ?>"
                        required
                    >
                </div>

                <div style="margin-bottom:18px;">
                    <label class="label">Username</label>
                    <input
                        type="text"
                        name="username"
                        class="form-control"
                        value="<?php echo e($username); ?>"
                        required
                    >
                </div>

                <div style="margin-bottom:18px;">
                    <label class="label">Email</label>
                    <input
                        type="email"
                        name="email"
                        class="form-control"
                        value="<?php echo e($email); ?>"
                        required
                    >
                </div>

                <div style="margin-bottom:18px;">
                    <label class="label">
                        Password
                        <?php if ($is_edit): ?>
                            <span style="font-weight:normal; color:#64748b;">(leave blank to keep current password)</span>
                        <?php endif; ?>
                    </label>
                    <input
                        type="password"
                        name="password"
                        class="form-control"
                        <?php echo $is_edit ? '' : 'required'; ?>
                    >
                </div>

                <div style="margin-bottom:18px;">
                    <label class="label">Role</label>
                    <select name="role" class="form-control" required>
                        <option value="">Select role</option>
                        <option value="Administrator" <?php echo ($role === 'Administrator') ? 'selected' : ''; ?>>Administrator</option>
                        <option value="Records Personnel" <?php echo ($role === 'Records Personnel') ? 'selected' : ''; ?>>Records Personnel</option>
                        <option value="Accounting" <?php echo ($role === 'Accounting') ? 'selected' : ''; ?>>Accounting</option>
                        <option value="Budget" <?php echo ($role === 'Budget') ? 'selected' : ''; ?>>Budget</option>
                        <option value="Human Resource" <?php echo ($role === 'Human Resource') ? 'selected' : ''; ?>>Human Resource</option>
                        <option value="Property" <?php echo ($role === 'Property') ? 'selected' : ''; ?>>Property</option>
                        <option value="Administrative Officer" <?php echo ($role === 'Administrative Officer') ? 'selected' : ''; ?>>Administrative Officer</option>
                        <option value="SDS Secretary" <?php echo ($role === 'SDS Secretary') ? 'selected' : ''; ?>>SDS Secretary</option>
                        <option value="ASDS Secretary" <?php echo ($role === 'ASDS Secretary') ? 'selected' : ''; ?>>ASDS Secretary</option>
                        <option value="SGOD Secretary" <?php echo ($role === 'SGOD Secretary') ? 'selected' : ''; ?>>SGOD Secretary</option>
                        <option value="CID Secretary" <?php echo ($role === 'CID Secretary') ? 'selected' : ''; ?>>CID Secretary</option>
                    </select>
                </div>

                <div style="margin-bottom:18px;">
                    <label class="label">Department</label>
                    <select name="department_id" class="form-control" required>
                        <option value="">Select department</option>
                        <?php if ($departments): ?>
                            <?php while ($dept = mysqli_fetch_assoc($departments)): ?>
                                <option value="<?php echo $dept['department_id']; ?>" <?php echo ($department_id == $dept['department_id']) ? 'selected' : ''; ?>>
                                    <?php echo e($dept['department_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div style="margin-bottom:22px;">
                    <label class="label">Status</label>
                    <select name="status" class="form-control" required>
                        <option value="Active" <?php echo ($status === 'Active') ? 'selected' : ''; ?>>Active</option>
                        <option value="Inactive" <?php echo ($status === 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>

                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <button type="submit" class="btn btn-primary">
                        <?php echo $is_edit ? 'Update User' : 'Create User'; ?>
                    </button>
                    <a href="users.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>

        <div class="page-card">
            <h3 style="margin:0 0 16px 0; color:#0f172a;">Form Guide</h3>

            <div style="display:flex; flex-direction:column; gap:12px; color:#374151; font-size:14px; line-height:1.7;">
                <div><strong>Administrator</strong> has full system access.</div>
                <div><strong>Records Personnel</strong> handles registration, forwarding, and release flow.</div>
                <div><strong>Staff roles</strong> process only documents assigned to their department.</div>
                <div>Each user should be assigned to the correct department to avoid visibility conflicts later.</div>
                <div>Use a strong password for better account security.</div>
            </div>
        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>