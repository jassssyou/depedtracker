<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator'])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

$is_edit = false;
$department_id = 0;
$errors = [];

$department_name = '';
$status = 'Active';

/*
|--------------------------------------------------------------------------
| Edit mode
|--------------------------------------------------------------------------
*/
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $department_id = (int) $_GET['id'];

    $department_query = mysqli_query($conn, "
        SELECT *
        FROM departments
        WHERE department_id = '$department_id'
        LIMIT 1
    ");

    if ($department_query && mysqli_num_rows($department_query) > 0) {
        $is_edit = true;
        $department = mysqli_fetch_assoc($department_query);

        $department_name = $department['department_name'];
        $status = $department['status'];
    } else {
        echo "<script>alert('Department not found.'); window.location='departments.php';</script>";
        exit();
    }
}

/*
|--------------------------------------------------------------------------
| Handle submit
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $department_name = trim($_POST['department_name'] ?? '');
    $status = trim($_POST['status'] ?? 'Active');

    if ($department_name === '') {
        $errors[] = "Department name is required.";
    }

    /*
    |--------------------------------------------------------------------------
    | Check duplicate department name
    |--------------------------------------------------------------------------
    */
    if ($department_name !== '') {
        $department_name_escaped = mysqli_real_escape_string($conn, $department_name);

        $duplicate_sql = "
            SELECT department_id
            FROM departments
            WHERE department_name = '$department_name_escaped'
        ";

        if ($is_edit) {
            $duplicate_sql .= " AND department_id != '$department_id'";
        }

        $duplicate_sql .= " LIMIT 1";

        $duplicate_query = mysqli_query($conn, $duplicate_sql);

        if ($duplicate_query && mysqli_num_rows($duplicate_query) > 0) {
            $errors[] = "Department name already exists.";
        }
    }

    if (empty($errors)) {
        $department_name_escaped = mysqli_real_escape_string($conn, $department_name);
        $status_escaped = mysqli_real_escape_string($conn, $status);

        if ($is_edit) {
            $update = mysqli_query($conn, "
                UPDATE departments
                SET
                    department_name = '$department_name_escaped',
                    status = '$status_escaped'
                WHERE department_id = '$department_id'
            ");

            if ($update) {
                $admin_id = $_SESSION['user_id'];
                $activity = mysqli_real_escape_string($conn, "Updated department: $department_name");
                mysqli_query($conn, "
                    INSERT INTO system_logs (user_id, activity, log_time)
                    VALUES ('$admin_id', '$activity', NOW())
                ");

                echo "<script>alert('Department updated successfully.'); window.location='departments.php';</script>";
                exit();
            } else {
                $errors[] = "Failed to update department: " . mysqli_error($conn);
            }
        } else {
            $insert = mysqli_query($conn, "
                INSERT INTO departments (
                    department_name,
                    status
                ) VALUES (
                    '$department_name_escaped',
                    '$status_escaped'
                )
            ");

            if ($insert) {
                $admin_id = $_SESSION['user_id'];
                $activity = mysqli_real_escape_string($conn, "Created department: $department_name");
                mysqli_query($conn, "
                    INSERT INTO system_logs (user_id, activity, log_time)
                    VALUES ('$admin_id', '$activity', NOW())
                ");

                echo "<script>alert('Department created successfully.'); window.location='departments.php';</script>";
                exit();
            } else {
                $errors[] = "Failed to create department: " . mysqli_error($conn);
            }
        }
    }
}
?>

<div class="main-content">

    <style>
        .form-hero {
            background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 55%, #3b82f6 100%);
            color: #ffffff;
            border-radius: 18px;
            padding: 24px 26px;
            box-shadow: 0 16px 30px rgba(29, 78, 216, 0.18);
            margin-bottom: 24px;
        }

        .form-hero h2 {
            margin: 0 0 8px 0;
            font-size: 32px;
        }

        .form-hero p {
            margin: 0;
            color: rgba(255,255,255,0.92);
            line-height: 1.6;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
            align-items: start;
        }

        @media (max-width: 980px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <div class="form-hero">
        <h2><?php echo $is_edit ? 'Edit Department' : 'Add New Department'; ?></h2>
        <p>
            <?php echo $is_edit ? 'Update department name and current status.' : 'Create a new department or office for routing and user assignment.'; ?>
        </p>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <strong>Please fix the following:</strong>
            <ul style="margin:10px 0 0 20px;">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="form-grid">

        <div class="page-card">
            <h3 style="margin:0 0 18px 0; color:#0f172a;"><?php echo $is_edit ? 'Department Information' : 'New Department Information'; ?></h3>

            <form method="POST">

                <div style="margin-bottom:18px;">
                    <label class="label">Department Name</label>
                    <input
                        type="text"
                        name="department_name"
                        class="form-control"
                        value="<?php echo e($department_name); ?>"
                        placeholder="Enter department name"
                        required
                    >
                </div>

                <div style="margin-bottom:22px;">
                    <label class="label">Status</label>
                    <select name="status" class="form-control" required>
                        <option value="Active" <?php echo ($status === 'Active') ? 'selected' : ''; ?>>Active</option>
                        <option value="Inactive" <?php echo ($status === 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>

                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <button type="submit" class="btn btn-primary">
                        <?php echo $is_edit ? 'Update Department' : 'Create Department'; ?>
                    </button>
                    <a href="departments.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>

        <div class="page-card">
            <h3 style="margin:0 0 16px 0; color:#0f172a;">Form Guide</h3>

            <div style="display:flex; flex-direction:column; gap:12px; color:#374151; font-size:14px; line-height:1.7;">
                <div>Departments are used for <strong>document routing</strong> and <strong>user assignment</strong>.</div>
                <div>Use clear names such as <strong>Records</strong>, <strong>ITO</strong>, <strong>Accounting</strong>, or <strong>CID Secretary</strong>.</div>
                <div>Inactive departments will remain in the database for history, but should not be used for new assignments.</div>
                <div>Avoid creating duplicate department names to prevent routing confusion later.</div>
            </div>
        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>