<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator'])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

/*
|--------------------------------------------------------------------------
| Handle status toggle
|--------------------------------------------------------------------------
*/
if (isset($_GET['toggle']) && isset($_GET['id'])) {
    $org_id = (int) $_GET['id'];

    if ($org_id > 0) {
        $get_org = mysqli_query($conn, "
            SELECT status, org_name
            FROM organization
            WHERE org_id = '$org_id'
            LIMIT 1
        ");

        if ($get_org && mysqli_num_rows($get_org) > 0) {
            $org = mysqli_fetch_assoc($get_org);
            $new_status = ($org['status'] === 'Active') ? 'Inactive' : 'Active';

            mysqli_query($conn, "
                UPDATE organization
                SET status = '$new_status'
                WHERE org_id = '$org_id'
            ");

            $admin_id = $_SESSION['user_id'];
            $org_name = mysqli_real_escape_string($conn, $org['org_name']);
            $activity = mysqli_real_escape_string($conn, "Updated organization status to $new_status: $org_name");
            mysqli_query($conn, "
                INSERT INTO system_logs (user_id, activity, log_time)
                VALUES ('$admin_id', '$activity', NOW())
            ");
        }
    }

    header("Location: organizations.php");
    exit();
}

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/
$search = trim($_GET['search'] ?? '');
$status_filter = trim($_GET['status'] ?? '');

$where = [];
$where[] = "1=1";

if ($search !== '') {
    $search_escaped = mysqli_real_escape_string($conn, $search);
    $where[] = "org_name LIKE '%$search_escaped%'";
}

if ($status_filter !== '') {
    $status_escaped = mysqli_real_escape_string($conn, $status_filter);
    $where[] = "status = '$status_escaped'";
}

$where_sql = implode(' AND ', $where);

/*
|--------------------------------------------------------------------------
| Fetch organizations
|--------------------------------------------------------------------------
*/
$organizations = mysqli_query($conn, "
    SELECT *
    FROM organization
    WHERE $where_sql
    ORDER BY org_id ASC
");

/*
|--------------------------------------------------------------------------
| Summary counts
|--------------------------------------------------------------------------
*/
$total_organizations = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM organization"))['total'] ?? 0;
$active_organizations = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM organization WHERE status='Active'"))['total'] ?? 0;
$inactive_organizations = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM organization WHERE status='Inactive'"))['total'] ?? 0;
?>

<div class="main-content">

    <style>
        .org-hero {
            background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 55%, #3b82f6 100%);
            color: #ffffff;
            border-radius: 18px;
            padding: 24px 26px;
            box-shadow: 0 16px 30px rgba(29, 78, 216, 0.18);
            margin-bottom: 24px;
        }

        .org-hero h2 {
            margin: 0 0 8px 0;
            font-size: 32px;
        }

        .org-hero p {
            margin: 0;
            color: rgba(255,255,255,0.92);
            line-height: 1.6;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
            gap: 18px;
            margin-bottom: 24px;
        }

        .summary-card {
            background: #ffffff;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 8px 22px rgba(15, 23, 42, 0.07);
            border: 1px solid #e5e7eb;
            border-left: 5px solid var(--accent, #1d4ed8);
        }

        .summary-label {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .summary-value {
            font-size: 34px;
            font-weight: bold;
            color: #0f172a;
            line-height: 1;
        }

        .chip {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 600;
        }

        .chip-active {
            background: #dcfce7;
            color: #166534;
        }

        .chip-inactive {
            background: #fee2e2;
            color: #991b1b;
        }
    </style>

    <div class="org-hero">
        <h2>Organizations</h2>
        <p>
            Maintain organizations, schools, and institutions used in document registration and tracking.
        </p>
    </div>

    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:20px; flex-wrap:wrap; margin-bottom:24px;">
        <div>
            <h3 style="margin:0; font-size:28px; color:#0f172a;">Organization Maintenance</h3>
            <p style="margin:8px 0 0 0; color:#64748b;">
                Add, edit, activate, or deactivate organizations available in the registration form.
            </p>
        </div>

        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <a href="organization_form.php" class="btn btn-primary">+ Add Organization</a>
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </div>
    </div>

    <div class="summary-grid">
        <div class="summary-card" style="--accent:#1d4ed8;">
            <div class="summary-label">Total Organizations</div>
            <div class="summary-value"><?php echo e($total_organizations); ?></div>
        </div>

        <div class="summary-card" style="--accent:#16a34a;">
            <div class="summary-label">Active</div>
            <div class="summary-value"><?php echo e($active_organizations); ?></div>
        </div>

        <div class="summary-card" style="--accent:#ef4444;">
            <div class="summary-label">Inactive</div>
            <div class="summary-value"><?php echo e($inactive_organizations); ?></div>
        </div>
    </div>

    <div class="page-card" style="margin-bottom:24px;">
        <form method="GET" style="display:grid; grid-template-columns:2fr 1fr 170px; gap:14px; align-items:end;">
            <div>
                <label class="label">Search</label>
                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="Organization name"
                    value="<?php echo e($search); ?>"
                >
            </div>

            <div>
                <label class="label">Status</label>
                <select name="status" class="form-control">
                    <option value="">All Statuses</option>
                    <option value="Active" <?php echo ($status_filter === 'Active') ? 'selected' : ''; ?>>Active</option>
                    <option value="Inactive" <?php echo ($status_filter === 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>

            <div style="display:flex; gap:8px;">
                <button type="submit" class="btn btn-primary" style="width:100%;">Filter</button>
                <a href="organizations.php" class="btn btn-secondary" style="width:100%; text-align:center;">Reset</a>
            </div>
        </form>
    </div>

    <div class="page-card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
            <h3 style="margin:0; color:#0f172a;">Organization List</h3>
            <div style="font-size:14px; color:#64748b;">
                Total Result: <strong><?php echo ($organizations) ? mysqli_num_rows($organizations) : 0; ?></strong>
            </div>
        </div>

        <?php if ($organizations && mysqli_num_rows($organizations) > 0): ?>
            <div style="overflow-x:auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Organization Name</th>
                            <th>Status</th>
                            <th style="min-width:220px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($organizations)): ?>
                            <tr>
                                <td><strong><?php echo e($row['org_id']); ?></strong></td>
                                <td><?php echo e($row['org_name']); ?></td>
                                <td>
                                    <?php if ($row['status'] === 'Active'): ?>
                                        <span class="chip chip-active">Active</span>
                                    <?php else: ?>
                                        <span class="chip chip-inactive">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div style="display:flex; flex-wrap:wrap; gap:8px;">
                                        <a href="organization_form.php?id=<?php echo $row['org_id']; ?>"
                                           style="background:#dbeafe; color:#1d4ed8; padding:7px 12px; border-radius:8px; font-size:13px; font-weight:bold;">
                                            Edit
                                        </a>

                                        <a href="organizations.php?toggle=1&id=<?php echo $row['org_id']; ?>"
                                           onclick="return confirm('Are you sure you want to change this organization status?')"
                                           style="background:#fef3c7; color:#92400e; padding:7px 12px; border-radius:8px; font-size:13px; font-weight:bold;">
                                            <?php echo ($row['status'] === 'Active') ? 'Deactivate' : 'Activate'; ?>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div style="padding:20px 0; color:#64748b;">
                No organizations found.
            </div>
        <?php endif; ?>
    </div>

</div>

<?php include '../includes/footer.php'; ?>