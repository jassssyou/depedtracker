<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator'])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

$is_edit = false;
$document_type_id = 0;
$errors = [];

$document_type_name = '';
$status = 'Active';

/*
|--------------------------------------------------------------------------
| Edit mode
|--------------------------------------------------------------------------
*/
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $document_type_id = (int) $_GET['id'];

    $type_query = mysqli_query($conn, "
        SELECT *
        FROM document_types
        WHERE document_type_id = '$document_type_id'
        LIMIT 1
    ");

    if ($type_query && mysqli_num_rows($type_query) > 0) {
        $is_edit = true;
        $type = mysqli_fetch_assoc($type_query);

        $document_type_name = $type['document_type_name'];
        $status = $type['status'];
    } else {
        echo "<script>alert('Document type not found.'); window.location='document_types.php';</script>";
        exit();
    }
}

/*
|--------------------------------------------------------------------------
| Handle submit
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $document_type_name = trim($_POST['document_type_name'] ?? '');
    $status = trim($_POST['status'] ?? 'Active');

    if ($document_type_name === '') {
        $errors[] = "Document type name is required.";
    }

    /*
    |--------------------------------------------------------------------------
    | Check duplicate document type name
    |--------------------------------------------------------------------------
    */
    if ($document_type_name !== '') {
        $document_type_name_escaped = mysqli_real_escape_string($conn, $document_type_name);

        $duplicate_sql = "
            SELECT document_type_id
            FROM document_types
            WHERE document_type_name = '$document_type_name_escaped'
        ";

        if ($is_edit) {
            $duplicate_sql .= " AND document_type_id != '$document_type_id'";
        }

        $duplicate_sql .= " LIMIT 1";

        $duplicate_query = mysqli_query($conn, $duplicate_sql);

        if ($duplicate_query && mysqli_num_rows($duplicate_query) > 0) {
            $errors[] = "Document type name already exists.";
        }
    }

    if (empty($errors)) {
        $document_type_name_escaped = mysqli_real_escape_string($conn, $document_type_name);
        $status_escaped = mysqli_real_escape_string($conn, $status);

        if ($is_edit) {
            $update = mysqli_query($conn, "
                UPDATE document_types
                SET
                    document_type_name = '$document_type_name_escaped',
                    status = '$status_escaped'
                WHERE document_type_id = '$document_type_id'
            ");

            if ($update) {
                $admin_id = $_SESSION['user_id'];
                $activity = mysqli_real_escape_string($conn, "Updated document type: $document_type_name");
                mysqli_query($conn, "
                    INSERT INTO system_logs (user_id, activity, log_time)
                    VALUES ('$admin_id', '$activity', NOW())
                ");

                echo "<script>alert('Document type updated successfully.'); window.location='document_types.php';</script>";
                exit();
            } else {
                $errors[] = "Failed to update document type: " . mysqli_error($conn);
            }
        } else {
            $insert = mysqli_query($conn, "
                INSERT INTO document_types (
                    document_type_name,
                    status
                ) VALUES (
                    '$document_type_name_escaped',
                    '$status_escaped'
                )
            ");

            if ($insert) {
                $admin_id = $_SESSION['user_id'];
                $activity = mysqli_real_escape_string($conn, "Created document type: $document_type_name");
                mysqli_query($conn, "
                    INSERT INTO system_logs (user_id, activity, log_time)
                    VALUES ('$admin_id', '$activity', NOW())
                ");

                echo "<script>alert('Document type created successfully.'); window.location='document_types.php';</script>";
                exit();
            } else {
                $errors[] = "Failed to create document type: " . mysqli_error($conn);
            }
        }
    }
}
?>

<div class="main-content">

    <style>
        .form-hero {
            background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 55%, #3b82f6 100%);
            color: #ffffff;
            border-radius: 18px;
            padding: 24px 26px;
            box-shadow: 0 16px 30px rgba(29, 78, 216, 0.18);
            margin-bottom: 24px;
        }

        .form-hero h2 {
            margin: 0 0 8px 0;
            font-size: 32px;
        }

        .form-hero p {
            margin: 0;
            color: rgba(255,255,255,0.92);
            line-height: 1.6;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
            align-items: start;
        }

        @media (max-width: 980px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <div class="form-hero">
        <h2><?php echo $is_edit ? 'Edit Document Type' : 'Add New Document Type'; ?></h2>
        <p>
            <?php echo $is_edit ? 'Update document type details and current status.' : 'Create a new document type to be used in registration and tracking.'; ?>
        </p>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <strong>Please fix the following:</strong>
            <ul style="margin:10px 0 0 20px;">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="form-grid">

        <div class="page-card">
            <h3 style="margin:0 0 18px 0; color:#0f172a;">
                <?php echo $is_edit ? 'Document Type Information' : 'New Document Type Information'; ?>
            </h3>

            <form method="POST">

                <div style="margin-bottom:18px;">
                    <label class="label">Document Type Name</label>
                    <input
                        type="text"
                        name="document_type_name"
                        class="form-control"
                        value="<?php echo e($document_type_name); ?>"
                        placeholder="Enter document type name"
                        required
                    >
                </div>

                <div style="margin-bottom:22px;">
                    <label class="label">Status</label>
                    <select name="status" class="form-control" required>
                        <option value="Active" <?php echo ($status === 'Active') ? 'selected' : ''; ?>>Active</option>
                        <option value="Inactive" <?php echo ($status === 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>

                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <button type="submit" class="btn btn-primary">
                        <?php echo $is_edit ? 'Update Document Type' : 'Create Document Type'; ?>
                    </button>
                    <a href="document_types.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>

        <div class="page-card">
            <h3 style="margin:0 0 16px 0; color:#0f172a;">Form Guide</h3>

            <div style="display:flex; flex-direction:column; gap:12px; color:#374151; font-size:14px; line-height:1.7;">
                <div>Document types appear in the registration form used by Records Personnel.</div>
                <div>Examples include <strong>Request Letter</strong>, <strong>Voucher</strong>, <strong>Memorandum</strong>, or <strong>Certification</strong>.</div>
                <div>Inactive document types remain in the database for history but should not appear in active registration dropdowns.</div>
                <div>Avoid duplicate names to keep reports and filters clean.</div>
            </div>
        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>