<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator'])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

$is_edit = false;
$org_id = 0;
$errors = [];

$org_name = '';
$status = 'Active';

/*
|--------------------------------------------------------------------------
| Edit mode
|--------------------------------------------------------------------------
*/
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $org_id = (int) $_GET['id'];

    $org_query = mysqli_query($conn, "
        SELECT *
        FROM organization
        WHERE org_id = '$org_id'
        LIMIT 1
    ");

    if ($org_query && mysqli_num_rows($org_query) > 0) {
        $is_edit = true;
        $org = mysqli_fetch_assoc($org_query);

        $org_name = $org['org_name'];
        $status = $org['status'];
    } else {
        echo "<script>alert('Organization not found.'); window.location='organizations.php';</script>";
        exit();
    }
}

/*
|--------------------------------------------------------------------------
| Handle submit
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $org_name = trim($_POST['org_name'] ?? '');
    $status = trim($_POST['status'] ?? 'Active');

    if ($org_name === '') {
        $errors[] = "Organization name is required.";
    }

    /*
    |--------------------------------------------------------------------------
    | Check duplicate organization name
    |--------------------------------------------------------------------------
    */
    if ($org_name !== '') {
        $org_name_escaped = mysqli_real_escape_string($conn, $org_name);

        $duplicate_sql = "
            SELECT org_id
            FROM organization
            WHERE org_name = '$org_name_escaped'
        ";

        if ($is_edit) {
            $duplicate_sql .= " AND org_id != '$org_id'";
        }

        $duplicate_sql .= " LIMIT 1";

        $duplicate_query = mysqli_query($conn, $duplicate_sql);

        if ($duplicate_query && mysqli_num_rows($duplicate_query) > 0) {
            $errors[] = "Organization name already exists.";
        }
    }

    if (empty($errors)) {
        $org_name_escaped = mysqli_real_escape_string($conn, $org_name);
        $status_escaped = mysqli_real_escape_string($conn, $status);

        if ($is_edit) {
            $update = mysqli_query($conn, "
                UPDATE organization
                SET
                    org_name = '$org_name_escaped',
                    status = '$status_escaped'
                WHERE org_id = '$org_id'
            ");

            if ($update) {
                $admin_id = $_SESSION['user_id'];
                $activity = mysqli_real_escape_string($conn, "Updated organization: $org_name");
                mysqli_query($conn, "
                    INSERT INTO system_logs (user_id, activity, log_time)
                    VALUES ('$admin_id', '$activity', NOW())
                ");

                echo "<script>alert('Organization updated successfully.'); window.location='organizations.php';</script>";
                exit();
            } else {
                $errors[] = "Failed to update organization: " . mysqli_error($conn);
            }
        } else {
            $insert = mysqli_query($conn, "
                INSERT INTO organization (
                    org_name,
                    status
                ) VALUES (
                    '$org_name_escaped',
                    '$status_escaped'
                )
            ");

            if ($insert) {
                $admin_id = $_SESSION['user_id'];
                $activity = mysqli_real_escape_string($conn, "Created organization: $org_name");
                mysqli_query($conn, "
                    INSERT INTO system_logs (user_id, activity, log_time)
                    VALUES ('$admin_id', '$activity', NOW())
                ");

                echo "<script>alert('Organization created successfully.'); window.location='organizations.php';</script>";
                exit();
            } else {
                $errors[] = "Failed to create organization: " . mysqli_error($conn);
            }
        }
    }
}
?>

<div class="main-content">

    <style>
        .form-hero {
            background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 55%, #3b82f6 100%);
            color: #ffffff;
            border-radius: 18px;
            padding: 24px 26px;
            box-shadow: 0 16px 30px rgba(29, 78, 216, 0.18);
            margin-bottom: 24px;
        }

        .form-hero h2 {
            margin: 0 0 8px 0;
            font-size: 32px;
        }

        .form-hero p {
            margin: 0;
            color: rgba(255,255,255,0.92);
            line-height: 1.6;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 24px;
            align-items: start;
        }

        @media (max-width: 980px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>

    <div class="form-hero">
        <h2><?php echo $is_edit ? 'Edit Organization' : 'Add New Organization'; ?></h2>
        <p>
            <?php echo $is_edit ? 'Update organization details and current status.' : 'Create a new organization, school, or institution for document registration.'; ?>
        </p>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <strong>Please fix the following:</strong>
            <ul style="margin:10px 0 0 20px;">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="form-grid">

        <div class="page-card">
            <h3 style="margin:0 0 18px 0; color:#0f172a;"><?php echo $is_edit ? 'Organization Information' : 'New Organization Information'; ?></h3>

            <form method="POST">

                <div style="margin-bottom:18px;">
                    <label class="label">Organization Name</label>
                    <input
                        type="text"
                        name="org_name"
                        class="form-control"
                        value="<?php echo e($org_name); ?>"
                        placeholder="Enter organization name"
                        required
                    >
                </div>

                <div style="margin-bottom:22px;">
                    <label class="label">Status</label>
                    <select name="status" class="form-control" required>
                        <option value="Active" <?php echo ($status === 'Active') ? 'selected' : ''; ?>>Active</option>
                        <option value="Inactive" <?php echo ($status === 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>

                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <button type="submit" class="btn btn-primary">
                        <?php echo $is_edit ? 'Update Organization' : 'Create Organization'; ?>
                    </button>
                    <a href="organizations.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>

        <div class="page-card">
            <h3 style="margin:0 0 16px 0; color:#0f172a;">Form Guide</h3>

            <div style="display:flex; flex-direction:column; gap:12px; color:#374151; font-size:14px; line-height:1.7;">
                <div>Organizations are used when registering submitted documents.</div>
                <div>These may include <strong>schools</strong>, <strong>private institutions</strong>, or other official submitting bodies.</div>
                <div>Inactive organizations remain in the database for history but should not appear in active selection lists.</div>
                <div>Avoid duplicate names to keep registration records clean and consistent.</div>
            </div>
        </div>

    </div>

</div>

<?php include '../includes/footer.php'; ?>