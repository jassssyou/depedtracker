<?php
include '../config/database.php';

$ref = trim($_GET['ref'] ?? '');
$document = null;
$logs = null;
$error_message = '';

if ($ref === '') {
    $error_message = "Reference number is required.";
} else {
    $ref_escaped = mysqli_real_escape_string($conn, $ref);

    $query = mysqli_query($conn, "
        SELECT 
            d.*,
            dt.document_type_name,
            o.org_name,
            dep.department_name
        FROM documents d
        LEFT JOIN document_types dt ON d.document_type_id = dt.document_type_id
        LEFT JOIN organization o ON d.org_id = o.org_id
        LEFT JOIN departments dep ON d.current_department_id = dep.department_id
        WHERE d.reference_no = '$ref_escaped'
        LIMIT 1
    ");

    if ($query && mysqli_num_rows($query) > 0) {
        $document = mysqli_fetch_assoc($query);

        $document_id = (int) $document['document_id'];

        $logs = mysqli_query($conn, "
            SELECT 
                dl.*,
                fd.department_name AS from_department_name,
                td.department_name AS to_department_name
            FROM document_logs dl
            LEFT JOIN departments fd ON dl.from_department = fd.department_id
            LEFT JOIN departments td ON dl.to_department = td.department_id
            WHERE dl.document_id = '$document_id'
            ORDER BY dl.action_datetime DESC
        ");
    } else {
        $error_message = "No record found for the reference number you entered.";
    }
}

function e($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function formatDateTime($datetime) {
    if (empty($datetime)) {
        return 'N/A';
    }
    return date('F j, Y h:i A', strtotime($datetime));
}

function getStatusStyle($status) {
    $status = strtolower(trim($status));

    switch ($status) {
        case 'received':
            return "background:#dbeafe; color:#1d4ed8;";
        case 'in process':
            return "background:#fef3c7; color:#92400e;";
        case 'forwarded':
            return "background:#ede9fe; color:#7c3aed;";
        case 'approved':
            return "background:#dcfce7; color:#166534;";
        case 'for releasing':
            return "background:#ccfbf1; color:#0f766e;";
        case 'released':
            return "background:#d1fae5; color:#065f46;";
        default:
            return "background:#e5e7eb; color:#374151;";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Document - DepEd Talisay Document Tracking System</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            margin: 0;
            min-height: 100vh;
            background: #eef3fb;
            color: #111827;
        }

        .topbar {
            background: #ffffff;
            border-bottom: 1px solid #dbe3ef;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .brand-logo {
            width: 58px;
            height: 58px;
            background: #ffffff;
            border: 4px solid #1d4ed8;
            border-radius: 14px;
            box-shadow: 0 8px 18px rgba(29, 78, 216, 0.12);
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .brand-logo img {
            width: 75%;
            height: auto;
        }

        .brand-text h1 {
            margin: 0;
            font-size: 20px;
            color: #0f172a;
        }

        .brand-text p {
            margin: 4px 0 0 0;
            font-size: 12px;
            color: #64748b;
            letter-spacing: 1px;
        }

        .top-link {
            color: #1d4ed8;
            font-weight: bold;
            text-decoration: none;
        }

        .top-link:hover {
            color: #1e40af;
        }

        .page-wrap {
            max-width: 1200px;
            margin: 0 auto;
            padding: 32px 20px 40px;
        }

        .search-card,
        .info-card,
        .timeline-card,
        .error-card {
            background: #ffffff;
            border-radius: 18px;
            box-shadow: 0 12px 28px rgba(15, 23, 42, 0.08);
            border: 1px solid #e5e7eb;
        }

        .search-card {
            padding: 18px;
            margin-bottom: 24px;
        }

        .search-form {
            display: grid;
            grid-template-columns: 1fr 180px;
            gap: 12px;
        }

        .search-input {
            width: 100%;
            padding: 16px 18px;
            border: 1px solid #cbd5e1;
            border-radius: 14px;
            font-size: 16px;
            outline: none;
            background: #ffffff;
            color: #111827;
        }

        .search-input:focus {
            border-color: #1d4ed8;
            box-shadow: 0 0 0 4px rgba(29, 78, 216, 0.10);
        }

        .search-btn {
            border: none;
            background: #1d4ed8;
            color: #ffffff;
            border-radius: 14px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            padding: 16px 18px;
        }

        .search-btn:hover {
            background: #1e40af;
        }

        .page-header {
            margin-bottom: 20px;
        }

        .page-header h2 {
            margin: 0;
            font-size: 36px;
            color: #0f172a;
        }

        .page-header p {
            margin: 8px 0 0 0;
            color: #64748b;
            font-size: 16px;
        }

        .error-card {
            padding: 28px;
            text-align: center;
        }

        .error-title {
            font-size: 22px;
            font-weight: bold;
            color: #991b1b;
            margin: 0 0 10px 0;
        }

        .error-text {
            color: #6b7280;
            margin-bottom: 20px;
        }

        .back-btn {
            display: inline-block;
            background: #1d4ed8;
            color: #ffffff;
            padding: 12px 18px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: bold;
        }

        .content-grid {
            display: grid;
            grid-template-columns: 1.8fr 1fr;
            gap: 24px;
            align-items: start;
        }

        .info-card {
            padding: 28px;
        }

        .info-card h3,
        .timeline-card h3 {
            margin: 0 0 18px 0;
            font-size: 24px;
            color: #0f172a;
        }

        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 22px;
        }

        .info-item label {
            display: block;
            font-size: 12px;
            font-weight: bold;
            color: #64748b;
            letter-spacing: 0.8px;
            margin-bottom: 8px;
            text-transform: uppercase;
        }

        .info-item .value {
            font-size: 18px;
            color: #111827;
            line-height: 1.5;
        }

        .status-badge {
            display: inline-block;
            padding: 7px 12px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: bold;
        }

        .description-box {
            margin-top: 20px;
            padding: 16px;
            border: 1px solid #e5e7eb;
            background: #f8fbff;
            border-radius: 14px;
            min-height: 90px;
            white-space: pre-line;
            color: #1f2937;
        }

        .timeline-card {
            padding: 24px;
        }

        .timeline-list {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .timeline-item {
            position: relative;
            padding-left: 18px;
            border-left: 3px solid #8fb0df;
        }

        .timeline-item::before {
            content: "";
            position: absolute;
            left: -8px;
            top: 2px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #1d4ed8;
            border: 2px solid #ffffff;
            box-shadow: 0 0 0 2px #c7d8ee;
        }

        .timeline-date {
            font-size: 13px;
            color: #64748b;
            margin-bottom: 6px;
        }

        .timeline-status {
            font-size: 18px;
            font-weight: bold;
            color: #0f172a;
            margin-bottom: 6px;
        }

        .timeline-remarks {
            color: #374151;
            line-height: 1.5;
            margin-bottom: 6px;
        }

        .timeline-route {
            font-size: 13px;
            color: #64748b;
        }

        .footer {
            background: #0f172a;
            color: #cbd5e1;
            text-align: center;
            padding: 18px;
            font-size: 14px;
            margin-top: 40px;
        }

        @media (max-width: 960px) {
            .content-grid {
                grid-template-columns: 1fr;
            }

            .info-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 640px) {
            .topbar {
                padding: 16px 20px;
            }

            .page-header h2 {
                font-size: 28px;
            }

            .search-form {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<header class="topbar">
    <div class="brand">
        <div class="brand-logo">
            <img src="../assets/images/logo.png" alt="DepEd Logo" onerror="this.style.display='none'; this.parentNode.innerHTML='<span style=&quot;color:#1d4ed8;font-weight:bold;font-size:18px;&quot;>DT</span>';">
        </div>
        <div class="brand-text">
            <h1>DepEd Talisay City</h1>
            <p>DOCUMENT TRACKING SYSTEM</p>
        </div>
    </div>

    <a href="../depedtracker.php" class="top-link">Back to Tracking Search</a>
</header>

<div class="page-wrap">

    <div class="search-card">
        <form action="track.php" method="GET" class="search-form">
            <input
                type="text"
                name="ref"
                class="search-input"
                placeholder="Enter Reference Number"
                value="<?php echo e($ref); ?>"
                required
            >
            <button type="submit" class="search-btn">Track Now</button>
        </form>
    </div>

    <?php if ($error_message !== '') : ?>
        <div class="error-card">
            <div class="error-title">Tracking Record Not Found</div>
            <div class="error-text"><?php echo e($error_message); ?></div>
            <a href="../depedtracker.php" class="back-btn">Return to Search</a>
        </div>
    <?php else : ?>

        <div class="page-header">
            <h2>Tracking Result</h2>
            <p>View the latest status and movement history of your submitted document.</p>
        </div>

        <div class="content-grid">
            <div class="info-card">
                <h3>Document Information</h3>

                <div class="info-grid">
                    <div class="info-item">
                        <label>Reference Number</label>
                        <div class="value"><?php echo e($document['reference_no']); ?></div>
                    </div>

                    <div class="info-item">
                        <label>Current Status</label>
                        <div class="value">
                            <span class="status-badge" style="<?php echo getStatusStyle($document['status']); ?>">
                                <?php echo e($document['status']); ?>
                            </span>
                        </div>
                    </div>

                    <div class="info-item">
                        <label>Document Type</label>
                        <div class="value"><?php echo e($document['document_type_name'] ?: 'N/A'); ?></div>
                    </div>

                    <div class="info-item">
                        <label>Current Office</label>
                        <div class="value"><?php echo e($document['department_name'] ?: 'Records Office'); ?></div>
                    </div>

                    <div class="info-item">
                        <label>Organization</label>
                        <div class="value">
                            <?php
                            if (!empty($document['org_name'])) {
                                echo e($document['org_name']);
                            } elseif (!empty($document['other_organization'])) {
                                echo e($document['other_organization']);
                            } else {
                                echo 'N/A';
                            }
                            ?>
                        </div>
                    </div>

                    <div class="info-item">
                        <label>Submitted By</label>
                        <div class="value"><?php echo e($document['submitted_by']); ?></div>
                    </div>

                    <div class="info-item">
                        <label>Date Received</label>
                        <div class="value"><?php echo formatDateTime($document['date_received']); ?></div>
                    </div>

                    <div class="info-item">
                        <label>Contact Email</label>
                        <div class="value"><?php echo e($document['client_email']); ?></div>
                    </div>
                </div>

                <div style="margin-top:22px;">
                    <label style="display:block; font-size:12px; font-weight:bold; color:#64748b; letter-spacing:0.8px; margin-bottom:8px; text-transform:uppercase;">
                        Subject / Description
                    </label>
                    <div class="description-box"><?php echo e($document['description']); ?></div>
                </div>
            </div>

            <div class="timeline-card">
                <h3>Routing Timeline</h3>

                <?php if ($logs && mysqli_num_rows($logs) > 0) : ?>
                    <div class="timeline-list">
                        <?php while ($log = mysqli_fetch_assoc($logs)) : ?>
                            <div class="timeline-item">
                                <div class="timeline-date"><?php echo formatDateTime($log['action_datetime']); ?></div>
                                <div class="timeline-status"><?php echo e($log['status']); ?></div>

                                <?php if (!empty($log['remarks'])) : ?>
                                    <div class="timeline-remarks"><?php echo e($log['remarks']); ?></div>
                                <?php endif; ?>

                                <?php if (!empty($log['from_department_name']) || !empty($log['to_department_name'])) : ?>
                                    <div class="timeline-route">
                                        Route:
                                        <?php echo e($log['from_department_name'] ?: 'N/A'); ?>
                                        →
                                        <?php echo e($log['to_department_name'] ?: 'N/A'); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else : ?>
                    <p style="color:#64748b; margin:0;">No movement history available yet.</p>
                <?php endif; ?>
            </div>
        </div>

    <?php endif; ?>
</div>

<footer class="footer">
    © <?php echo date('Y'); ?> Department of Education - Talisay City Division. All rights reserved.
</footer>

</body>
</html>