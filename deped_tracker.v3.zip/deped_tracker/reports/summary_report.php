<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

$allowed_roles = [
    'Administrator',
    'Records Personnel',
    'Accounting',
    'Budget',
    'Human Resource',
    'Property',
    'Administrative Officer',
    'SDS Secretary',
    'ASDS Secretary',
    'SGOD Secretary',
    'CID Secretary'
];

if (!hasRole($allowed_roles)) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

$current_role = $_SESSION['role'] ?? '';
$current_department_id = (int) ($_SESSION['department_id'] ?? 0);

$is_admin = ($current_role === 'Administrator');
$is_records = ($current_role === 'Records Personnel');

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/
$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');
$status_filter = trim($_GET['status'] ?? '');
$document_type_filter = trim($_GET['document_type_id'] ?? '');
$department_filter = trim($_GET['department_id'] ?? '');

/*
|--------------------------------------------------------------------------
| Dropdown data
|--------------------------------------------------------------------------
*/
$document_types = mysqli_query($conn, "
    SELECT document_type_id, document_type_name
    FROM document_types
    WHERE status = 'Active'
    ORDER BY document_type_name ASC
");

$departments = mysqli_query($conn, "
    SELECT department_id, department_name
    FROM departments
    WHERE status = 'Active'
    ORDER BY department_name ASC
");

/*
|--------------------------------------------------------------------------
| Build report conditions
|--------------------------------------------------------------------------
*/
$where_conditions = [];
$where_conditions[] = "1=1";

if ($date_from !== '') {
    $date_from_escaped = mysqli_real_escape_string($conn, $date_from);
    $where_conditions[] = "DATE(d.date_received) >= '$date_from_escaped'";
}

if ($date_to !== '') {
    $date_to_escaped = mysqli_real_escape_string($conn, $date_to);
    $where_conditions[] = "DATE(d.date_received) <= '$date_to_escaped'";
}

if ($status_filter !== '') {
    $status_escaped = mysqli_real_escape_string($conn, $status_filter);
    $where_conditions[] = "d.status = '$status_escaped'";
}

if ($document_type_filter !== '') {
    $document_type_id = (int) $document_type_filter;
    if ($document_type_id > 0) {
        $where_conditions[] = "d.document_type_id = '$document_type_id'";
    }
}

/*
|--------------------------------------------------------------------------
| Role-based scope
|--------------------------------------------------------------------------
*/
if ($is_admin || $is_records) {
    if ($department_filter !== '') {
        $department_id = (int) $department_filter;
        if ($department_id > 0) {
            $where_conditions[] = "d.current_department_id = '$department_id'";
        }
    }
} else {
    $where_conditions[] = "d.current_department_id = '$current_department_id'";
}

$where_sql = implode(' AND ', $where_conditions);

/*
|--------------------------------------------------------------------------
| Fetch report data
|--------------------------------------------------------------------------
*/
$report_query = "
    SELECT
        d.*,
        dt.document_type_name,
        o.org_name,
        dep.department_name
    FROM documents d
    LEFT JOIN document_types dt ON d.document_type_id = dt.document_type_id
    LEFT JOIN organization o ON d.org_id = o.org_id
    LEFT JOIN departments dep ON d.current_department_id = dep.department_id
    WHERE $where_sql
    ORDER BY d.date_received DESC, d.document_id DESC
";

$report_result = mysqli_query($conn, $report_query);

if (!$report_result) {
    die("Error generating report: " . mysqli_error($conn));
}

/*
|--------------------------------------------------------------------------
| Summary counts based on filtered result
|--------------------------------------------------------------------------
*/
$summary_total = 0;
$summary_received = 0;
$summary_in_process = 0;
$summary_released = 0;

$summary_query = mysqli_query($conn, "
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN d.status = 'Received' THEN 1 ELSE 0 END) AS received_count,
        SUM(CASE WHEN d.status = 'In Process' THEN 1 ELSE 0 END) AS in_process_count,
        SUM(CASE WHEN d.status = 'Released' THEN 1 ELSE 0 END) AS released_count
    FROM documents d
    WHERE $where_sql
");

if ($summary_query && mysqli_num_rows($summary_query) > 0) {
    $summary = mysqli_fetch_assoc($summary_query);
    $summary_total = $summary['total'] ?? 0;
    $summary_received = $summary['received_count'] ?? 0;
    $summary_in_process = $summary['in_process_count'] ?? 0;
    $summary_released = $summary['released_count'] ?? 0;
}

/*
|--------------------------------------------------------------------------
| Back link
|--------------------------------------------------------------------------
*/
$back_link = '../records/dashboard.php';
if ($is_admin) {
    $back_link = '../admin/dashboard.php';
} elseif (!$is_records) {
    $back_link = '../staff/dashboard.php';
}
?>

<div class="main-content">

    <style>
        .report-hero {
            background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 55%, #3b82f6 100%);
            color: #ffffff;
            border-radius: 18px;
            padding: 24px 26px;
            box-shadow: 0 16px 30px rgba(29, 78, 216, 0.18);
            margin-bottom: 24px;
        }

        .report-hero h2 {
            margin: 0 0 8px 0;
            font-size: 32px;
        }

        .report-hero p {
            margin: 0;
            color: rgba(255,255,255,0.92);
            line-height: 1.6;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
            gap: 18px;
            margin-bottom: 24px;
        }

        .summary-card {
            background: #ffffff;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 8px 22px rgba(15, 23, 42, 0.07);
            border: 1px solid #e5e7eb;
            border-left: 5px solid var(--accent, #1d4ed8);
        }

        .summary-label {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .summary-value {
            font-size: 34px;
            font-weight: bold;
            color: #0f172a;
            line-height: 1;
        }

        .status-chip {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 600;
        }
    </style>

    <div class="report-hero">
        <h2>Summary Report</h2>
        <p>
            View document transactions filtered by date range, status, document type, and department scope.
        </p>
    </div>

    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:20px; flex-wrap:wrap; margin-bottom:24px;">
        <div>
            <h3 style="margin:0; font-size:28px; color:#0f172a;">Filtered Transaction Summary</h3>
            <p style="margin:8px 0 0 0; color:#64748b;">
                <?php echo ($is_admin || $is_records) ? 'You can generate reports across the system.' : 'You can only view reports within your assigned department.'; ?>
            </p>
        </div>

        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <a href="<?php echo $back_link; ?>" class="btn btn-secondary">Back</a>
        </div>
    </div>

    <div class="summary-grid">
        <div class="summary-card" style="--accent:#1d4ed8;">
            <div class="summary-label">Total Transactions</div>
            <div class="summary-value"><?php echo e($summary_total); ?></div>
        </div>

        <div class="summary-card" style="--accent:#0ea5e9;">
            <div class="summary-label">Received</div>
            <div class="summary-value"><?php echo e($summary_received); ?></div>
        </div>

        <div class="summary-card" style="--accent:#f59e0b;">
            <div class="summary-label">In Process</div>
            <div class="summary-value"><?php echo e($summary_in_process); ?></div>
        </div>

        <div class="summary-card" style="--accent:#16a34a;">
            <div class="summary-label">Released</div>
            <div class="summary-value"><?php echo e($summary_released); ?></div>
        </div>
    </div>

    <div class="page-card" style="margin-bottom:24px;">
        <form method="GET" style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr <?php echo ($is_admin || $is_records) ? '1fr ' : ''; ?>1.7fr; gap:14px; align-items:end;">

            <div>
                <label class="label">Date From</label>
                <input
                    type="date"
                    name="date_from"
                    class="form-control"
                    value="<?php echo e($date_from); ?>"
                >
            </div>

            <div>
                <label class="label">Date To</label>
                <input
                    type="date"
                    name="date_to"
                    class="form-control"
                    value="<?php echo e($date_to); ?>"
                >
            </div>

            <div>
                <label class="label">Status</label>
                <select name="status" class="form-control">
                    <option value="">All Statuses</option>
                    <option value="Received" <?php echo ($status_filter === 'Received') ? 'selected' : ''; ?>>Received</option>
                    <option value="Forwarded" <?php echo ($status_filter === 'Forwarded') ? 'selected' : ''; ?>>Forwarded</option>
                    <option value="In Process" <?php echo ($status_filter === 'In Process') ? 'selected' : ''; ?>>In Process</option>
                    <option value="Approved" <?php echo ($status_filter === 'Approved') ? 'selected' : ''; ?>>Approved</option>
                    <option value="For Releasing" <?php echo ($status_filter === 'For Releasing') ? 'selected' : ''; ?>>For Releasing</option>
                    <option value="Released" <?php echo ($status_filter === 'Released') ? 'selected' : ''; ?>>Released</option>
                </select>
            </div>

            <div>
                <label class="label">Document Type</label>
                <select name="document_type_id" class="form-control">
                    <option value="">All Types</option>
                    <?php if ($document_types): ?>
                        <?php while ($type = mysqli_fetch_assoc($document_types)): ?>
                            <option value="<?php echo $type['document_type_id']; ?>" <?php echo ($document_type_filter == $type['document_type_id']) ? 'selected' : ''; ?>>
                                <?php echo e($type['document_type_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </select>
            </div>

            <?php if ($is_admin || $is_records): ?>
                <div>
                    <label class="label">Department</label>
                    <select name="department_id" class="form-control">
                        <option value="">All Departments</option>
                        <?php if ($departments): ?>
                            <?php while ($dept = mysqli_fetch_assoc($departments)): ?>
                                <option value="<?php echo $dept['department_id']; ?>" <?php echo ($department_filter == $dept['department_id']) ? 'selected' : ''; ?>>
                                    <?php echo e($dept['department_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>
            <?php endif; ?>

            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <button type="submit" class="btn btn-primary">Generate</button>
                <a href="summary_report.php" class="btn btn-secondary">Reset</a>

                <a
                    href="export_pdf.php?date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>&status=<?php echo urlencode($status_filter); ?>&document_type_id=<?php echo urlencode($document_type_filter); ?>&department_id=<?php echo urlencode($department_filter); ?>&mode=preview"
                    class="btn btn-dark"
                    target="_blank"
                >
                    Preview PDF
                </a>

                <a
                    href="export_pdf.php?date_from=<?php echo urlencode($date_from); ?>&date_to=<?php echo urlencode($date_to); ?>&status=<?php echo urlencode($status_filter); ?>&document_type_id=<?php echo urlencode($document_type_filter); ?>&department_id=<?php echo urlencode($department_filter); ?>&mode=download"
                    class="btn btn-secondary"
                    target="_blank"
                >
                    Download PDF
                </a>
            </div>
        </form>
    </div>

    <div class="page-card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
            <h3 style="margin:0; color:#0f172a;">Summary Report Results</h3>
            <div style="font-size:14px; color:#64748b;">
                Total Result: <strong><?php echo mysqli_num_rows($report_result); ?></strong>
            </div>
        </div>

        <?php if (mysqli_num_rows($report_result) > 0): ?>
            <div style="overflow-x:auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Reference No.</th>
                            <th>Document Type</th>
                            <th>Organization</th>
                            <th>Submitted By</th>
                            <th>Status</th>
                            <th>Current Office</th>
                            <th>Date Received</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($report_result)): ?>
                            <?php
                                $organization_name = 'N/A';
                                if (!empty($row['org_name'])) {
                                    $organization_name = $row['org_name'];
                                } elseif (!empty($row['other_organization'])) {
                                    $organization_name = $row['other_organization'];
                                }
                            ?>
                            <tr>
                                <td><strong><?php echo e($row['reference_no']); ?></strong></td>
                                <td><?php echo e($row['document_type_name'] ?: 'N/A'); ?></td>
                                <td><?php echo e($organization_name); ?></td>
                                <td><?php echo e($row['submitted_by']); ?></td>
                                <td>
                                    <span class="status-chip" style="<?php echo getStatusBadgeStyle($row['status']); ?>">
                                        <?php echo e($row['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo e($row['department_name'] ?: 'Records'); ?></td>
                                <td><?php echo formatDateTime($row['date_received']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div style="padding:20px 0; color:#64748b;">
                No records found for the selected filters.
            </div>
        <?php endif; ?>
    </div>

</div>

<?php include '../includes/footer.php'; ?>