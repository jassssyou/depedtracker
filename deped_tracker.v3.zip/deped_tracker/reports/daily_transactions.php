<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole([
    'Administrator',
    'Records Personnel',
    'Accounting',
    'Budget',
    'Human Resource',
    'Property',
    'Administrative Officer',
    'SDS Secretary',
    'ASDS Secretary',
    'SGOD Secretary',
    'CID Secretary'
])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

$current_role = $_SESSION['role'] ?? '';
$current_department_id = (int) ($_SESSION['department_id'] ?? 0);

$is_admin = ($current_role === 'Administrator');
$is_records = ($current_role === 'Records Personnel');

/*
|--------------------------------------------------------------------------
| Selected date (default today)
|--------------------------------------------------------------------------
*/
$selected_date = $_GET['date'] ?? date('Y-m-d');
$selected_date_escaped = mysqli_real_escape_string($conn, $selected_date);

/*
|--------------------------------------------------------------------------
| Role scope
|--------------------------------------------------------------------------
*/
$role_condition = "1=1";

if (!($is_admin || $is_records)) {
    $role_condition = "d.current_department_id = '$current_department_id'";
}

/*
|--------------------------------------------------------------------------
| Fetch daily records
|--------------------------------------------------------------------------
*/
$query = "
    SELECT
        d.*,
        dt.document_type_name,
        o.org_name,
        dep.department_name
    FROM documents d
    LEFT JOIN document_types dt ON d.document_type_id = dt.document_type_id
    LEFT JOIN organization o ON d.org_id = o.org_id
    LEFT JOIN departments dep ON d.current_department_id = dep.department_id
    WHERE DATE(d.date_received) = '$selected_date_escaped'
    AND $role_condition
    ORDER BY d.date_received DESC
";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Error: " . mysqli_error($conn));
}

/*
|--------------------------------------------------------------------------
| Summary counts
|--------------------------------------------------------------------------
*/
$summary_query = mysqli_query($conn, "
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN status='Received' THEN 1 ELSE 0 END) AS received,
        SUM(CASE WHEN status='Forwarded' THEN 1 ELSE 0 END) AS forwarded,
        SUM(CASE WHEN status='In Process' THEN 1 ELSE 0 END) AS in_process,
        SUM(CASE WHEN status='For Releasing' THEN 1 ELSE 0 END) AS releasing,
        SUM(CASE WHEN status='Released' THEN 1 ELSE 0 END) AS released
    FROM documents d
    WHERE DATE(d.date_received) = '$selected_date_escaped'
    AND $role_condition
");

$summary = mysqli_fetch_assoc($summary_query);
?>

<div class="main-content">

<style>
.daily-hero {
    background: linear-gradient(135deg,#1d4ed8,#3b82f6);
    color:#fff;
    padding:22px;
    border-radius:16px;
    margin-bottom:20px;
}
.summary-grid {
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:16px;
    margin-bottom:20px;
}
.summary-card {
    background:#fff;
    padding:18px;
    border-radius:12px;
    box-shadow:0 4px 12px rgba(0,0,0,0.06);
}
.summary-title {
    font-size:13px;
    color:#64748b;
}
.summary-value {
    font-size:26px;
    font-weight:bold;
    color:#0f172a;
}
</style>

<!-- HERO -->
<div class="daily-hero">
    <h2>Daily Transactions</h2>
    <p>Showing records for <strong><?php echo date('F d, Y', strtotime($selected_date)); ?></strong></p>
</div>

<!-- DATE FILTER -->
<div class="page-card" style="margin-bottom:20px;">
    <form method="GET" style="display:flex; gap:10px; align-items:end;">
        <div>
            <label class="label">Select Date</label>
            <input type="date" name="date" class="form-control"
                   value="<?php echo e($selected_date); ?>">
        </div>

        <button class="btn btn-primary">Filter</button>
        <a href="daily_transactions.php" class="btn btn-secondary">Today</a>
    </form>
</div>

<!-- SUMMARY -->
<div class="summary-grid">
    <div class="summary-card">
        <div class="summary-title">Total</div>
        <div class="summary-value"><?php echo $summary['total'] ?? 0; ?></div>
    </div>
    <div class="summary-card">
        <div class="summary-title">Received</div>
        <div class="summary-value"><?php echo $summary['received'] ?? 0; ?></div>
    </div>
    <div class="summary-card">
        <div class="summary-title">Forwarded</div>
        <div class="summary-value"><?php echo $summary['forwarded'] ?? 0; ?></div>
    </div>
    <div class="summary-card">
        <div class="summary-title">In Process</div>
        <div class="summary-value"><?php echo $summary['in_process'] ?? 0; ?></div>
    </div>
    <div class="summary-card">
        <div class="summary-title">For Releasing</div>
        <div class="summary-value"><?php echo $summary['releasing'] ?? 0; ?></div>
    </div>
    <div class="summary-card">
        <div class="summary-title">Released</div>
        <div class="summary-value"><?php echo $summary['released'] ?? 0; ?></div>
    </div>
</div>

<!-- TABLE -->
<div class="page-card">
    <h3>Transaction List</h3>

    <?php if (mysqli_num_rows($result) > 0): ?>
    <table class="table">
        <thead>
            <tr>
                <th>Reference</th>
                <th>Type</th>
                <th>Submitted By</th>
                <th>Status</th>
                <th>Office</th>
                <th>Time</th>
            </tr>
        </thead>

        <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><strong><?php echo e($row['reference_no']); ?></strong></td>
            <td><?php echo e($row['document_type_name'] ?? 'N/A'); ?></td>
            <td><?php echo e($row['submitted_by']); ?></td>
            <td>
                <span class="status-badge" style="<?php echo getStatusBadgeStyle($row['status']); ?>">
                    <?php echo e($row['status']); ?>
                </span>
            </td>
            <td><?php echo e($row['department_name'] ?? 'Records'); ?></td>
            <td><?php echo date('h:i A', strtotime($row['date_received'])); ?></td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p style="color:#64748b;">No records for this date.</p>
    <?php endif; ?>
</div>

</div>

<?php include '../includes/footer.php'; ?>