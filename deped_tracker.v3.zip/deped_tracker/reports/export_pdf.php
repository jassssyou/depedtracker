<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

require('../libs/fpdf/fpdf.php');

$allowed_roles = [
    'Administrator',
    'Records Personnel',
    'Accounting',
    'Budget',
    'Human Resource',
    'Property',
    'Administrative Officer',
    'SDS Secretary',
    'ASDS Secretary',
    'SGOD Secretary',
    'CID Secretary'
];

if (!hasRole($allowed_roles)) {
    die("Access denied.");
}

date_default_timezone_set('Asia/Manila');

$current_role = $_SESSION['role'] ?? '';
$current_department_id = (int) ($_SESSION['department_id'] ?? 0);
$exported_by = $_SESSION['fullname'] ?? 'System User';

$is_admin = ($current_role === 'Administrator');
$is_records = ($current_role === 'Records Personnel');

/*
|--------------------------------------------------------------------------
| Output mode
|--------------------------------------------------------------------------
*/
$mode = $_GET['mode'] ?? 'preview'; // preview | download

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/
$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');
$status_filter = trim($_GET['status'] ?? '');
$document_type_filter = trim($_GET['document_type_id'] ?? '');
$department_filter = trim($_GET['department_id'] ?? '');

$where_conditions = [];
$where_conditions[] = "1=1";

if ($date_from !== '') {
    $date_from_escaped = mysqli_real_escape_string($conn, $date_from);
    $where_conditions[] = "DATE(d.date_received) >= '$date_from_escaped'";
}

if ($date_to !== '') {
    $date_to_escaped = mysqli_real_escape_string($conn, $date_to);
    $where_conditions[] = "DATE(d.date_received) <= '$date_to_escaped'";
}

if ($status_filter !== '') {
    $status_escaped = mysqli_real_escape_string($conn, $status_filter);
    $where_conditions[] = "d.status = '$status_escaped'";
}

if ($document_type_filter !== '') {
    $document_type_id = (int) $document_type_filter;
    if ($document_type_id > 0) {
        $where_conditions[] = "d.document_type_id = '$document_type_id'";
    }
}

/*
|--------------------------------------------------------------------------
| Role-based scope
|--------------------------------------------------------------------------
*/
if ($is_admin || $is_records) {
    if ($department_filter !== '') {
        $department_id = (int) $department_filter;
        if ($department_id > 0) {
            $where_conditions[] = "d.current_department_id = '$department_id'";
        }
    }
} else {
    $where_conditions[] = "d.current_department_id = '$current_department_id'";
}

$where_sql = implode(" AND ", $where_conditions);

/*
|--------------------------------------------------------------------------
| Fetch data
|--------------------------------------------------------------------------
*/
$query = "
    SELECT
        d.reference_no,
        d.submitted_by,
        d.status,
        d.date_received,
        dt.document_type_name,
        o.org_name,
        d.other_organization,
        dep.department_name
    FROM documents d
    LEFT JOIN document_types dt ON d.document_type_id = dt.document_type_id
    LEFT JOIN organization o ON d.org_id = o.org_id
    LEFT JOIN departments dep ON d.current_department_id = dep.department_id
    WHERE $where_sql
    ORDER BY d.date_received DESC, d.document_id DESC
";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Error generating report: " . mysqli_error($conn));
}

/*
|--------------------------------------------------------------------------
| Resolve names for filter display
|--------------------------------------------------------------------------
*/
$document_type_name = '';
$department_name = '';

if ($document_type_filter !== '') {
    $document_type_id = (int) $document_type_filter;
    $type_query = mysqli_query($conn, "
        SELECT document_type_name
        FROM document_types
        WHERE document_type_id = '$document_type_id'
        LIMIT 1
    ");
    if ($type_query && mysqli_num_rows($type_query) > 0) {
        $document_type_name = mysqli_fetch_assoc($type_query)['document_type_name'] ?? '';
    }
}

if (($is_admin || $is_records) && $department_filter !== '') {
    $department_id = (int) $department_filter;
    $dept_query = mysqli_query($conn, "
        SELECT department_name
        FROM departments
        WHERE department_id = '$department_id'
        LIMIT 1
    ");
    if ($dept_query && mysqli_num_rows($dept_query) > 0) {
        $department_name = mysqli_fetch_assoc($dept_query)['department_name'] ?? '';
    }
}

/*
|--------------------------------------------------------------------------
| PDF class
|--------------------------------------------------------------------------
*/
class PDF extends FPDF
{
    public $logoPath = '';
    public $exportedBy = '';
    public $exportedAt = '';

    function Header()
    {
        // Logo
        if (!empty($this->logoPath) && file_exists($this->logoPath)) {
            $this->Image($this->logoPath, 10, 8, 22);
        }

        // Title block
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(0, 7, 'DepEd Talisay Document Tracking System', 0, 1, 'C');

        $this->SetFont('Arial', '', 11);
        $this->Cell(0, 6, 'Summary Report', 0, 1, 'C');

        $this->Ln(3);

        // Export info
        $this->SetFont('Arial', '', 9);
        $this->Cell(0, 5, 'Exported by: ' . $this->exportedBy, 0, 1, 'R');
        $this->Cell(0, 5, 'Exported at: ' . $this->exportedAt, 0, 1, 'R');

        $this->Ln(3);
    }

    function Footer()
    {
        $this->SetY(-12);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 5, 'Page ' . $this->PageNo(), 0, 0, 'C');
    }
}

/*
|--------------------------------------------------------------------------
| Create PDF
|--------------------------------------------------------------------------
*/
$pdf = new PDF('L', 'mm', 'A4');
$pdf->logoPath = '../assets/images/logo.png';
$pdf->exportedBy = $exported_by;
$pdf->exportedAt = date('F j, Y h:i A');
$pdf->AddPage();
$pdf->SetAutoPageBreak(true, 15);

/*
|--------------------------------------------------------------------------
| Filter display
|--------------------------------------------------------------------------
*/
$pdf->SetFont('Arial', '', 10);

if ($date_from !== '' || $date_to !== '') {
    $display_date_from = $date_from !== '' ? $date_from : 'Any';
    $display_date_to = $date_to !== '' ? $date_to : 'Any';
    $pdf->Cell(0, 6, "Date Range: $display_date_from to $display_date_to", 0, 1);
}

if ($status_filter !== '') {
    $pdf->Cell(0, 6, "Status: $status_filter", 0, 1);
}

if ($document_type_name !== '') {
    $pdf->Cell(0, 6, "Document Type: $document_type_name", 0, 1);
}

if ($department_name !== '') {
    $pdf->Cell(0, 6, "Department: $department_name", 0, 1);
} elseif (!($is_admin || $is_records)) {
    $pdf->Cell(0, 6, "Department Scope: Assigned Department Only", 0, 1);
}

$pdf->Ln(4);

/*
|--------------------------------------------------------------------------
| Table header
|--------------------------------------------------------------------------
*/
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(230, 238, 250);

$pdf->Cell(35, 8, 'Reference No.', 1, 0, 'C', true);
$pdf->Cell(42, 8, 'Document Type', 1, 0, 'C', true);
$pdf->Cell(55, 8, 'Organization', 1, 0, 'C', true);
$pdf->Cell(45, 8, 'Submitted By', 1, 0, 'C', true);
$pdf->Cell(30, 8, 'Status', 1, 0, 'C', true);
$pdf->Cell(40, 8, 'Current Office', 1, 0, 'C', true);
$pdf->Cell(38, 8, 'Date Received', 1, 1, 'C', true);

/*
|--------------------------------------------------------------------------
| Table body
|--------------------------------------------------------------------------
*/
$pdf->SetFont('Arial', '', 8);

$row_count = 0;

while ($row = mysqli_fetch_assoc($result)) {
    $organization_name = 'N/A';

    if (!empty($row['org_name'])) {
        $organization_name = $row['org_name'];
    } elseif (!empty($row['other_organization'])) {
        $organization_name = $row['other_organization'];
    }

    $current_office = !empty($row['department_name']) ? $row['department_name'] : 'Records';

    $pdf->Cell(35, 8, substr($row['reference_no'], 0, 22), 1);
    $pdf->Cell(42, 8, substr($row['document_type_name'] ?? 'N/A', 0, 26), 1);
    $pdf->Cell(55, 8, substr($organization_name, 0, 34), 1);
    $pdf->Cell(45, 8, substr($row['submitted_by'], 0, 28), 1);
    $pdf->Cell(30, 8, substr($row['status'], 0, 18), 1);
    $pdf->Cell(40, 8, substr($current_office, 0, 24), 1);
    $pdf->Cell(38, 8, date('M d, Y h:i A', strtotime($row['date_received'])), 1);
    $pdf->Ln();

    $row_count++;
}

/*
|--------------------------------------------------------------------------
| Footer summary
|--------------------------------------------------------------------------
*/
$pdf->Ln(4);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 6, "Total Records: $row_count", 0, 1);

/*
|--------------------------------------------------------------------------
| Output
|--------------------------------------------------------------------------
*/
$filename = 'summary_report_' . date('Ymd_His') . '.pdf';

if ($mode === 'download') {
    $pdf->Output('D', $filename);
} else {
    $pdf->Output('I', $filename);
}
exit();