<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator', 'Records Personnel'])) {
    echo "<script>alert('You do not have permission to access this page.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/
$search = trim($_GET['search'] ?? '');
$status_filter = trim($_GET['status'] ?? '');
$date_filter = trim($_GET['date_received'] ?? '');

$where_conditions = [];
$where_conditions[] = "1=1";

if ($search !== '') {
    $search_escaped = mysqli_real_escape_string($conn, $search);
    $where_conditions[] = "(
        d.reference_no LIKE '%$search_escaped%' OR
        d.submitted_by LIKE '%$search_escaped%' OR
        d.client_email LIKE '%$search_escaped%' OR
        d.description LIKE '%$search_escaped%'
    )";
}

if ($status_filter !== '') {
    $status_escaped = mysqli_real_escape_string($conn, $status_filter);
    $where_conditions[] = "d.status = '$status_escaped'";
}

if ($date_filter !== '') {
    $date_escaped = mysqli_real_escape_string($conn, $date_filter);
    $where_conditions[] = "DATE(d.date_received) = '$date_escaped'";
}

$where_sql = implode(' AND ', $where_conditions);

/*
|--------------------------------------------------------------------------
| Fetch documents
|--------------------------------------------------------------------------
*/
$query = "
    SELECT
        d.*,
        dt.document_type_name,
        o.org_name,
        dep.department_name
    FROM documents d
    LEFT JOIN document_types dt ON d.document_type_id = dt.document_type_id
    LEFT JOIN organization o ON d.org_id = o.org_id
    LEFT JOIN departments dep ON d.current_department_id = dep.department_id
    WHERE $where_sql
    ORDER BY d.document_id DESC
";

$result = mysqli_query($conn, $query);

if (!$result) {
    die("Error fetching documents: " . mysqli_error($conn));
}

/*
|--------------------------------------------------------------------------
| Summary counts
|--------------------------------------------------------------------------
*/
$total_documents = 0;
$received_count = 0;
$forwarded_count = 0;
$in_process_count = 0;
$for_releasing_count = 0;
$released_count = 0;

$total_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents");
if ($total_query) {
    $row = mysqli_fetch_assoc($total_query);
    $total_documents = $row['total'] ?? 0;
}

$received_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status = 'Received'");
if ($received_query) {
    $row = mysqli_fetch_assoc($received_query);
    $received_count = $row['total'] ?? 0;
}

$forwarded_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status = 'Forwarded'");
if ($forwarded_query) {
    $row = mysqli_fetch_assoc($forwarded_query);
    $forwarded_count = $row['total'] ?? 0;
}

$in_process_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status = 'In Process'");
if ($in_process_query) {
    $row = mysqli_fetch_assoc($in_process_query);
    $in_process_count = $row['total'] ?? 0;
}

$for_releasing_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status = 'For Releasing'");
if ($for_releasing_query) {
    $row = mysqli_fetch_assoc($for_releasing_query);
    $for_releasing_count = $row['total'] ?? 0;
}

$released_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status = 'Released'");
if ($released_query) {
    $row = mysqli_fetch_assoc($released_query);
    $released_count = $row['total'] ?? 0;
}
?>

<div class="main-content">

    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:20px; flex-wrap:wrap; margin-bottom:24px;">
        <div>
            <h2 style="margin:0; font-size:32px; color:#0f172a;">Documents</h2>
            <p style="margin:8px 0 0 0; color:#64748b; font-size:15px;">
                Manage registered documents, review details, and forward them to the proper office.
            </p>
        </div>

        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <a href="register_document.php" class="btn btn-primary">+ Register Document</a>
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
            <a href="release.php" class="btn btn-dark">Release Queue</a>
        </div>
    </div>

    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(210px, 1fr)); gap:18px; margin-bottom:24px;">
        <div class="page-card" style="border-left:5px solid #1d4ed8;">
            <div style="font-size:14px; color:#64748b; margin-bottom:10px;">Total Documents</div>
            <div style="font-size:34px; font-weight:bold; color:#0f172a;"><?php echo e($total_documents); ?></div>
        </div>

        <div class="page-card" style="border-left:5px solid #0ea5e9;">
            <div style="font-size:14px; color:#64748b; margin-bottom:10px;">Received</div>
            <div style="font-size:34px; font-weight:bold; color:#0f172a;"><?php echo e($received_count); ?></div>
        </div>

        <div class="page-card" style="border-left:5px solid #8b5cf6;">
            <div style="font-size:14px; color:#64748b; margin-bottom:10px;">Forwarded</div>
            <div style="font-size:34px; font-weight:bold; color:#0f172a;"><?php echo e($forwarded_count); ?></div>
        </div>

        <div class="page-card" style="border-left:5px solid #f59e0b;">
            <div style="font-size:14px; color:#64748b; margin-bottom:10px;">In Process</div>
            <div style="font-size:34px; font-weight:bold; color:#0f172a;"><?php echo e($in_process_count); ?></div>
        </div>

        <div class="page-card" style="border-left:5px solid #14b8a6;">
            <div style="font-size:14px; color:#64748b; margin-bottom:10px;">For Releasing</div>
            <div style="font-size:34px; font-weight:bold; color:#0f172a;"><?php echo e($for_releasing_count); ?></div>
        </div>

        <div class="page-card" style="border-left:5px solid #16a34a;">
            <div style="font-size:14px; color:#64748b; margin-bottom:10px;">Released</div>
            <div style="font-size:34px; font-weight:bold; color:#0f172a;"><?php echo e($released_count); ?></div>
        </div>
    </div>

    <div class="page-card" style="margin-bottom:24px;">
        <form method="GET" style="display:grid; grid-template-columns:2fr 1fr 1fr 170px; gap:14px; align-items:end;">

            <div>
                <label class="label">Search</label>
                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="Reference no, submitted by, email, or description"
                    value="<?php echo e($search); ?>"
                >
            </div>

            <div>
                <label class="label">Status</label>
                <select name="status" class="form-control">
                    <option value="">All Statuses</option>
                    <option value="Received" <?php echo ($status_filter === 'Received') ? 'selected' : ''; ?>>Received</option>
                    <option value="Forwarded" <?php echo ($status_filter === 'Forwarded') ? 'selected' : ''; ?>>Forwarded</option>
                    <option value="In Process" <?php echo ($status_filter === 'In Process') ? 'selected' : ''; ?>>In Process</option>
                    <option value="Approved" <?php echo ($status_filter === 'Approved') ? 'selected' : ''; ?>>Approved</option>
                    <option value="For Releasing" <?php echo ($status_filter === 'For Releasing') ? 'selected' : ''; ?>>For Releasing</option>
                    <option value="Released" <?php echo ($status_filter === 'Released') ? 'selected' : ''; ?>>Released</option>
                </select>
            </div>

            <div>
                <label class="label">Date Received</label>
                <input
                    type="date"
                    name="date_received"
                    class="form-control"
                    value="<?php echo e($date_filter); ?>"
                >
            </div>

            <div style="display:flex; gap:8px;">
                <button type="submit" class="btn btn-primary" style="width:100%;">Filter</button>
                <a href="documents.php" class="btn btn-secondary" style="width:100%; text-align:center;">Reset</a>
            </div>
        </form>
    </div>

    <div class="page-card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
            <h3 style="margin:0; color:#0f172a;">Registered Documents</h3>
            <div style="font-size:14px; color:#64748b;">
                Total Result:
                <strong><?php echo mysqli_num_rows($result); ?></strong>
            </div>
        </div>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div style="overflow-x:auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Reference No.</th>
                            <th>Document Type</th>
                            <th>Organization</th>
                            <th>Submitted By</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Current Office</th>
                            <th>Date Received</th>
                            <th style="min-width:260px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <?php
                                $organization_name = 'N/A';
                                if (!empty($row['org_name'])) {
                                    $organization_name = $row['org_name'];
                                } elseif (!empty($row['other_organization'])) {
                                    $organization_name = $row['other_organization'];
                                }

                                $current_office = !empty($row['department_name']) ? $row['department_name'] : 'Records';

                                $can_forward = ($row['status'] === 'Received');
                                $can_release = ($row['status'] === 'For Releasing');
                            ?>
                            <tr>
                                <td><strong><?php echo e($row['reference_no']); ?></strong></td>
                                <td><?php echo e($row['document_type_name'] ?: 'N/A'); ?></td>
                                <td><?php echo e($organization_name); ?></td>
                                <td><?php echo e($row['submitted_by']); ?></td>
                                <td style="word-break:break-word;"><?php echo e($row['client_email']); ?></td>
                                <td>
                                    <span class="status-badge" style="<?php echo getStatusBadgeStyle($row['status']); ?>">
                                        <?php echo e($row['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo e($current_office); ?></td>
                                <td><?php echo formatDateTime($row['date_received']); ?></td>
                                <td>
                                    <div style="display:flex; flex-wrap:wrap; gap:8px;">
                                        <a href="document_view.php?id=<?php echo $row['document_id']; ?>"
                                           style="background:#dbeafe; color:#1d4ed8; padding:7px 12px; border-radius:8px; font-size:13px; font-weight:bold;">
                                            View
                                        </a>

                                        <?php if ($can_forward): ?>
                                            <a href="forward_document.php?id=<?php echo $row['document_id']; ?>"
                                               style="background:#eff6ff; color:#1e40af; padding:7px 12px; border-radius:8px; font-size:13px; font-weight:bold;">
                                                Forward
                                            </a>
                                        <?php endif; ?>

                                        <?php if ($can_release): ?>
                                            <a href="../staff/update_status.php?id=<?php echo $row['document_id']; ?>"
                                               style="background:#dcfce7; color:#166534; padding:7px 12px; border-radius:8px; font-size:13px; font-weight:bold;">
                                                Release
                                            </a>
                                        <?php endif; ?>

                                        <?php if (!empty($row['qr_code'])): ?>
                                            <a href="../<?php echo e($row['qr_code']); ?>" target="_blank"
                                               style="background:#e2e8f0; color:#0f172a; padding:7px 12px; border-radius:8px; font-size:13px; font-weight:bold;">
                                                QR
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div style="padding:20px 0; color:#64748b;">
                No documents found.
            </div>
        <?php endif; ?>
    </div>

</div>

<?php include '../includes/footer.php'; ?>