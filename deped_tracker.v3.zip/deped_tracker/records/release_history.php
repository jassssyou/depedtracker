<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator', 'Records Personnel'])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/
$search = trim($_GET['search'] ?? '');
$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');

$where_conditions = [];
$where_conditions[] = "d.status = 'Released'";

if ($search !== '') {
    $search_escaped = mysqli_real_escape_string($conn, $search);
    $where_conditions[] = "(
        d.reference_no LIKE '%$search_escaped%' OR
        d.submitted_by LIKE '%$search_escaped%' OR
        d.client_email LIKE '%$search_escaped%' OR
        d.description LIKE '%$search_escaped%' OR
        dt.document_type_name LIKE '%$search_escaped%' OR
        o.org_name LIKE '%$search_escaped%'
    )";
}

if ($date_from !== '') {
    $date_from_escaped = mysqli_real_escape_string($conn, $date_from);
    $where_conditions[] = "DATE(d.date_received) >= '$date_from_escaped'";
}

if ($date_to !== '') {
    $date_to_escaped = mysqli_real_escape_string($conn, $date_to);
    $where_conditions[] = "DATE(d.date_received) <= '$date_to_escaped'";
}

$where_sql = implode(' AND ', $where_conditions);

/*
|--------------------------------------------------------------------------
| Fetch released documents
|--------------------------------------------------------------------------
*/
$released_query = "
    SELECT
        d.*,
        dt.document_type_name,
        o.org_name,
        dep.department_name
    FROM documents d
    LEFT JOIN document_types dt ON d.document_type_id = dt.document_type_id
    LEFT JOIN organization o ON d.org_id = o.org_id
    LEFT JOIN departments dep ON d.current_department_id = dep.department_id
    WHERE $where_sql
    ORDER BY d.updated_at DESC, d.document_id DESC
";

$released = mysqli_query($conn, $released_query);

if (!$released) {
    die("Error fetching released documents: " . mysqli_error($conn));
}

/*
|--------------------------------------------------------------------------
| Summary counts
|--------------------------------------------------------------------------
*/
$total_released = 0;
$released_today = 0;
$released_this_month = 0;

$total_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status = 'Released'");
if ($total_query) {
    $total_released = mysqli_fetch_assoc($total_query)['total'] ?? 0;
}

$today_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status = 'Released' AND DATE(updated_at) = CURDATE()");
if ($today_query) {
    $released_today = mysqli_fetch_assoc($today_query)['total'] ?? 0;
}

$month_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM documents WHERE status = 'Released' AND MONTH(updated_at) = MONTH(CURDATE()) AND YEAR(updated_at) = YEAR(CURDATE())");
if ($month_query) {
    $released_this_month = mysqli_fetch_assoc($month_query)['total'] ?? 0;
}
?>

<div class="main-content">

    <style>
        .release-hero {
            background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 55%, #3b82f6 100%);
            color: #ffffff;
            border-radius: 18px;
            padding: 24px 26px;
            box-shadow: 0 16px 30px rgba(29, 78, 216, 0.18);
            margin-bottom: 24px;
        }

        .release-hero h2 {
            margin: 0 0 8px 0;
            font-size: 32px;
        }

        .release-hero p {
            margin: 0;
            color: rgba(255,255,255,0.92);
            line-height: 1.6;
        }

        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
            gap: 18px;
            margin-bottom: 24px;
        }

        .summary-card {
            background: #ffffff;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 8px 22px rgba(15, 23, 42, 0.07);
            border: 1px solid #e5e7eb;
            border-left: 5px solid var(--accent, #1d4ed8);
        }

        .summary-label {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .summary-value {
            font-size: 34px;
            font-weight: bold;
            color: #0f172a;
            line-height: 1;
        }

        .chip {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 600;
            background: #dcfce7;
            color: #166534;
        }
    </style>

    <div class="release-hero">
        <h2>Release History</h2>
        <p>
            View all completed and released document transactions for monitoring and reference.
        </p>
    </div>

    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:20px; flex-wrap:wrap; margin-bottom:24px;">
        <div>
            <h3 style="margin:0; font-size:28px; color:#0f172a;">Released Documents</h3>
            <p style="margin:8px 0 0 0; color:#64748b;">
                Search and review all released records.
            </p>
        </div>

        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <a href="release.php" class="btn btn-primary">Release Queue</a>
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </div>
    </div>

    <div class="summary-grid">
        <div class="summary-card" style="--accent:#16a34a;">
            <div class="summary-label">Total Released</div>
            <div class="summary-value"><?php echo e($total_released); ?></div>
        </div>

        <div class="summary-card" style="--accent:#0ea5e9;">
            <div class="summary-label">Released Today</div>
            <div class="summary-value"><?php echo e($released_today); ?></div>
        </div>

        <div class="summary-card" style="--accent:#8b5cf6;">
            <div class="summary-label">Released This Month</div>
            <div class="summary-value"><?php echo e($released_this_month); ?></div>
        </div>
    </div>

    <div class="page-card" style="margin-bottom:24px;">
        <form method="GET" style="display:grid; grid-template-columns:2fr 1fr 1fr 170px; gap:14px; align-items:end;">

            <div>
                <label class="label">Search</label>
                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="Reference no, submitted by, email, type, organization"
                    value="<?php echo e($search); ?>"
                >
            </div>

            <div>
                <label class="label">Date From</label>
                <input
                    type="date"
                    name="date_from"
                    class="form-control"
                    value="<?php echo e($date_from); ?>"
                >
            </div>

            <div>
                <label class="label">Date To</label>
                <input
                    type="date"
                    name="date_to"
                    class="form-control"
                    value="<?php echo e($date_to); ?>"
                >
            </div>

            <div style="display:flex; gap:8px;">
                <button type="submit" class="btn btn-primary" style="width:100%;">Filter</button>
                <a href="release_history.php" class="btn btn-secondary" style="width:100%; text-align:center;">Reset</a>
            </div>
        </form>
    </div>

    <div class="page-card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
            <h3 style="margin:0; color:#0f172a;">Release History List</h3>
            <div style="font-size:14px; color:#64748b;">
                Total Result: <strong><?php echo mysqli_num_rows($released); ?></strong>
            </div>
        </div>

        <?php if (mysqli_num_rows($released) > 0): ?>
            <div style="overflow-x:auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Reference</th>
                            <th>Document Type</th>
                            <th>Organization</th>
                            <th>Submitted By</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Date Received</th>
                            <th style="min-width:150px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($released)): ?>
                            <?php
                                $organization_name = 'N/A';
                                if (!empty($row['org_name'])) {
                                    $organization_name = $row['org_name'];
                                } elseif (!empty($row['other_organization'])) {
                                    $organization_name = $row['other_organization'];
                                }
                            ?>
                            <tr>
                                <td><strong><?php echo e($row['reference_no']); ?></strong></td>
                                <td><?php echo e($row['document_type_name'] ?: 'N/A'); ?></td>
                                <td><?php echo e($organization_name); ?></td>
                                <td><?php echo e($row['submitted_by']); ?></td>
                                <td style="word-break:break-word;"><?php echo e($row['client_email']); ?></td>
                                <td><span class="chip">Released</span></td>
                                <td><?php echo formatDateTime($row['date_received']); ?></td>
                                <td>
                                    <a href="document_view.php?id=<?php echo $row['document_id']; ?>" class="btn btn-secondary">
                                        View
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div style="padding:20px 0; color:#64748b;">
                No released documents found.
            </div>
        <?php endif; ?>
    </div>

</div>

<?php include '../includes/footer.php'; ?>