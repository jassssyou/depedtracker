<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator', 'Records Personnel'])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('Invalid request.'); window.location='documents.php';</script>";
    exit();
}

$document_id = (int) $_GET['id'];
$user_id = $_SESSION['user_id'];

/*
|--------------------------------------------------------------------------
| CONFIG
|--------------------------------------------------------------------------
*/
$records_department_id = 2;

/*
|--------------------------------------------------------------------------
| Fetch document
|--------------------------------------------------------------------------
*/
$doc_query = mysqli_query($conn, "
    SELECT 
        d.*, 
        dt.document_type_name, 
        o.org_name,
        dep.department_name AS current_department_name
    FROM documents d
    LEFT JOIN document_types dt ON d.document_type_id = dt.document_type_id
    LEFT JOIN organization o ON d.org_id = o.org_id
    LEFT JOIN departments dep ON d.current_department_id = dep.department_id
    WHERE d.document_id = '$document_id'
    LIMIT 1
");

if (!$doc_query) {
    die("Error fetching document: " . mysqli_error($conn));
}

$document = mysqli_fetch_assoc($doc_query);

if (!$document) {
    echo "<script>alert('Document not found.'); window.location='documents.php';</script>";
    exit();
}

/*
|--------------------------------------------------------------------------
| Prevent invalid forwarding
|--------------------------------------------------------------------------
*/
if ($document['status'] !== 'Received') {
    echo "<script>alert('Only RECEIVED documents can be forwarded.'); window.location='documents.php';</script>";
    exit();
}

/*
|--------------------------------------------------------------------------
| Get departments (exclude Records and ITO)
|--------------------------------------------------------------------------
*/
$departments = mysqli_query($conn, "
    SELECT department_id, department_name
    FROM departments
    WHERE status = 'Active'
      AND department_id != '$records_department_id'
      AND department_name != 'ITO'
    ORDER BY department_name ASC
");

if (!$departments) {
    die("Error fetching departments: " . mysqli_error($conn));
}

/*
|--------------------------------------------------------------------------
| Form values
|--------------------------------------------------------------------------
*/
$error = '';
$to_department = '';
$remarks = '';

/*
|--------------------------------------------------------------------------
| Submit forward
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $to_department = (int) ($_POST['department_id'] ?? 0);
    $remarks = trim($_POST['remarks'] ?? '');

    if ($to_department <= 0) {
        $error = "Please select a department.";
    } elseif ($to_department === (int)($document['current_department_id'] ?? 0)) {
        $error = "The document is already assigned to the selected department.";
    } elseif ($remarks === '') {
        $error = "Remarks is required.";
    } else {

        $remarks_escaped = mysqli_real_escape_string($conn, $remarks);

        /*
        |--------------------------------------------------------------------------
        | Update document
        |--------------------------------------------------------------------------
        */
        $update = mysqli_query($conn, "
            UPDATE documents
            SET
                status = 'Forwarded',
                current_department_id = '$to_department',
                updated_at = NOW()
            WHERE document_id = '$document_id'
        ");

        if (!$update) {
            die("Update failed: " . mysqli_error($conn));
        }

        /*
        |--------------------------------------------------------------------------
        | Insert log
        |--------------------------------------------------------------------------
        */
        $insert_log = mysqli_query($conn, "
            INSERT INTO document_logs (
                document_id,
                from_department,
                to_department,
                status,
                remarks,
                updated_by,
                action_datetime
            ) VALUES (
                '$document_id',
                '$records_department_id',
                '$to_department',
                'Forwarded',
                '$remarks_escaped',
                '$user_id',
                NOW()
            )
        ");

        if (!$insert_log) {
            die("Log insert failed: " . mysqli_error($conn));
        }

        /*
        |--------------------------------------------------------------------------
        | System log
        |--------------------------------------------------------------------------
        */
        $activity = mysqli_real_escape_string(
            $conn,
            "Forwarded document {$document['reference_no']} to department ID $to_department"
        );

        $insert_system_log = mysqli_query($conn, "
            INSERT INTO system_logs (user_id, activity, log_time)
            VALUES ('$user_id', '$activity', NOW())
        ");

        if (!$insert_system_log) {
            die("System log insert failed: " . mysqli_error($conn));
        }

        echo "<script>alert('Document forwarded successfully.'); window.location='documents.php';</script>";
        exit();
    }
}

/*
|--------------------------------------------------------------------------
| Resolve organization display
|--------------------------------------------------------------------------
*/
$organization_name = 'N/A';
if (!empty($document['org_name'])) {
    $organization_name = $document['org_name'];
} elseif (!empty($document['other_organization'])) {
    $organization_name = $document['other_organization'];
}

$current_office = !empty($document['current_department_name']) ? $document['current_department_name'] : 'Records';
?>

<div class="main-content">

<style>
.forward-layout {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 24px;
    align-items: start;
}

.forward-hero {
    background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 55%, #3b82f6 100%);
    color: #ffffff;
    border-radius: 18px;
    padding: 24px 26px;
    box-shadow: 0 16px 30px rgba(29, 78, 216, 0.18);
    margin-bottom: 24px;
}

.forward-hero h2 {
    margin: 0 0 8px 0;
    font-size: 32px;
}

.forward-hero p {
    margin: 0;
    color: rgba(255,255,255,0.92);
    line-height: 1.6;
}

.info-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
    color: #374151;
    font-size: 14px;
    line-height: 1.6;
}

.info-label {
    font-size: 12px;
    color: #64748b;
    text-transform: uppercase;
    font-weight: bold;
    margin-bottom: 4px;
}

@media (max-width: 980px) {
    .forward-layout {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="forward-hero">
    <h2>Forward Document</h2>
    <p>Assign this document to the correct department for processing and add routing remarks.</p>
</div>

<?php if ($error): ?>
    <div class="alert alert-error"><?php echo e($error); ?></div>
<?php endif; ?>

<div class="forward-layout">

    <div class="page-card">
        <h3 style="margin:0 0 18px 0; color:#0f172a;">Forwarding Form</h3>

        <form method="POST">

            <div style="margin-bottom:18px;">
                <label class="label">Select Department *</label>
                <select name="department_id" class="form-control" required>
                    <option value="">Select Department</option>
                    <?php while ($dept = mysqli_fetch_assoc($departments)): ?>
                        <option value="<?php echo $dept['department_id']; ?>" <?php echo ($to_department == $dept['department_id']) ? 'selected' : ''; ?>>
                            <?php echo e($dept['department_name']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div style="margin-bottom:20px;">
                <label class="label">Remarks *</label>
                <textarea
                    name="remarks"
                    class="form-control"
                    rows="5"
                    placeholder="Enter instructions or notes for the department..."
                    required
                ><?php echo e($remarks); ?></textarea>
            </div>

            <div style="display:flex; gap:10px; flex-wrap:wrap;">
                <button type="submit" class="btn btn-primary">Forward Document</button>
                <a href="document_view.php?id=<?php echo $document_id; ?>" class="btn btn-secondary">Back to Details</a>
            </div>

        </form>
    </div>

    <div class="page-card">
        <h3 style="margin:0 0 18px 0; color:#0f172a;">Document Summary</h3>

        <div class="info-list">

            <div>
                <div class="info-label">Reference No.</div>
                <div><strong><?php echo e($document['reference_no']); ?></strong></div>
            </div>

            <div>
                <div class="info-label">Document Type</div>
                <div><?php echo e($document['document_type_name'] ?: 'N/A'); ?></div>
            </div>

            <div>
                <div class="info-label">Organization</div>
                <div><?php echo e($organization_name); ?></div>
            </div>

            <div>
                <div class="info-label">Submitted By</div>
                <div><?php echo e($document['submitted_by']); ?></div>
            </div>

            <div>
                <div class="info-label">Current Status</div>
                <div>
                    <span class="status-badge" style="<?php echo getStatusBadgeStyle($document['status']); ?>">
                        <?php echo e($document['status']); ?>
                    </span>
                </div>
            </div>

            <div>
                <div class="info-label">Current Office</div>
                <div><?php echo e($current_office); ?></div>
            </div>

            <div>
                <div class="info-label">Description</div>
                <div style="border:1px solid #e5e7eb; background:#f8fbff; border-radius:12px; padding:12px;">
                    <?php echo nl2br(e($document['description'])); ?>
                </div>
            </div>

        </div>
    </div>

</div>

</div>

<?php include '../includes/footer.php'; ?>