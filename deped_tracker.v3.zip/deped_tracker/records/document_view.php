<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator', 'Records Personnel'])) {
    echo "<script>alert('You do not have permission to access this page.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('Invalid document request.'); window.location='documents.php';</script>";
    exit();
}

$document_id = (int) $_GET['id'];

/*
|--------------------------------------------------------------------------
| Fetch document details
|--------------------------------------------------------------------------
*/
$document_query = mysqli_query($conn, "
    SELECT
        d.*,
        dt.document_type_name,
        o.org_name,
        dep.department_name,
        u.fullname AS created_by_name
    FROM documents d
    LEFT JOIN document_types dt ON d.document_type_id = dt.document_type_id
    LEFT JOIN organization o ON d.org_id = o.org_id
    LEFT JOIN departments dep ON d.current_department_id = dep.department_id
    LEFT JOIN users u ON d.created_by = u.user_id
    WHERE d.document_id = '$document_id'
    LIMIT 1
");

if (!$document_query || mysqli_num_rows($document_query) === 0) {
    echo "<script>alert('Document not found.'); window.location='documents.php';</script>";
    exit();
}

$document = mysqli_fetch_assoc($document_query);

/*
|--------------------------------------------------------------------------
| Fetch latest log
|--------------------------------------------------------------------------
*/
$latest_log_query = mysqli_query($conn, "
    SELECT
        dl.*,
        u.fullname
    FROM document_logs dl
    LEFT JOIN users u ON dl.updated_by = u.user_id
    WHERE dl.document_id = '$document_id'
    ORDER BY dl.action_datetime DESC
    LIMIT 1
");

$latest_log = null;
if ($latest_log_query && mysqli_num_rows($latest_log_query) > 0) {
    $latest_log = mysqli_fetch_assoc($latest_log_query);
}

/*
|--------------------------------------------------------------------------
| Fetch document logs
|--------------------------------------------------------------------------
*/
$logs_query = mysqli_query($conn, "
    SELECT
        dl.*,
        u.fullname,
        fd.department_name AS from_department_name,
        td.department_name AS to_department_name
    FROM document_logs dl
    LEFT JOIN users u ON dl.updated_by = u.user_id
    LEFT JOIN departments fd ON dl.from_department = fd.department_id
    LEFT JOIN departments td ON dl.to_department = td.department_id
    WHERE dl.document_id = '$document_id'
    ORDER BY dl.action_datetime DESC
");

/*
|--------------------------------------------------------------------------
| UI helpers
|--------------------------------------------------------------------------
*/
$current_status = $document['status'] ?? 'N/A';
$current_department = !empty($document['department_name']) ? $document['department_name'] : 'Records';
$organization_name = 'N/A';

if (!empty($document['org_name'])) {
    $organization_name = $document['org_name'];
} elseif (!empty($document['other_organization'])) {
    $organization_name = $document['other_organization'];
}

$can_forward = !in_array($current_status, ['Released', 'For Releasing']);
$can_mark_release = in_array($current_status, ['For Releasing']);

?>

<div class="main-content">

    <!-- Page Header -->
    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:20px; flex-wrap:wrap; margin-bottom:24px;">
        <div>
            <h2 style="margin:0; font-size:32px; color:#0f172a;">Document Detail</h2>
            <p style="margin:8px 0 0 0; color:#64748b; font-size:15px;">
                Review document information, routing history, and Records actions.
            </p>
        </div>

        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <a href="documents.php" class="btn btn-secondary">Back to Documents</a>

            <?php if ($can_forward): ?>
                <a href="forward_document.php?id=<?php echo $document['document_id']; ?>" class="btn btn-primary">Forward Document</a>
            <?php endif; ?>

            <a href="../staff/update_status.php?id=<?php echo $document['document_id']; ?>" class="btn btn-dark">Update Status</a>

            <?php if ($can_mark_release): ?>
                <a href="../staff/update_status.php?id=<?php echo $document['document_id']; ?>" class="btn btn-primary">Mark Released</a>
            <?php endif; ?>

            <?php if (!empty($document['qr_code'])): ?>
                <a href="../<?php echo e($document['qr_code']); ?>" target="_blank" class="btn btn-secondary">View QR</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Top Summary Strip -->
    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:18px; margin-bottom:24px;">
        <div class="page-card" style="border-left:5px solid #1d4ed8;">
            <div style="font-size:13px; color:#64748b; margin-bottom:8px;">Reference Number</div>
            <div style="font-size:22px; font-weight:bold; color:#0f172a;"><?php echo e($document['reference_no']); ?></div>
        </div>

        <div class="page-card" style="border-left:5px solid #0ea5e9;">
            <div style="font-size:13px; color:#64748b; margin-bottom:8px;">Current Status</div>
            <div>
                <span class="status-badge" style="<?php echo getStatusBadgeStyle($current_status); ?>">
                    <?php echo e($current_status); ?>
                </span>
            </div>
        </div>

        <div class="page-card" style="border-left:5px solid #14b8a6;">
            <div style="font-size:13px; color:#64748b; margin-bottom:8px;">Current Office</div>
            <div style="font-size:18px; font-weight:bold; color:#0f172a;"><?php echo e($current_department); ?></div>
        </div>

        <div class="page-card" style="border-left:5px solid #8b5cf6;">
            <div style="font-size:13px; color:#64748b; margin-bottom:8px;">Date Received</div>
            <div style="font-size:18px; font-weight:bold; color:#0f172a;"><?php echo formatDateTime($document['date_received']); ?></div>
        </div>
    </div>

    <div style="display:grid; grid-template-columns:2fr 1fr; gap:24px; align-items:start;">

        <!-- LEFT COLUMN -->
        <div style="display:flex; flex-direction:column; gap:24px;">

            <!-- Main Information -->
            <div class="page-card">
                <h3 style="margin:0 0 18px 0; color:#0f172a;">Document Information</h3>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">

                    <div>
                        <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Document Type</div>
                        <div style="font-size:16px; color:#111827;"><?php echo e($document['document_type_name'] ?: 'N/A'); ?></div>
                    </div>

                    <div>
                        <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Organization</div>
                        <div style="font-size:16px; color:#111827;"><?php echo e($organization_name); ?></div>
                    </div>

                    <div>
                        <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Submitted By</div>
                        <div style="font-size:16px; color:#111827;"><?php echo e($document['submitted_by']); ?></div>
                    </div>

                    <div>
                        <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Client Email</div>
                        <div style="font-size:16px; color:#111827; word-break:break-word;"><?php echo e($document['client_email']); ?></div>
                    </div>

                    <div>
                        <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Created By</div>
                        <div style="font-size:16px; color:#111827;"><?php echo e($document['created_by_name'] ?: 'System'); ?></div>
                    </div>

                    <div>
                        <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Last Updated</div>
                        <div style="font-size:16px; color:#111827;">
                            <?php echo !empty($document['updated_at']) ? formatDateTime($document['updated_at']) : 'Not yet updated'; ?>
                        </div>
                    </div>

                    <div style="grid-column:1 / span 2;">
                        <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Description / Subject</div>
                        <div style="border:1px solid #e5e7eb; background:#f8fbff; border-radius:12px; padding:16px; min-height:110px; line-height:1.7; color:#1f2937;">
                            <?php echo nl2br(e($document['description'])); ?>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Routing Timeline -->
            <div class="page-card">
                <h3 style="margin:0 0 18px 0; color:#0f172a;">Routing Timeline</h3>

                <?php if ($logs_query && mysqli_num_rows($logs_query) > 0): ?>
                    <div style="display:flex; flex-direction:column; gap:18px;">
                        <?php while ($log = mysqli_fetch_assoc($logs_query)): ?>
                            <div style="border-left:4px solid #1d4ed8; padding-left:14px;">
                                <div style="font-size:13px; color:#64748b; margin-bottom:6px;">
                                    <?php echo formatDateTime($log['action_datetime']); ?>
                                </div>

                                <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:6px;">
                                    <div style="font-size:18px; font-weight:bold; color:#0f172a;">
                                        <?php echo e($log['status']); ?>
                                    </div>
                                    <span class="status-badge" style="<?php echo getStatusBadgeStyle($log['status']); ?>">
                                        <?php echo e($log['status']); ?>
                                    </span>
                                </div>

                                <?php if (!empty($log['remarks'])): ?>
                                    <div style="color:#374151; margin-bottom:6px; line-height:1.6;">
                                        <?php echo e($log['remarks']); ?>
                                    </div>
                                <?php endif; ?>

                                <div style="font-size:13px; color:#64748b; margin-bottom:4px;">
                                    <strong>Updated By:</strong> <?php echo e($log['fullname'] ?: 'System'); ?>
                                </div>

                                <?php if (!empty($log['from_department_name']) || !empty($log['to_department_name'])): ?>
                                    <div style="font-size:13px; color:#64748b;">
                                        <strong>Route:</strong>
                                        <?php echo e($log['from_department_name'] ?: 'N/A'); ?>
                                        →
                                        <?php echo e($log['to_department_name'] ?: 'N/A'); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <div style="color:#64748b;">No tracking logs found for this document.</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- RIGHT COLUMN -->
        <div style="display:flex; flex-direction:column; gap:20px;">

            <!-- QR -->
            <?php if (!empty($document['qr_code'])): ?>
                <div class="page-card" style="text-align:center;">
                    <h3 style="margin:0 0 16px 0; color:#0f172a;">QR Code</h3>
                    <img
                        src="../<?php echo e($document['qr_code']); ?>"
                        alt="QR Code"
                        style="max-width:220px; width:100%; border:1px solid #dbe3ef; background:#fff; padding:10px; border-radius:12px;"
                    >
                    <p style="margin:12px 0 0 0; color:#64748b; font-size:13px;">
                        Scan to open the public tracking page.
                    </p>
                </div>
            <?php endif; ?>

            <!-- Latest Action -->
            <div class="page-card">
                <h3 style="margin:0 0 14px 0; color:#0f172a;">Latest Action</h3>

                <?php if ($latest_log): ?>
                    <div style="display:flex; flex-direction:column; gap:10px; font-size:14px; color:#374151; line-height:1.6;">
                        <div><strong>Status:</strong> <?php echo e($latest_log['status']); ?></div>
                        <div><strong>Date:</strong> <?php echo formatDateTime($latest_log['action_datetime']); ?></div>
                        <div><strong>Updated By:</strong> <?php echo e($latest_log['fullname'] ?: 'System'); ?></div>
                        <div><strong>Remarks:</strong> <?php echo !empty($latest_log['remarks']) ? e($latest_log['remarks']) : 'No remarks'; ?></div>
                    </div>
                <?php else: ?>
                    <div style="color:#64748b;">No latest action available.</div>
                <?php endif; ?>
            </div>

            <!-- Records Actions -->
            <div class="page-card">
                <h3 style="margin:0 0 14px 0; color:#0f172a;">Records Actions</h3>
                <div style="display:flex; flex-direction:column; gap:12px;">
                    <?php if ($can_forward): ?>
                        <a href="forward_document.php?id=<?php echo $document['document_id']; ?>" class="btn btn-primary" style="text-align:center;">
                            Forward to Department
                        </a>
                    <?php endif; ?>

                    <a href="../staff/update_status.php?id=<?php echo $document['document_id']; ?>" class="btn btn-dark" style="text-align:center;">
                        Update Status
                    </a>

                    <?php if ($can_mark_release): ?>
                        <a href="../staff/update_status.php?id=<?php echo $document['document_id']; ?>" class="btn btn-secondary" style="text-align:center;">
                            Finalize Release
                        </a>
                    <?php endif; ?>
                </div>

                <div style="margin-top:14px; padding:12px; border-radius:10px; background:#eff6ff; color:#1e3a8a; font-size:13px; line-height:1.6;">
                    Records Personnel can review, forward, and finalize release-related updates from this page.
                </div>
            </div>

        </div>
    </div>

</div>

<?php include '../includes/footer.php'; ?>