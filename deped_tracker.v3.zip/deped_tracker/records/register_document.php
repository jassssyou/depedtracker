<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/header.php';
include '../includes/sidebar.php';
require_once '../libs/phpqrcode/qrlib.php';

/*
|--------------------------------------------------------------------------
| Set Philippine Timezone
|--------------------------------------------------------------------------
*/
date_default_timezone_set('Asia/Manila');

/*
|--------------------------------------------------------------------------
| OPTIONAL: Include mailer if already set up
|--------------------------------------------------------------------------
*/
$mailer_available = file_exists('../includes/mailer.php');
if ($mailer_available) {
    include_once '../includes/mailer.php';
}

/*
|--------------------------------------------------------------------------
| Helper: Generate unique reference number
|--------------------------------------------------------------------------
*/
function generateReferenceNo($conn) {
    do {
        $reference_no = 'DT-' . date('Ymd') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        $check = mysqli_query($conn, "SELECT document_id FROM documents WHERE reference_no = '$reference_no' LIMIT 1");
    } while ($check && mysqli_num_rows($check) > 0);

    return $reference_no;
}

/*
|--------------------------------------------------------------------------
| Fetch dropdown data
|--------------------------------------------------------------------------
*/
$document_types = mysqli_query($conn, "
    SELECT document_type_id, document_type_name
    FROM document_types
    WHERE status = 'Active'
    ORDER BY document_type_name ASC
");

$organization = mysqli_query($conn, "
    SELECT org_id, org_name
    FROM organization
    WHERE status = 'Active'
    ORDER BY org_name ASC
");

/*
|--------------------------------------------------------------------------
| Defaults
|--------------------------------------------------------------------------
*/
$errors = [];
$submitted_by = '';
$email = '';
$description = '';
$document_type_id = '';
$org_id = '';
$other_organization = '';

$php_now = date('Y-m-d H:i:s');
$date_received_display = date('m/d/Y h:i A');

/*
|--------------------------------------------------------------------------
| Handle form submission
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $document_type_id = isset($_POST['document_type_id']) ? (int) $_POST['document_type_id'] : 0;
    $org_id = isset($_POST['org_id']) ? trim($_POST['org_id']) : '';
    $other_organization = isset($_POST['other_organization']) ? trim($_POST['other_organization']) : '';
    $submitted_by = trim($_POST['submitted_by'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $created_by = (int) ($_SESSION['user_id'] ?? 0);

    /*
    |--------------------------------------------------------------------------
    | Validation
    |--------------------------------------------------------------------------
    */
    if ($document_type_id <= 0) {
        $errors[] = "Please select a document type.";
    }

    if ($org_id === '') {
        $errors[] = "Please select an organization.";
    }

    if ($org_id === 'others' && $other_organization === '') {
        $errors[] = "Please specify the organization.";
    }

    if ($submitted_by === '') {
        $errors[] = "Submitted by field is required.";
    }

    if ($email === '') {
        $errors[] = "Client email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }

    if ($description === '') {
        $errors[] = "Description is required.";
    }

    if ($created_by <= 0) {
        $errors[] = "Invalid session. Please log in again.";
    }

    /*
    |--------------------------------------------------------------------------
    | Save document if no validation errors
    |--------------------------------------------------------------------------
    */
    if (empty($errors)) {
        $reference_no = generateReferenceNo($conn);

        // Philippine time
        $date_received = date('Y-m-d H:i:s');
        $created_at = date('Y-m-d H:i:s');
        $log_time = date('Y-m-d H:i:s');
        $email_sent_at = date('Y-m-d H:i:s');

        $org_id_value = 'NULL';
        $other_org_value = 'NULL';

        if ($org_id === 'others') {
            $other_org_escaped = mysqli_real_escape_string($conn, $other_organization);
            $other_org_value = "'$other_org_escaped'";
        } else {
            $org_id_value = (int) $org_id;
        }

        $submitted_by_escaped = mysqli_real_escape_string($conn, $submitted_by);
        $email_escaped = mysqli_real_escape_string($conn, $email);
        $description_escaped = mysqli_real_escape_string($conn, $description);

        /*
        |--------------------------------------------------------------------------
        | IMPORTANT:
        | Use `status` column, not `document_status`
        |--------------------------------------------------------------------------
        */
        $insert_sql = "INSERT INTO documents (
                            reference_no,
                            qr_code,
                            document_type_id,
                            org_id,
                            other_organization,
                            submitted_by,
                            client_email,
                            description,
                            current_department_id,
                            status,
                            date_received,
                            created_by,
                            created_at
                        ) VALUES (
                            '$reference_no',
                            NULL,
                            '$document_type_id',
                            $org_id_value,
                            $other_org_value,
                            '$submitted_by_escaped',
                            '$email_escaped',
                            '$description_escaped',
                            NULL,
                            'Received',
                            '$date_received',
                            '$created_by',
                            '$created_at'
                        )";

        $insert = mysqli_query($conn, $insert_sql);

        if ($insert) {
            $document_id = mysqli_insert_id($conn);

            /*
            |--------------------------------------------------------------------------
            | Generate tracking URL
            |--------------------------------------------------------------------------
            */
            $tracking_url = "http://localhost/deped_tracker/public/track.php?ref=" . urlencode($reference_no);

            /*
            |--------------------------------------------------------------------------
            | Generate QR code
            |--------------------------------------------------------------------------
            */
            $qr_folder = "../qr/";
            if (!is_dir($qr_folder)) {
                mkdir($qr_folder, 0777, true);
            }

            $qr_filename = $reference_no . ".png";
            $qr_full_path = $qr_folder . $qr_filename;
            $qr_db_path = "qr/" . $qr_filename;

            QRcode::png($tracking_url, $qr_full_path, QR_ECLEVEL_L, 5);

            $update_qr = mysqli_query($conn, "
                UPDATE documents
                SET qr_code = '$qr_db_path'
                WHERE document_id = '$document_id'
            ");

            if (!$update_qr) {
                $errors[] = "QR update failed: " . mysqli_error($conn);
            }

            /*
            |--------------------------------------------------------------------------
            | Insert first tracking log
            |--------------------------------------------------------------------------
            */
            $insert_log = mysqli_query($conn, "
                INSERT INTO document_logs (
                    document_id,
                    from_department,
                    to_department,
                    status,
                    remarks,
                    updated_by,
                    action_datetime
                ) VALUES (
                    '$document_id',
                    NULL,
                    NULL,
                    'Received',
                    'Document received at Records Office',
                    '$created_by',
                    '$log_time'
                )
            ");

            if (!$insert_log) {
                $errors[] = "Failed to save document log: " . mysqli_error($conn);
            }

            /*
            |--------------------------------------------------------------------------
            | Send email notification
            |--------------------------------------------------------------------------
            */
            if (
                $mailer_available &&
                function_exists('sendDocumentEmail') &&
                function_exists('buildLoggedEmailTemplate')
            ) {
                $subject = "Document Successfully Logged - $reference_no";
                $body = buildLoggedEmailTemplate($reference_no, $submitted_by, $description, $tracking_url);

                $sent = sendDocumentEmail($email, $subject, $body, $qr_full_path, $qr_filename);

                $subject_escaped = mysqli_real_escape_string($conn, $subject);
                $body_escaped = mysqli_real_escape_string($conn, $body);
                $email_type = $sent ? 'Document Logged' : 'Document Logged - Failed';

                $insert_email_log = mysqli_query($conn, "
                    INSERT INTO email_notifications (
                        document_id,
                        recipient_email,
                        subject,
                        message,
                        type,
                        sent_at
                    ) VALUES (
                        '$document_id',
                        '$email_escaped',
                        '$subject_escaped',
                        '$body_escaped',
                        '$email_type',
                        '$email_sent_at'
                    )
                ");

                if (!$insert_email_log) {
                    $errors[] = "Failed to save email notification log: " . mysqli_error($conn);
                }
            }

            if (empty($errors)) {
                echo "<script>alert('Document registered successfully. Reference No: {$reference_no}'); window.location='document_view.php?id={$document_id}';</script>";
                exit();
            }
        } else {
            $errors[] = "Error saving document: " . mysqli_error($conn);
        }
    }
}
?>

<div style="margin-left:270px; padding:20px; max-width:900px;">
    <h2>Register Document</h2>
    <p>Enter document details to generate a tracking reference and QR code.</p>

    <?php if (!empty($errors)) : ?>
        <div style="background:#fee2e2; color:#991b1b; padding:15px; border-radius:8px; margin-bottom:20px;">
            <strong>Please fix the following:</strong>
            <ul style="margin:10px 0 0 20px;">
                <?php foreach ($errors as $error) : ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" style="background:#fff; padding:25px; border-radius:12px; box-shadow:0 2px 10px rgba(0,0,0,0.08);">

        <div style="margin-bottom:18px;">
            <label><strong>Document Type *</strong></label><br>
            <select name="document_type_id" required style="width:100%; padding:10px; margin-top:6px;">
                <option value="">Select document type</option>
                <?php
                if ($document_types) {
                    mysqli_data_seek($document_types, 0);
                    while ($type = mysqli_fetch_assoc($document_types)) :
                ?>
                    <option value="<?php echo $type['document_type_id']; ?>" <?php echo ($document_type_id == $type['document_type_id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($type['document_type_name']); ?>
                    </option>
                <?php
                    endwhile;
                }
                ?>
            </select>
        </div>

        <div style="margin-bottom:18px;">
            <label><strong>Organization *</strong></label><br>
            <select name="org_id" id="org_id" required onchange="toggleOtherOrganization()" style="width:100%; padding:10px; margin-top:6px;">
                <option value="">Select organization</option>
                <?php
                if ($organization) {
                    mysqli_data_seek($organization, 0);
                    while ($org = mysqli_fetch_assoc($organization)) :
                ?>
                    <option value="<?php echo $org['org_id']; ?>" <?php echo ($org_id == $org['org_id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($org['org_name']); ?>
                    </option>
                <?php
                    endwhile;
                }
                ?>
                <option value="others" <?php echo ($org_id === 'others') ? 'selected' : ''; ?>>Others</option>
            </select>
        </div>

        <div id="otherOrgWrapper" style="margin-bottom:18px; display:<?php echo ($org_id === 'others') ? 'block' : 'none'; ?>;">
            <label><strong>Specify Organization *</strong></label><br>
            <input
                type="text"
                name="other_organization"
                value="<?php echo htmlspecialchars($other_organization); ?>"
                placeholder="Enter organization name"
                style="width:100%; padding:10px; margin-top:6px;"
            >
        </div>

        <div style="margin-bottom:18px;">
            <label><strong>Date Received *</strong></label><br>
            <input
                type="text"
                value="<?php echo htmlspecialchars($date_received_display); ?>"
                readonly
                style="width:100%; padding:10px; margin-top:6px; background:#f3f4f6;"
            >
        </div>

        <div style="margin-bottom:18px;">
            <label><strong>Submitted By *</strong></label><br>
            <input
                type="text"
                name="submitted_by"
                value="<?php echo htmlspecialchars($submitted_by); ?>"
                placeholder="Name of school head / bearer / client"
                required
                style="width:100%; padding:10px; margin-top:6px;"
            >
        </div>

        <div style="margin-bottom:18px;">
            <label><strong>Contact Email *</strong></label><br>
            <input
                type="email"
                name="email"
                value="<?php echo htmlspecialchars($email); ?>"
                placeholder="Email for notifications"
                required
                style="width:100%; padding:10px; margin-top:6px;"
            >
        </div>

        <div style="margin-bottom:18px;">
            <label><strong>Description / Subject *</strong></label><br>
            <textarea
                name="description"
                rows="5"
                placeholder="Brief description of the document contents"
                required
                style="width:100%; padding:10px; margin-top:6px;"
            ><?php echo htmlspecialchars($description); ?></textarea>
        </div>

        <button type="submit" style="background:#1d4ed8; color:#fff; padding:12px 20px; border:none; border-radius:8px; cursor:pointer;">
            Register & Generate QR
        </button>
    </form>
</div>

<script>
function toggleOtherOrganization() {
    const orgSelect = document.getElementById('org_id');
    const otherOrgWrapper = document.getElementById('otherOrgWrapper');

    if (orgSelect.value === 'others') {
        otherOrgWrapper.style.display = 'block';
    } else {
        otherOrgWrapper.style.display = 'none';
    }
}
</script>

<?php include '../includes/footer.php'; ?>