<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$current_role = $_SESSION['role'] ?? '';
$current_name = $_SESSION['fullname'] ?? 'User';

$current_page = basename($_SERVER['PHP_SELF']);

function sidebarLink($href, $label, $current_page, $page_match = []) {
    $matched = in_array($current_page, $page_match) ? true : false;

    $base_style = "display:block; color:#e5eefc; padding:11px 12px; border-radius:10px; margin-bottom:6px; font-size:14px; font-weight:500; transition:all 0.2s ease;";
    $active_style = "background:#1d4ed8; color:#ffffff; box-shadow:0 6px 14px rgba(29,78,216,0.28);";
    $inactive_style = "background:transparent;";

    echo '<a href="' . $href . '" style="' . $base_style . ($matched ? $active_style : $inactive_style) . '">' . htmlspecialchars($label) . '</a>';
}
?>

<div style="
    width:260px;
    height:100vh;
    background:linear-gradient(180deg, #0f172a 0%, #111c34 100%);
    color:#ffffff;
    position:fixed;
    top:0;
    left:0;
    padding:18px 16px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    border-right:1px solid rgba(255,255,255,0.04);
    overflow-y:auto;
">

    <div>
        <!-- BRAND -->
        <div style="
            display:flex;
            align-items:center;
            gap:12px;
            margin-bottom:28px;
            padding:8px 6px 14px 6px;
            border-bottom:1px solid rgba(255,255,255,0.08);
        ">
            <div style="
                width:56px;
                height:56px;
                background:#ffffff url('../assets/images/logo.png') center/cover no-repeat;
                border-radius:12px;
                flex-shrink:0;
                box-shadow:0 8px 16px rgba(0,0,0,0.25);
            "></div>

            <div>
                <div style="font-weight:700; font-size:15px; color:#ffffff;">DepEd Tracker</div>
                <div style="font-size:12px; color:#94a3b8; line-height:1.4;">Document Tracking System</div>
            </div>
        </div>

        <div style="font-size:11px; color:#94a3b8; margin:0 0 10px 6px; letter-spacing:1px;">MAIN</div>

        <?php if ($current_role === 'Administrator') : ?>

            <?php sidebarLink('../admin/dashboard.php', 'Dashboard', $current_page, ['dashboard.php']); ?>
            <?php sidebarLink('../records/documents.php', 'Documents', $current_page, ['documents.php', 'document_view.php', 'forward_document.php']); ?>
            <?php sidebarLink('../records/register_document.php', 'Register Document', $current_page, ['register_document.php']); ?>
            <?php sidebarLink('../records/release.php', 'Release Queue', $current_page, ['release.php', 'release_history.php']); ?>
            <?php sidebarLink('../reports/summary_report.php', 'Reports', $current_page, ['summary_report.php', 'daily_transactions.php']); ?>

            <div style="font-size:11px; color:#94a3b8; margin:18px 0 10px 6px; letter-spacing:1px;">ADMINISTRATION</div>

            <?php sidebarLink('../admin/users.php', 'Manage Users', $current_page, ['users.php', 'user_form.php']); ?>
            <?php sidebarLink('../admin/departments.php', 'Departments', $current_page, ['departments.php', 'department_form.php']); ?>
            <?php sidebarLink('../admin/document_types.php', 'Document Types', $current_page, ['document_types.php', 'document_type_form.php']); ?>
            <?php sidebarLink('../admin/organizations.php', 'Organizations', $current_page, ['organizations.php', 'organization_form.php']); ?>
            <?php sidebarLink('../admin/system_logs.php', 'System Logs', $current_page, ['system_logs.php']); ?>

        <?php elseif ($current_role === 'Records Personnel') : ?>

            <?php sidebarLink('../records/dashboard.php', 'Dashboard', $current_page, ['dashboard.php']); ?>
            <?php sidebarLink('../records/register_document.php', 'Register Document', $current_page, ['register_document.php']); ?>
            <?php sidebarLink('../records/documents.php', 'Documents', $current_page, ['documents.php', 'document_view.php', 'forward_document.php']); ?>
            <?php sidebarLink('../records/release.php', 'Release Queue', $current_page, ['release.php']); ?>
            <?php sidebarLink('../records/release_history.php', 'Release History', $current_page, ['release_history.php']); ?>
            <?php sidebarLink('../reports/summary_report.php', 'Reports', $current_page, ['summary_report.php', 'daily_transactions.php']); ?>

        <?php else : ?>

            <?php sidebarLink('../staff/dashboard.php', 'Dashboard', $current_page, ['dashboard.php']); ?>
            <?php sidebarLink('../staff/documents.php', 'Assigned Documents', $current_page, ['documents.php', 'document_view.php', 'update_status.php', 'return_to_records.php']); ?>
            <?php sidebarLink('../reports/summary_report.php', 'Reports', $current_page, ['summary_report.php', 'daily_transactions.php']); ?>

        <?php endif; ?>
    </div>

    <div style="padding-top:16px;">
        <div style="
            background:rgba(255,255,255,0.06);
            padding:12px;
            border-radius:12px;
            margin-bottom:10px;
            border:1px solid rgba(255,255,255,0.05);
        ">
            <div style="font-weight:700; font-size:14px; color:#ffffff;">
                <?php echo htmlspecialchars($current_name); ?>
            </div>
            <div style="font-size:12px; color:#94a3b8; margin-top:3px;">
                <?php echo htmlspecialchars($current_role); ?>
            </div>
        </div>

        <a href="../auth/logout.php" style="
            display:block;
            text-align:center;
            background:#111827;
            color:#ffffff;
            padding:10px 12px;
            border-radius:10px;
            font-weight:600;
            border:1px solid rgba(255,255,255,0.06);
        ">
            Sign Out
        </a>
    </div>
</div>