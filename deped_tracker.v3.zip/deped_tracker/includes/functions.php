<?php

/*
|--------------------------------------------------------------------------
| GLOBAL TIMEZONE (PHILIPPINES)
|--------------------------------------------------------------------------
*/
date_default_timezone_set('Asia/Manila');

/*
|--------------------------------------------------------------------------
| Escape helper
|--------------------------------------------------------------------------
*/
function e($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| Role checker
|--------------------------------------------------------------------------
*/
function hasRole($allowed_roles = []) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (!isset($_SESSION['role'])) {
        return false;
    }

    return in_array($_SESSION['role'], $allowed_roles);
}

/*
|--------------------------------------------------------------------------
| Require role
|--------------------------------------------------------------------------
*/
function requireRole($allowed_roles = []) {
    if (!hasRole($allowed_roles)) {
        echo "<script>alert('You do not have permission to access this page.'); window.history.back();</script>";
        exit();
    }
}

/*
|--------------------------------------------------------------------------
| Status badge colors
|--------------------------------------------------------------------------
*/
function getStatusBadgeStyle($status) {
    switch (strtolower(trim($status))) {
        case 'received':
            return "background:#dbeafe; color:#1d4ed8;";
        case 'in process':
            return "background:#fef3c7; color:#92400e;";
        case 'forwarded':
            return "background:#ede9fe; color:#7c3aed;";
        case 'approved':
            return "background:#dcfce7; color:#166534;";
        case 'for releasing':
            return "background:#ccfbf1; color:#0f766e;";
        case 'released':
            return "background:#d1fae5; color:#065f46;";
        default:
            return "background:#e5e7eb; color:#374151;";
    }
}

/*
|--------------------------------------------------------------------------
| Format DateTime (PH Time Safe)
|--------------------------------------------------------------------------
*/
function formatDateTime($datetime) {
    if (empty($datetime) || $datetime === '0000-00-00 00:00:00') {
        return 'N/A';
    }

    try {
        $date = new DateTime($datetime, new DateTimeZone('Asia/Manila'));
        return $date->format('F j, Y h:i A');
    } catch (Exception $e) {
        return 'Invalid Date';
    }
}

/*
|--------------------------------------------------------------------------
| Short Date (optional use)
|--------------------------------------------------------------------------
*/
function formatDate($date) {
    if (empty($date)) return 'N/A';

    try {
        $d = new DateTime($date, new DateTimeZone('Asia/Manila'));
        return $d->format('M d, Y');
    } catch (Exception $e) {
        return 'Invalid Date';
    }
}

/*
|--------------------------------------------------------------------------
| Time only (optional use)
|--------------------------------------------------------------------------
*/
function formatTime($datetime) {
    if (empty($datetime)) return 'N/A';

    try {
        $d = new DateTime($datetime, new DateTimeZone('Asia/Manila'));
        return $d->format('h:i A');
    } catch (Exception $e) {
        return 'Invalid Time';
    }
}

?>