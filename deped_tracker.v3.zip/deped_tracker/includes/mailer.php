<?php

require_once __DIR__ . '/../config/mail_config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../libs/PHPMailer/src/Exception.php';
require_once __DIR__ . '/../libs/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../libs/PHPMailer/src/SMTP.php';

function sendDocumentEmail($to, $subject, $body, $qr_full_path = null, $qr_filename = null) {
    if (empty($to)) {
        return false;
    }

    if (
        !defined('MAIL_HOST') ||
        !defined('MAIL_USERNAME') ||
        !defined('MAIL_PASSWORD') ||
        !defined('MAIL_PORT') ||
        !defined('MAIL_FROM') ||
        !defined('MAIL_FROM_NAME')
    ) {
        die('Mail configuration constants are missing in config/mail_config.php');
    }

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = MAIL_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = MAIL_USERNAME;
        $mail->Password = MAIL_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = MAIL_PORT;
        $mail->CharSet = 'UTF-8';

        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addReplyTo(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addAddress($to);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->AltBody = strip_tags(str_replace(
            ['<br>', '<br/>', '<br />'],
            "\n",
            $body
        ));

        if (!empty($qr_full_path) && file_exists($qr_full_path)) {
            $mail->addEmbeddedImage($qr_full_path, 'document_qr_cid', $qr_filename ?: 'qr.png');
            $mail->addAttachment($qr_full_path, $qr_filename ?: 'qr.png');
        }

        return $mail->send();

    } catch (Exception $e) {
        return false;
    }
}

function buildEmailLayout($title, $subtitle, $content_html) {
    return "
        <div style='font-family: Arial, sans-serif; background:#f4f7fb; padding:24px; color:#1f2937;'>
            <div style='max-width:700px; margin:0 auto; background:#ffffff; border:1px solid #e5e7eb; border-radius:12px; overflow:hidden;'>
                <div style='background:#1d4ed8; color:#ffffff; padding:24px; text-align:center;'>
                    <h2 style='margin:0; font-size:24px;'>DepEd Talisay Document Tracking System</h2>
                    <p style='margin:8px 0 0 0; font-size:14px;'>$subtitle</p>
                </div>

                <div style='padding:28px;'>
                    <h3 style='margin-top:0; color:#111827;'>$title</h3>
                    $content_html
                </div>

                <div style='background:#f9fafb; color:#6b7280; padding:16px 24px; font-size:13px; text-align:center;'>
                    This is an automated message from DepEd Talisay City Division.
                </div>
            </div>
        </div>
    ";
}

function buildLoggedEmailTemplate($reference_no, $submitted_by, $description, $tracking_url) {
    $reference_no = htmlspecialchars($reference_no, ENT_QUOTES, 'UTF-8');
    $submitted_by = htmlspecialchars($submitted_by, ENT_QUOTES, 'UTF-8');
    $description = nl2br(htmlspecialchars($description, ENT_QUOTES, 'UTF-8'));
    $tracking_url = htmlspecialchars($tracking_url, ENT_QUOTES, 'UTF-8');

    $content = "
        <p>Good day,</p>
        <p>Your document has been <strong>successfully logged</strong> in the system.</p>

        <table style='width:100%; border-collapse:collapse; margin:20px 0;'>
            <tr>
                <td style='padding:10px; border:1px solid #e5e7eb; background:#f9fafb; width:35%;'><strong>Reference Number</strong></td>
                <td style='padding:10px; border:1px solid #e5e7eb;'>$reference_no</td>
            </tr>
            <tr>
                <td style='padding:10px; border:1px solid #e5e7eb; background:#f9fafb;'><strong>Submitted By</strong></td>
                <td style='padding:10px; border:1px solid #e5e7eb;'>$submitted_by</td>
            </tr>
            <tr>
                <td style='padding:10px; border:1px solid #e5e7eb; background:#f9fafb;'><strong>Description</strong></td>
                <td style='padding:10px; border:1px solid #e5e7eb;'>$description</td>
            </tr>
        </table>

        <p>You may track your document using the button below:</p>

        <p style='margin:18px 0;'>
            <a href='$tracking_url' style='display:inline-block; background:#1d4ed8; color:#ffffff; text-decoration:none; padding:12px 18px; border-radius:8px; font-weight:bold;'>
                Track Document
            </a>
        </p>

        <p>Direct tracking link:</p>
        <p style='word-break:break-all;'><a href='$tracking_url'>$tracking_url</a></p>

        <div style='margin-top:30px; text-align:center;'>
            <p style='margin-bottom:10px;'><strong>QR Code for Tracking</strong></p>
            <img src='cid:document_qr_cid' alt='Document QR Code' style='max-width:220px; border:1px solid #e5e7eb; padding:10px; border-radius:8px; background:#fff;'>
            <p style='font-size:13px; color:#6b7280; margin-top:10px;'>You can scan this QR code to track the document.</p>
        </div>

        <p style='margin-top:30px;'>Please keep your reference number for future tracking and inquiries.</p>
        <p>Thank you.</p>
    ";

    return buildEmailLayout('Document Registration Confirmation', 'Document Successfully Logged', $content);
}

function buildReadyForReleaseEmailTemplate($reference_no, $tracking_url, $description = '') {
    $reference_no = htmlspecialchars($reference_no, ENT_QUOTES, 'UTF-8');
    $tracking_url = htmlspecialchars($tracking_url, ENT_QUOTES, 'UTF-8');
    $description = htmlspecialchars($description, ENT_QUOTES, 'UTF-8');

    $extra = $description !== '' ? "
        <tr>
            <td style='padding:10px; border:1px solid #e5e7eb; background:#f9fafb; width:35%;'><strong>Description</strong></td>
            <td style='padding:10px; border:1px solid #e5e7eb;'>$description</td>
        </tr>
    " : "";

    $content = "
        <p>Good day,</p>
        <p>Your document is now <strong>ready for release</strong>.</p>

        <table style='width:100%; border-collapse:collapse; margin:20px 0;'>
            <tr>
                <td style='padding:10px; border:1px solid #e5e7eb; background:#f9fafb; width:35%;'><strong>Reference Number</strong></td>
                <td style='padding:10px; border:1px solid #e5e7eb;'>$reference_no</td>
            </tr>
            $extra
            <tr>
                <td style='padding:10px; border:1px solid #e5e7eb; background:#f9fafb;'><strong>Status</strong></td>
                <td style='padding:10px; border:1px solid #e5e7eb;'>For Releasing</td>
            </tr>
        </table>

        <p>Please proceed to DepEd Talisay City Division to claim your document.</p>
        <p>You may also monitor the status through the link below:</p>

        <p style='margin:18px 0;'>
            <a href='$tracking_url' style='display:inline-block; background:#1d4ed8; color:#ffffff; text-decoration:none; padding:12px 18px; border-radius:8px; font-weight:bold;'>
                Track Document
            </a>
        </p>

        <p>Direct tracking link:</p>
        <p style='word-break:break-all;'><a href='$tracking_url'>$tracking_url</a></p>

        <p style='margin-top:24px;'>Please bring your reference number when claiming the document.</p>
        <p>Thank you.</p>
    ";

    return buildEmailLayout('Document Ready for Release', 'Release Notification', $content);
}

function buildReleasedEmailTemplate($reference_no, $tracking_url, $description = '') {
    $reference_no = htmlspecialchars($reference_no, ENT_QUOTES, 'UTF-8');
    $tracking_url = htmlspecialchars($tracking_url, ENT_QUOTES, 'UTF-8');
    $description = htmlspecialchars($description, ENT_QUOTES, 'UTF-8');

    $extra = $description !== '' ? "
        <tr>
            <td style='padding:10px; border:1px solid #e5e7eb; background:#f9fafb; width:35%;'><strong>Description</strong></td>
            <td style='padding:10px; border:1px solid #e5e7eb;'>$description</td>
        </tr>
    " : "";

    $content = "
        <p>Good day,</p>
        <p>Your document has been marked as <strong>released</strong> in the system.</p>

        <table style='width:100%; border-collapse:collapse; margin:20px 0;'>
            <tr>
                <td style='padding:10px; border:1px solid #e5e7eb; background:#f9fafb; width:35%;'><strong>Reference Number</strong></td>
                <td style='padding:10px; border:1px solid #e5e7eb;'>$reference_no</td>
            </tr>
            $extra
            <tr>
                <td style='padding:10px; border:1px solid #e5e7eb; background:#f9fafb;'><strong>Status</strong></td>
                <td style='padding:10px; border:1px solid #e5e7eb;'>Released</td>
            </tr>
        </table>

        <p>You may still view the document history using the link below:</p>

        <p style='margin:18px 0;'>
            <a href='$tracking_url' style='display:inline-block; background:#1d4ed8; color:#ffffff; text-decoration:none; padding:12px 18px; border-radius:8px; font-weight:bold;'>
                View Tracking History
            </a>
        </p>

        <p>Direct tracking link:</p>
        <p style='word-break:break-all;'><a href='$tracking_url'>$tracking_url</a></p>

        <p>Thank you.</p>
    ";

    return buildEmailLayout('Document Released', 'Release Confirmation', $content);
}