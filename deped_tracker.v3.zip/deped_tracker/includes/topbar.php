<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<div style="
    position:fixed;
    top:0;
    left:260px;
    right:0;
    height:70px;
    background:#ffffff;
    border-bottom:1px solid #e5e7eb;
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 24px;
    z-index:999;
">

    <div style="font-weight:bold; color:#0f172a;">
        Welcome, <?php echo $_SESSION['role']; ?>
    </div>

    <div>
        <a href="../auth/logout.php" style="
            background:#ef4444;
            color:#fff;
            padding:8px 14px;
            border-radius:8px;
            text-decoration:none;
            font-size:14px;
        ">Logout</a>
    </div>

</div>

<div style="height:70px;"></div>