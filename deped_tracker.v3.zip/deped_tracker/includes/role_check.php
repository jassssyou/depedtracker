<?php
function requireRole($roles = []) {
    if (!isset($_SESSION['role'])) {
        header("Location: ../auth/login.php");
        exit();
    }

    if (!in_array($_SESSION['role'], $roles)) {
        echo "<script>alert('Access denied.'); window.history.back();</script>";
        exit();
    }
}
?>