<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole([
    'Administrator',
    'Records Personnel',
    'Accounting',
    'Budget',
    'Human Resource',
    'Property',
    'Administrative Officer V',
    'SGOD Secretary',
    'CID Secretary',
    'SDS Secretary',
    'ASDS Secretary'
])) {
    echo "<script>alert('You do not have permission to access this page.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('Invalid document request.'); window.location='documents.php';</script>";
    exit();
}

$document_id = (int) $_GET['id'];
$current_role = $_SESSION['role'] ?? '';
$current_department_id = $_SESSION['department_id'] ?? null;

$is_admin = ($current_role === 'Administrator');
$is_records = ($current_role === 'Records Personnel');

/*
|--------------------------------------------------------------------------
| Fetch document details
|--------------------------------------------------------------------------
*/
$document_query = mysqli_query($conn, "
    SELECT
        d.*,
        dt.document_type_name,
        o.org_name,
        dep.department_name
    FROM documents d
    LEFT JOIN document_types dt ON d.document_type_id = dt.document_type_id
    LEFT JOIN organization o ON d.org_id = o.org_id
    LEFT JOIN departments dep ON d.current_department_id = dep.department_id
    WHERE d.document_id = '$document_id'
    LIMIT 1
");

if (!$document_query || mysqli_num_rows($document_query) === 0) {
    echo "<script>alert('Document not found.'); window.location='documents.php';</script>";
    exit();
}

$document = mysqli_fetch_assoc($document_query);

/*
|--------------------------------------------------------------------------
| Department visibility rule
|--------------------------------------------------------------------------
| Staff can only view documents assigned to them
|--------------------------------------------------------------------------
*/
if (!$is_admin && !$is_records) {
    if (empty($document['current_department_id']) || (int)$document['current_department_id'] !== (int)$current_department_id) {
        echo "<script>alert('You can only view documents assigned to your department.'); window.location='documents.php';</script>";
        exit();
    }
}

/*
|--------------------------------------------------------------------------
| Fetch document logs
|--------------------------------------------------------------------------
*/
$logs_query = mysqli_query($conn, "
    SELECT
        dl.*,
        u.fullname,
        fd.department_name AS from_department_name,
        td.department_name AS to_department_name
    FROM document_logs dl
    LEFT JOIN users u ON dl.updated_by = u.user_id
    LEFT JOIN departments fd ON dl.from_department = fd.department_id
    LEFT JOIN departments td ON dl.to_department = td.department_id
    WHERE dl.document_id = '$document_id'
    ORDER BY dl.action_datetime DESC
");
?>

<div class="main-content">

    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:20px; flex-wrap:wrap; margin-bottom:24px;">
        <div>
            <h2 style="margin:0; font-size:32px; color:#0f172a;">Assigned Document Detail</h2>
            <p style="margin:8px 0 0 0; color:#64748b; font-size:15px;">
                Review document information and update its processing status.
            </p>
        </div>

        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <a href="documents.php" class="btn btn-secondary">Back to Assigned Documents</a>
            <a href="update_status.php?id=<?php echo $document['document_id']; ?>" class="btn btn-primary">Update Status</a>

            <?php if (!empty($document['qr_code'])): ?>
                <a href="../<?php echo e($document['qr_code']); ?>" target="_blank" class="btn btn-dark">View QR</a>
            <?php endif; ?>
        </div>
    </div>

    <div style="display:grid; grid-template-columns:2fr 1fr; gap:24px; align-items:start;">

        <!-- LEFT: DOCUMENT DETAILS -->
        <div class="page-card">
            <h3 style="margin:0 0 18px 0; color:#0f172a;">Document Information</h3>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">

                <div>
                    <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Reference Number</div>
                    <div style="font-size:18px; font-weight:bold; color:#111827;"><?php echo e($document['reference_no']); ?></div>
                </div>

                <div>
                    <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Current Status</div>
                    <span class="status-badge" style="<?php echo getStatusBadgeStyle($document['status']); ?>">
                        <?php echo e($document['status']); ?>
                    </span>
                </div>

                <div>
                    <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Document Type</div>
                    <div style="font-size:16px; color:#111827;">
                        <?php echo e($document['document_type_name'] ?: 'N/A'); ?>
                    </div>
                </div>

                <div>
                    <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Assigned Department</div>
                    <div style="font-size:16px; color:#111827;">
                        <?php echo e($document['department_name'] ?: 'Records Office'); ?>
                    </div>
                </div>

                <div>
                    <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Organization</div>
                    <div style="font-size:16px; color:#111827;">
                        <?php
                        if (!empty($document['org_name'])) {
                            echo e($document['org_name']);
                        } elseif (!empty($document['other_organization'])) {
                            echo e($document['other_organization']);
                        } else {
                            echo 'N/A';
                        }
                        ?>
                    </div>
                </div>

                <div>
                    <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Date Received</div>
                    <div style="font-size:16px; color:#111827;">
                        <?php echo formatDateTime($document['date_received']); ?>
                    </div>
                </div>

                <div>
                    <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Submitted By</div>
                    <div style="font-size:16px; color:#111827;"><?php echo e($document['submitted_by']); ?></div>
                </div>

                <div>
                    <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Client Email</div>
                    <div style="font-size:16px; color:#111827; word-break:break-word;"><?php echo e($document['client_email']); ?></div>
                </div>

                <div style="grid-column:1 / span 2;">
                    <div style="font-size:12px; font-weight:bold; color:#64748b; text-transform:uppercase; margin-bottom:8px;">Description / Subject</div>
                    <div style="border:1px solid #e5e7eb; background:#f8fbff; border-radius:12px; padding:16px; min-height:90px; line-height:1.6; color:#1f2937;">
                        <?php echo nl2br(e($document['description'])); ?>
                    </div>
                </div>

            </div>
        </div>

        <!-- RIGHT: QR + STAFF NOTE -->
        <div style="display:flex; flex-direction:column; gap:20px;">

            <?php if (!empty($document['qr_code'])): ?>
                <div class="page-card" style="text-align:center;">
                    <h3 style="margin:0 0 16px 0; color:#0f172a;">QR Code</h3>
                    <img
                        src="../<?php echo e($document['qr_code']); ?>"
                        alt="QR Code"
                        style="max-width:220px; width:100%; border:1px solid #dbe3ef; background:#fff; padding:10px; border-radius:12px;"
                    >
                    <p style="margin:145px 0 0 0; color:#64748b; font-size:13px;">
                        Public tracking QR for the client.
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ROUTING TIMELINE -->
    <div class="page-card" style="margin-top:24px;">
        <h3 style="margin:0 0 18px 0; color:#0f172a;">Routing Timeline</h3>

        <?php if ($logs_query && mysqli_num_rows($logs_query) > 0): ?>
            <div style="display:flex; flex-direction:column; gap:16px;">
                <?php while ($log = mysqli_fetch_assoc($logs_query)): ?>
                    <div style="border-left:4px solid #1d4ed8; padding:0 0 0 14px;">
                        <div style="font-size:13px; color:#64748b; margin-bottom:6px;">
                            <?php echo formatDateTime($log['action_datetime']); ?>
                        </div>

                        <div style="font-size:18px; font-weight:bold; color:#0f172a; margin-bottom:6px;">
                            <?php echo e($log['status']); ?>
                        </div>

                        <?php if (!empty($log['remarks'])): ?>
                            <div style="color:#374151; margin-bottom:6px; line-height:1.5;">
                                <?php echo e($log['remarks']); ?>
                            </div>
                        <?php endif; ?>

                        <div style="font-size:13px; color:#64748b; margin-bottom:4px;">
                            <strong>Updated By:</strong>
                            <?php echo e($log['fullname'] ?: 'System'); ?>
                        </div>

                        <?php if (!empty($log['from_department_name']) || !empty($log['to_department_name'])): ?>
                            <div style="font-size:13px; color:#64748b;">
                                <strong>Route:</strong>
                                <?php echo e($log['from_department_name'] ?: 'N/A'); ?>
                                →
                                <?php echo e($log['to_department_name'] ?: 'N/A'); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div style="color:#64748b;">No tracking logs found for this document.</div>
        <?php endif; ?>
    </div>

</div>

<?php include '../includes/footer.php'; ?>