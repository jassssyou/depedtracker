<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

/*
|--------------------------------------------------------------------------
| Allowed roles
|--------------------------------------------------------------------------
| Admin and Records can access for testing/visibility,
| but this page is mainly for department staff.
|--------------------------------------------------------------------------
*/
if (!hasRole([
    'Administrator',
    'Records Personnel',
    'Accounting',
    'Budget',
    'Human Resource',
    'Property',
    'Administrative Officer V',
    'SGOD Secretary',
    'CID Secretary',
    'SDS Secretary',
    'ASDS Secretary'
])) {
    echo "<script>alert('You do not have permission to access this page.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

$current_role = $_SESSION['role'] ?? '';
$current_department_id = $_SESSION['department_id'] ?? null;

$is_admin = ($current_role === 'Administrator');
$is_records = ($current_role === 'Records Personnel');

/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/
$search = trim($_GET['search'] ?? '');
$status_filter = trim($_GET['status'] ?? '');

/*
|--------------------------------------------------------------------------
| Build where clause
|--------------------------------------------------------------------------
*/
$where_conditions = [];
$where_conditions[] = "1=1";

/*
|--------------------------------------------------------------------------
| Department visibility rule
|--------------------------------------------------------------------------
| Department staff: only documents currently assigned to them
| Admin / Records: can view all here if needed
|--------------------------------------------------------------------------
*/
if (!$is_admin && !$is_records) {
    $dept_id = (int) $current_department_id;
    $where_conditions[] = "d.current_department_id = '$dept_id'";

    // show only active working items for department staff
    if ($status_filter === '') {
        $where_conditions[] = "d.status IN ('Received', 'In Process', 'Approved')";
    }
}

if ($search !== '') {
    $search_escaped = mysqli_real_escape_string($conn, $search);
    $where_conditions[] = "(
        d.reference_no LIKE '%$search_escaped%' OR
        d.submitted_by LIKE '%$search_escaped%' OR
        d.client_email LIKE '%$search_escaped%' OR
        d.description LIKE '%$search_escaped%'
    )";
}

if ($status_filter !== '') {
    $status_escaped = mysqli_real_escape_string($conn, $status_filter);
    $where_conditions[] = "d.status = '$status_escaped'";
}

$where_sql = implode(' AND ', $where_conditions);

/*
|--------------------------------------------------------------------------
| Fetch documents
|--------------------------------------------------------------------------
*/
$query = "
    SELECT
        d.*,
        dt.document_type_name,
        o.org_name,
        dep.department_name
    FROM documents d
    LEFT JOIN document_types dt ON d.document_type_id = dt.document_type_id
    LEFT JOIN organization o ON d.org_id = o.org_id
    LEFT JOIN departments dep ON d.current_department_id = dep.department_id
    WHERE $where_sql
    ORDER BY d.document_id DESC
";

$result = mysqli_query($conn, $query);
?>

<div class="main-content">

    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:20px; flex-wrap:wrap; margin-bottom:24px;">
        <div>
            <h2 style="margin:0; font-size:32px; color:#0f172a;">Assigned Documents</h2>
            <p style="margin:8px 0 0 0; color:#64748b; font-size:15px;">
                View and process documents currently assigned to your department.
            </p>
        </div>

        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </div>
    </div>

    <!-- Filter Card -->
    <div class="page-card" style="margin-bottom:24px;">
        <form method="GET" style="display:grid; grid-template-columns:2fr 1fr 220px; gap:14px; align-items:end;">
            
            <div>
                <label class="label">Search</label>
                <input
                    type="text"
                    name="search"
                    class="form-control"
                    placeholder="Reference no, submitted by, email, or description"
                    value="<?php echo e($search); ?>"
                >
            </div>

            <div>
                <label class="label">Status</label>
                <select name="status" class="form-control">
                    <option value="">All Active Statuses</option>
                    <option value="Received" <?php echo ($status_filter === 'Received') ? 'selected' : ''; ?>>Received</option>
                    <option value="In Process" <?php echo ($status_filter === 'In Process') ? 'selected' : ''; ?>>In Process</option>
                    <option value="Approved" <?php echo ($status_filter === 'Approved') ? 'selected' : ''; ?>>Approved</option>
                    <option value="Forwarded" <?php echo ($status_filter === 'Forwarded') ? 'selected' : ''; ?>>Forwarded</option>
                </select>
            </div>

            <div style="display:flex; gap:8px;">
                <button type="submit" class="btn btn-primary" style="width:100%;">Filter</button>
                <a href="documents.php" class="btn btn-secondary" style="width:100%; text-align:center;">Reset</a>
            </div>
        </form>
    </div>

    <!-- Staff Note -->
    <div class="page-card" style="margin-bottom:24px; background:#eff6ff; border:1px solid #bfdbfe;">
        <div style="color:#1e3a8a; font-size:14px; line-height:1.7;">
            <strong>Note:</strong>
            Department staff can only view documents assigned to their department.  
            Once a document is forwarded back to Records, it will no longer appear in this active list.
        </div>
    </div>

    <!-- Table -->
    <div class="page-card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:10px;">
            <h3 style="margin:0; color:#0f172a;">Department Work Queue</h3>
            <div style="font-size:14px; color:#64748b;">
                Total Result:
                <strong><?php echo ($result) ? mysqli_num_rows($result) : 0; ?></strong>
            </div>
        </div>

        <?php if ($result && mysqli_num_rows($result) > 0): ?>
            <div style="overflow-x:auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Reference No.</th>
                            <th>Document Type</th>
                            <th>Organization</th>
                            <th>Submitted By</th>
                            <th>Status</th>
                            <th>Date Received</th>
                            <th style="min-width:180px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($row['reference_no']); ?></strong>
                                </td>

                                <td>
                                    <?php echo e($row['document_type_name'] ?: 'N/A'); ?>
                                </td>

                                <td>
                                    <?php
                                    if (!empty($row['org_name'])) {
                                        echo e($row['org_name']);
                                    } elseif (!empty($row['other_organization'])) {
                                        echo e($row['other_organization']);
                                    } else {
                                        echo 'N/A';
                                    }
                                    ?>
                                </td>

                                <td><?php echo e($row['submitted_by']); ?></td>

                                <td>
                                    <span class="status-badge" style="<?php echo getStatusBadgeStyle($row['status']); ?>">
                                        <?php echo e($row['status']); ?>
                                    </span>
                                </td>

                                <td><?php echo formatDateTime($row['date_received']); ?></td>

                                <td>
                                    <div style="display:flex; flex-wrap:wrap; gap:8px;">
                                        <a href="document_view.php?id=<?php echo $row['document_id']; ?>"
                                           style="background:#dbeafe; color:#1d4ed8; padding:7px 12px; border-radius:8px; font-size:13px; font-weight:bold;">
                                            View
                                        </a>

                                        <a href="update_status.php?id=<?php echo $row['document_id']; ?>"
                                           style="background:#ede9fe; color:#7c3aed; padding:7px 12px; border-radius:8px; font-size:13px; font-weight:bold;">
                                            Update
                                        </a>

                                        <?php if (!empty($row['qr_code'])): ?>
                                            <a href="../<?php echo e($row['qr_code']); ?>" target="_blank"
                                               style="background:#e2e8f0; color:#0f172a; padding:7px 12px; border-radius:8px; font-size:13px; font-weight:bold;">
                                                QR
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div style="padding:20px 0; color:#64748b;">
                No assigned documents found.
            </div>
        <?php endif; ?>
    </div>

</div>

<?php include '../includes/footer.php'; ?>