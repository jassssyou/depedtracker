<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole([
    'Accounting','Budget','Human Resource','Property',
    'Administrative Officer','SDS Secretary','ASDS Secretary',
    'SGOD Secretary','CID Secretary'
])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

$department_id = $_SESSION['department_id'];

/*
|--------------------------------------------------------------------------
| Dashboard Stats
|--------------------------------------------------------------------------
*/
$total = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) AS total
    FROM documents
    WHERE current_department_id = '$department_id'
"))['total'] ?? 0;

$received = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) AS total
    FROM documents
    WHERE current_department_id = '$department_id'
    AND status = 'Received'
"))['total'] ?? 0;

$in_process = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) AS total
    FROM documents
    WHERE current_department_id = '$department_id'
    AND status = 'In Process'
"))['total'] ?? 0;

$approved = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) AS total
    FROM documents
    WHERE current_department_id = '$department_id'
    AND status = 'Approved'
"))['total'] ?? 0;

/*
|--------------------------------------------------------------------------
| Recent Documents
|--------------------------------------------------------------------------
*/
$recent_docs = mysqli_query($conn, "
    SELECT *
    FROM documents
    WHERE current_department_id = '$department_id'
    ORDER BY date_received DESC
    LIMIT 5
");
?>

<div class="main-content">

<style>
.dashboard-hero {
    background: linear-gradient(135deg,#1d4ed8,#2563eb,#3b82f6);
    color:#fff;
    padding:24px;
    border-radius:16px;
    margin-bottom:20px;
}

.stat-grid {
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
    gap:16px;
    margin-bottom:20px;
}

.stat-card {
    background:#fff;
    padding:18px;
    border-radius:12px;
    box-shadow:0 4px 12px rgba(0,0,0,0.06);
}

.stat-title {
    font-size:14px;
    color:#64748b;
}

.stat-value {
    font-size:28px;
    font-weight:bold;
    color:#0f172a;
}

.quick-actions {
    display:flex;
    gap:10px;
    margin-bottom:20px;
    flex-wrap:wrap;
}

.btn-action {
    padding:10px 14px;
    border-radius:8px;
    background:#1d4ed8;
    color:#fff;
    font-size:14px;
}
</style>

<div class="dashboard-hero">
    <h2>Staff Dashboard</h2>
    <p>Manage and process documents assigned to your department.</p>
</div>

<!-- STATS -->
<div class="stat-grid">
    <div class="stat-card">
        <div class="stat-title">Total Assigned</div>
        <div class="stat-value"><?php echo $total; ?></div>
    </div>

    <div class="stat-card">
        <div class="stat-title">Received</div>
        <div class="stat-value"><?php echo $received; ?></div>
    </div>

    <div class="stat-card">
        <div class="stat-title">In Process</div>
        <div class="stat-value"><?php echo $in_process; ?></div>
    </div>

    <div class="stat-card">
        <div class="stat-title">Approved</div>
        <div class="stat-value"><?php echo $approved; ?></div>
    </div>
</div>

<!-- ACTIONS -->
<div class="quick-actions">
    <a href="documents.php" class="btn-action">View Assigned Documents</a>
</div>

<!-- RECENT DOCUMENTS -->
<div class="page-card">
    <h3>Recent Documents</h3>

    <?php if ($recent_docs && mysqli_num_rows($recent_docs) > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Reference</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($recent_docs)): ?>
                <tr>
                    <td><?php echo e($row['reference_no']); ?></td>
                    <td><?php echo e($row['status']); ?></td>
                    <td><?php echo date('M d, Y', strtotime($row['date_received'])); ?></td>
                    <td>
                        <a href="document_view.php?id=<?php echo $row['document_id']; ?>" class="btn-secondary">View</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="color:#64748b;">No documents assigned.</p>
    <?php endif; ?>
</div>

</div>

<?php include '../includes/footer.php'; ?>