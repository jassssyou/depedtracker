<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole([
    'Accounting','Budget','Human Resource','Property',
    'Administrative Officer','SDS Secretary','ASDS Secretary',
    'SGOD Secretary','CID Secretary'
])) {
    echo "<script>alert('Access denied.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

if (!isset($_GET['id'])) {
    die("Invalid request.");
}

$document_id = (int) $_GET['id'];
$user_id = $_SESSION['user_id'];
$current_department = $_SESSION['department_id'];

/*
|--------------------------------------------------------------------------
| CONFIG: RECORDS DEPARTMENT ID
|--------------------------------------------------------------------------
*/
$records_department_id = 2; // IMPORTANT

/*
|--------------------------------------------------------------------------
| Fetch document
|--------------------------------------------------------------------------
*/
$doc = mysqli_query($conn, "
    SELECT *
    FROM documents
    WHERE document_id = '$document_id'
    AND current_department_id = '$current_department'
");

if (!$doc || mysqli_num_rows($doc) == 0) {
    echo "<script>alert('Document not found or not assigned to your department.'); window.location='documents.php';</script>";
    exit();
}

$document = mysqli_fetch_assoc($doc);

$error = '';

/*
|--------------------------------------------------------------------------
| Submit return
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $remarks = mysqli_real_escape_string($conn, $_POST['remarks'] ?? '');

    if (empty($remarks)) {
        $error = "Remarks is required.";
    } else {

        /*
        |--------------------------------------------------------------------------
        | Update document
        |--------------------------------------------------------------------------
        */
        mysqli_query($conn, "
            UPDATE documents
            SET
                status = 'For Releasing',
                current_department_id = '$records_department_id'
            WHERE document_id = '$document_id'
        ");

        /*
        |--------------------------------------------------------------------------
        | Insert log
        |--------------------------------------------------------------------------
        */
        mysqli_query($conn, "
            INSERT INTO document_logs (
                document_id,
                from_department,
                to_department,
                status,
                remarks,
                updated_by,
                action_datetime
            ) VALUES (
                '$document_id',
                '$current_department',
                '$records_department_id',
                'For Releasing',
                '$remarks',
                '$user_id',
                NOW()
            )
        ");

        /*
        |--------------------------------------------------------------------------
        | Send Email (Ready for Release)
        |--------------------------------------------------------------------------
        */
        if (function_exists('sendDocumentEmail')) {

            $reference_no = $document['reference_no'];
            $email = $document['client_email'];

            $tracking_url = "http://localhost/deped_tracker/public/track.php?ref=" . urlencode($reference_no);

            $subject = "Document Ready for Release - $reference_no";

            $body = buildReadyForReleaseEmailTemplate(
                $reference_no,
                $tracking_url,
                $document['description']
            );

            $sent = sendDocumentEmail($email, $subject, $body);

            $subject_escaped = mysqli_real_escape_string($conn, $subject);
            $body_escaped = mysqli_real_escape_string($conn, $body);
            $email_type = $sent ? 'Ready for Release' : 'Ready for Release - Failed';

            mysqli_query($conn, "
                INSERT INTO email_notifications (
                    document_id,
                    recipient_email,
                    subject,
                    message,
                    type,
                    sent_at
                ) VALUES (
                    '$document_id',
                    '{$document['client_email']}',
                    '$subject_escaped',
                    '$body_escaped',
                    '$email_type',
                    NOW()
                )
            ");
        }

        /*
        |--------------------------------------------------------------------------
        | System Log
        |--------------------------------------------------------------------------
        */
        $activity = mysqli_real_escape_string($conn, "Returned document to Records: {$document['reference_no']}");
        mysqli_query($conn, "
            INSERT INTO system_logs (user_id, activity, log_time)
            VALUES ('$user_id', '$activity', NOW())
        ");

        echo "<script>alert('Document successfully returned to Records.'); window.location='documents.php';</script>";
        exit();
    }
}
?>

<div class="main-content">

<style>
.return-card {
    max-width:600px;
}
</style>

<div class="page-card return-card">
    <h2>Return Document to Records</h2>

    <p><strong>Reference:</strong> <?php echo e($document['reference_no']); ?></p>
    <p><strong>Description:</strong> <?php echo e($document['description']); ?></p>

    <?php if ($error): ?>
        <div class="alert alert-error"><?php echo e($error); ?></div>
    <?php endif; ?>

    <form method="POST">

        <div style="margin-bottom:15px;">
            <label class="label">Remarks *</label>
            <textarea name="remarks" class="form-control" rows="4"
                placeholder="Enter remarks before returning document"
                required></textarea>
        </div>

        <button class="btn btn-primary">Return to Records</button>
        <a href="documents.php" class="btn btn-secondary">Cancel</a>

    </form>
</div>

</div>

<?php include '../includes/footer.php'; ?>