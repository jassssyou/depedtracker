<?php
include '../includes/auth.php';
include '../config/database.php';
include '../includes/functions.php';

if (!hasRole(['Administrator', 'Records Personnel', 'Accounting', 'Budget', 'Human Resource', 'Property', 'Administrative Officer V', 'SGOD Secretary', 'CID Secretary', 'SDS Secretary', 'ASDS Secretary'])) {
    echo "<script>alert('You do not have permission to access this page.'); window.location='../auth/login.php';</script>";
    exit();
}

include '../includes/header.php';
include '../includes/sidebar.php';

$mailer_available = file_exists('../includes/mailer.php');
if ($mailer_available) {
    include_once '../includes/mailer.php';
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('Invalid document request.'); window.history.back();</script>";
    exit();
}

$document_id = (int) $_GET['id'];
$current_user_id = $_SESSION['user_id'];
$current_role = $_SESSION['role'] ?? '';
$current_department_id = $_SESSION['department_id'] ?? null;

/*
|--------------------------------------------------------------------------
| Get document details
|--------------------------------------------------------------------------
*/
$doc_query = mysqli_query($conn, "
    SELECT 
        d.*,
        dt.document_type_name,
        o.org_name,
        dep.department_name
    FROM documents d
    LEFT JOIN document_types dt ON d.document_type_id = dt.document_type_id
    LEFT JOIN organization o ON d.org_id = o.org_id
    LEFT JOIN departments dep ON d.current_department_id = dep.department_id
    WHERE d.document_id = '$document_id'
    LIMIT 1
");

if (!$doc_query || mysqli_num_rows($doc_query) === 0) {
    echo "<script>alert('Document not found.'); window.location='../records/documents.php';</script>";
    exit();
}

$document = mysqli_fetch_assoc($doc_query);

/*
|--------------------------------------------------------------------------
| Access rules
|--------------------------------------------------------------------------
| Admin: can access all
| Records Personnel: can access all
| Other staff: only documents assigned to their department
|--------------------------------------------------------------------------
*/
$is_admin = ($current_role === 'Administrator');
$is_records = ($current_role === 'Records Personnel');
$is_department_staff = (!$is_admin && !$is_records);

if ($is_department_staff) {
    if (empty($document['current_department_id']) || (int)$document['current_department_id'] !== (int)$current_department_id) {
        echo "<script>alert('You can only update documents assigned to your department.'); window.history.back();</script>";
        exit();
    }
}

/*
|--------------------------------------------------------------------------
| Get Records department ID if exists
|--------------------------------------------------------------------------
| Used when returning a document to Records or setting For Releasing
|--------------------------------------------------------------------------
*/
$records_department_id = null;
$records_dept_query = mysqli_query($conn, "SELECT department_id FROM departments WHERE department_name LIKE '%Records%' LIMIT 1");
if ($records_dept_query && mysqli_num_rows($records_dept_query) > 0) {
    $records_department_id = (int) mysqli_fetch_assoc($records_dept_query)['department_id'];
}

/*
|--------------------------------------------------------------------------
| Fetch active departments
|--------------------------------------------------------------------------
*/
$departments = mysqli_query($conn, "SELECT department_id, department_name FROM departments WHERE status='Active' ORDER BY department_name ASC");

/*
|--------------------------------------------------------------------------
| Allowed statuses by role
|--------------------------------------------------------------------------
*/
$allowed_statuses = [];

if ($is_admin || $is_records) {
    $allowed_statuses = ['Forwarded', 'For Releasing', 'Released'];
} else {
    $allowed_statuses = ['Received', 'In Process', 'Approved', 'Forwarded'];
}

/*
|--------------------------------------------------------------------------
| Form defaults
|--------------------------------------------------------------------------
*/
$errors = [];
$new_status = '';
$remarks = '';
$to_department = '';

/*
|--------------------------------------------------------------------------
| Handle update
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = trim($_POST['status'] ?? '');
    $remarks = trim($_POST['remarks'] ?? '');
    $to_department = trim($_POST['to_department'] ?? '');

    if ($new_status === '') {
        $errors[] = "Please select a status.";
    } elseif (!in_array($new_status, $allowed_statuses, true)) {
        $errors[] = "You are not allowed to use the selected status.";
    }

    if ($remarks === '') {
        $errors[] = "Remarks are required.";
    }

    /*
    |--------------------------------------------------------------------------
    | Routing rules
    |--------------------------------------------------------------------------
    */
    $from_department = !empty($document['current_department_id']) ? (int)$document['current_department_id'] : null;
    $target_department_id = null;

    if (empty($errors)) {
        if ($is_admin || $is_records) {
            // Records/Admin flow
            if ($new_status === 'Forwarded') {
                if ($to_department === '') {
                    $errors[] = "Please select the department to forward this document to.";
                } else {
                    $target_department_id = (int) $to_department;
                }
            } elseif ($new_status === 'For Releasing') {
                $target_department_id = $records_department_id ?: $from_department;
            } elseif ($new_status === 'Released') {
                $target_department_id = $records_department_id ?: $from_department;
            }
        } else {
            // Department staff flow
            if ($new_status === 'Received' || $new_status === 'In Process' || $new_status === 'Approved') {
                $target_department_id = $from_department;
            } elseif ($new_status === 'Forwarded') {
                // For department staff, Forwarded means returned to Records
                $target_department_id = $records_department_id;
                if (!$target_department_id) {
                    $errors[] = "Records department is not configured. Please add it in departments first.";
                }
            }
        }
    }

    if (empty($errors)) {
        $new_status_escaped = mysqli_real_escape_string($conn, $new_status);
        $remarks_escaped = mysqli_real_escape_string($conn, $remarks);

        $update_sql = "
            UPDATE documents
            SET 
                status = '$new_status_escaped',
                current_department_id = " . ($target_department_id !== null ? "'$target_department_id'" : "NULL") . "
            WHERE document_id = '$document_id'
        ";

        $updated = mysqli_query($conn, $update_sql);

        if ($updated) {
            mysqli_query($conn, "
                INSERT INTO document_logs (
                    document_id,
                    from_department,
                    to_department,
                    status,
                    remarks,
                    updated_by,
                    action_datetime
                ) VALUES (
                    '$document_id',
                    " . ($from_department !== null ? "'$from_department'" : "NULL") . ",
                    " . ($target_department_id !== null ? "'$target_department_id'" : "NULL") . ",
                    '$new_status_escaped',
                    '$remarks_escaped',
                    '$current_user_id',
                    NOW()
                )
            ");

            /*
            |--------------------------------------------------------------------------
            | Email triggers
            |--------------------------------------------------------------------------
            | Only send email on:
            | - For Releasing
            | - Released
            |--------------------------------------------------------------------------
            */
            if (
                $mailer_available &&
                function_exists('sendDocumentEmail') &&
                !empty($document['client_email'])
            ) {
                $tracking_url = "http://localhost/deped_tracker/public/track.php?ref=" . urlencode($document['reference_no']);
                $email = $document['client_email'];
                $reference_no = $document['reference_no'];
                $description = $document['description'];
                $qr_relative_path = !empty($document['qr_code']) ? '../' . $document['qr_code'] : null;
                $qr_filename = !empty($document['qr_code']) ? basename($document['qr_code']) : null;

                $subject = '';
                $body = '';
                $email_type = '';

                if ($new_status === 'For Releasing' && function_exists('buildReadyForReleaseEmailTemplate')) {
                    $subject = "Document Ready for Release - $reference_no";
                    $body = buildReadyForReleaseEmailTemplate($reference_no, $tracking_url, $description);
                    $email_type = 'Ready for Release';
                } elseif ($new_status === 'Released' && function_exists('buildReleasedEmailTemplate')) {
                    $subject = "Document Released - $reference_no";
                    $body = buildReleasedEmailTemplate($reference_no, $tracking_url, $description);
                    $email_type = 'Released';
                }

                if ($subject !== '' && $body !== '') {
                    $sent = sendDocumentEmail($email, $subject, $body, $qr_relative_path, $qr_filename);

                    $email_escaped = mysqli_real_escape_string($conn, $email);
                    $subject_escaped = mysqli_real_escape_string($conn, $subject);
                    $body_escaped = mysqli_real_escape_string($conn, $body);
                    $type_escaped = mysqli_real_escape_string($conn, $sent ? $email_type : $email_type . ' - Failed');

                    mysqli_query($conn, "
                        INSERT INTO email_notifications (
                            document_id,
                            recipient_email,
                            subject,
                            message,
                            type,
                            sent_at
                        ) VALUES (
                            '$document_id',
                            '$email_escaped',
                            '$subject_escaped',
                            '$body_escaped',
                            '$type_escaped',
                            NOW()
                        )
                    ");
                }
            }

            if ($is_admin || $is_records) {
                echo "<script>alert('Document updated successfully.'); window.location='../records/document_view.php?id=$document_id';</script>";
            } else {
                echo "<script>alert('Document updated successfully.'); window.location='documents.php';</script>";
            }
            exit();
        } else {
            $errors[] = "Failed to update document: " . mysqli_error($conn);
        }
    }
}
?>

<div class="main-content">

    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:20px; flex-wrap:wrap; margin-bottom:24px;">
        <div>
            <h2 style="margin:0; font-size:32px; color:#0f172a;">Update Status</h2>
            <p style="margin:8px 0 0 0; color:#64748b; font-size:15px;">
                Update the processing status and routing of the selected document.
            </p>
        </div>

        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <?php if ($is_admin || $is_records): ?>
                <a href="../records/document_view.php?id=<?php echo $document['document_id']; ?>" class="btn btn-secondary">Back to Details</a>
            <?php else: ?>
                <a href="documents.php" class="btn btn-secondary">Back to Assigned Documents</a>
            <?php endif; ?>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-error">
            <strong>Please fix the following:</strong>
            <ul style="margin:10px 0 0 20px;">
                <?php foreach ($errors as $error): ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div style="display:grid; grid-template-columns:1.5fr 1fr; gap:24px; align-items:start;">
        
        <!-- LEFT: FORM -->
        <div class="page-card">
            <h3 style="margin:0 0 18px 0; color:#0f172a;">Status Update Form</h3>

            <form method="POST">
                <div style="margin-bottom:18px;">
                    <label class="label">New Status</label>
                    <select name="status" id="status" class="form-control" onchange="handleStatusUI()" required>
                        <option value="">Select status</option>
                        <?php foreach ($allowed_statuses as $status_option): ?>
                            <option value="<?php echo e($status_option); ?>" <?php echo ($new_status === $status_option) ? 'selected' : ''; ?>>
                                <?php
                                if ($is_department_staff && $status_option === 'Forwarded') {
                                    echo 'Forwarded (Return to Records)';
                                } else {
                                    echo e($status_option);
                                }
                                ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div id="forwardDeptWrapper" style="margin-bottom:18px; display:none;">
                    <label class="label">
                        <?php echo ($is_admin || $is_records) ? 'Forward To Department' : 'Return To Department'; ?>
                    </label>
                    <select name="to_department" id="to_department" class="form-control">
                        <option value="">Select department</option>
                        <?php if ($departments): ?>
                            <?php while ($dept = mysqli_fetch_assoc($departments)): ?>
                                <option value="<?php echo $dept['department_id']; ?>" <?php echo ($to_department == $dept['department_id']) ? 'selected' : ''; ?>>
                                    <?php echo e($dept['department_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div style="margin-bottom:18px;">
                    <label class="label">Remarks</label>
                    <textarea
                        name="remarks"
                        class="form-control"
                        rows="5"
                        placeholder="Enter processing notes, routing reason, or release remarks"
                        required
                    ><?php echo e($remarks); ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Save Update</button>
            </form>
        </div>

        <!-- RIGHT: DOCUMENT SUMMARY -->
        <div class="page-card">
            <h3 style="margin:0 0 18px 0; color:#0f172a;">Document Summary</h3>

            <div style="display:flex; flex-direction:column; gap:14px; font-size:14px; color:#374151; line-height:1.6;">
                <div>
                    <div style="font-size:12px; color:#64748b; text-transform:uppercase; font-weight:bold;">Reference No.</div>
                    <div style="font-size:16px; font-weight:bold;"><?php echo e($document['reference_no']); ?></div>
                </div>

                <div>
                    <div style="font-size:12px; color:#64748b; text-transform:uppercase; font-weight:bold;">Current Status</div>
                    <span class="status-badge" style="<?php echo getStatusBadgeStyle($document['status']); ?>">
                        <?php echo e($document['status']); ?>
                    </span>
                </div>

                <div>
                    <div style="font-size:12px; color:#64748b; text-transform:uppercase; font-weight:bold;">Document Type</div>
                    <div><?php echo e($document['document_type_name'] ?: 'N/A'); ?></div>
                </div>

                <div>
                    <div style="font-size:12px; color:#64748b; text-transform:uppercase; font-weight:bold;">Organization</div>
                    <div>
                        <?php
                        if (!empty($document['org_name'])) {
                            echo e($document['org_name']);
                        } elseif (!empty($document['other_organization'])) {
                            echo e($document['other_organization']);
                        } else {
                            echo 'N/A';
                        }
                        ?>
                    </div>
                </div>

                <div>
                    <div style="font-size:12px; color:#64748b; text-transform:uppercase; font-weight:bold;">Current Department</div>
                    <div><?php echo e($document['department_name'] ?: 'Records Office'); ?></div>
                </div>

                <div>
                    <div style="font-size:12px; color:#64748b; text-transform:uppercase; font-weight:bold;">Submitted By</div>
                    <div><?php echo e($document['submitted_by']); ?></div>
                </div>

                <div>
                    <div style="font-size:12px; color:#64748b; text-transform:uppercase; font-weight:bold;">Description</div>
                    <div style="border:1px solid #e5e7eb; background:#f8fbff; border-radius:12px; padding:12px;">
                        <?php echo nl2br(e($document['description'])); ?>
                    </div>
                </div>

                <?php if ($is_department_staff): ?>
                    <div style="margin-top:6px; padding:12px; border-radius:10px; background:#eff6ff; color:#1e3a8a; font-size:13px;">
                        You can only update documents assigned to your department and return them to Records when processing is complete.
                    </div>
                <?php else: ?>
                    <div style="margin-top:6px; padding:12px; border-radius:10px; background:#eff6ff; color:#1e3a8a; font-size:13px;">
                        Records Personnel can forward documents, prepare them for release, and mark them as released.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>

<script>
function handleStatusUI() {
    const status = document.getElementById('status').value;
    const forwardDeptWrapper = document.getElementById('forwardDeptWrapper');

    if (status === 'Forwarded') {
        forwardDeptWrapper.style.display = 'block';
    } else {
        forwardDeptWrapper.style.display = 'none';
        document.getElementById('to_department').value = '';
    }
}

handleStatusUI();
</script>

<?php include '../includes/footer.php'; ?>