<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['user_id'])) {
    $role = $_SESSION['role'] ?? '';

    if ($role === 'Administrator') {
        header("Location: ../admin/dashboard.php");
    } elseif ($role === 'Records Personnel') {
        header("Location: ../records/dashboard.php");
    } else {
        header("Location: ../staff/dashboard.php");
    }
    exit();
}

$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Login - DepEd Talisay Document Tracker</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        html, body {
            width: 100%;
            min-height: 100%;
            margin: 0;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(
                180deg,
                #1d4ed8 25%,
                #4777e8 34%,
                #eaf0fb 24%,
                #eef3fb 100%
            );
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            color: #111827;
        }

        .page-shell {
            width: 100%;
            min-height: calc(100vh - 40px);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-wrapper {
            width: 100%;
            max-width: 520px;
        }

        .brand-box {
            text-align: center;
            margin-bottom: 24px;
            color: #ffffff;
        }

        .brand-logo {
            width: 118px;
            height: 118px;
            margin: 0 auto 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .brand-logo img {
            width: 100%;
            height: auto;
            display: block;
        }

        .brand-title {
            margin: 0;
            font-size: 36px;
            font-weight: 700;
            line-height: 1.1;
            color: #ffffff;
        }

        .brand-subtitle {
            margin-top: 10px;
            font-size: 15px;
            color: rgba(255,255,255,0.96);
            line-height: 1.5;
        }

        .login-card {
            background: #ffffff;
            border-radius: 24px;
            padding: 34px 30px;
            box-shadow: 0 24px 45px rgba(15, 23, 42, 0.14);
            width: 100%;
        }

        .login-card h2 {
            margin: 0 0 8px 0;
            font-size: 30px;
            color: #111827;
            text-align: center;
        }

        .login-card p {
            margin: 0 0 24px 0;
            text-align: center;
            color: #4b5563;
            font-size: 14px;
        }

        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
            padding: 12px 14px;
            border-radius: 12px;
            margin-bottom: 18px;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 700;
            color: #111827;
            font-size: 14px;
        }

        .input-wrapper {
            position: relative;
        }

        .form-control {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid #cbd5e1;
            border-radius: 14px;
            font-size: 15px;
            outline: none;
            transition: border-color 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
            background: #f8fafc;
            color: #111827;
        }

        .password-input {
            padding-right: 52px;
        }

        .form-control::placeholder {
            color: #64748b;
        }

        .form-control:focus {
            border-color: #1d4ed8;
            box-shadow: 0 0 0 4px rgba(29, 78, 216, 0.10);
            background: #ffffff;
        }

        .toggle-password {
            position: absolute;
            top: 50%;
            right: 14px;
            transform: translateY(-50%);
            width: 32px;
            height: 32px;
            border: none;
            background: transparent;
            color: #475569;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            padding: 0;
        }

        .toggle-password:hover {
            background: #eef2ff;
            color: #1d4ed8;
        }

        .toggle-password svg {
            width: 20px;
            height: 20px;
            display: block;
        }

        .login-btn {
            width: 100%;
            border: none;
            background: #1d4ed8;
            color: #ffffff;
            padding: 14px;
            border-radius: 14px;
            font-size: 17px;
            font-weight: 700;
            cursor: pointer;
            transition: background 0.2s ease, transform 0.1s ease;
            margin-top: 4px;
        }

        .login-btn:hover {
            background: #1e40af;
        }

        .login-btn:active {
            transform: scale(0.99);
        }

        .extra-links {
            margin-top: 20px;
            text-align: center;
        }

        .extra-links a {
            color: #475569;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
        }

        .extra-links a:hover {
            color: #1d4ed8;
        }

        .footer-note {
            margin-top: 18px;
            text-align: center;
            font-size: 12px;
            color: #64748b;
            line-height: 1.5;
        }

        @media (max-width: 768px) {
            body {
                padding: 16px;
            }

            .page-shell {
                min-height: calc(100vh - 32px);
                align-items: center;
            }

            .login-wrapper {
                max-width: 100%;
            }

            .brand-logo {
                width: 100px;
                height: 100px;
            }

            .brand-title {
                font-size: 30px;
            }

            .brand-subtitle {
                font-size: 14px;
            }

            .login-card {
                padding: 26px 20px;
                border-radius: 20px;
            }

            .login-card h2 {
                font-size: 26px;
            }
        }

        @media (max-width: 480px) {
            body {
                padding: 12px;
            }

            .page-shell {
                min-height: calc(100vh - 24px);
            }

            .brand-logo {
                width: 88px;
                height: 88px;
            }

            .brand-title {
                font-size: 26px;
            }

            .brand-subtitle {
                font-size: 13px;
            }

            .login-card {
                padding: 22px 16px;
                border-radius: 18px;
            }

            .login-card h2 {
                font-size: 24px;
            }

            .form-control {
                font-size: 14px;
                padding: 13px 14px;
            }

            .password-input {
                padding-right: 48px;
            }

            .login-btn {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>

<div class="page-shell">
    <div class="login-wrapper">
        <div class="brand-box">
            <div class="brand-logo">
                <img src="../assets/images/logo.png" alt="DepEd Logo">
            </div>
            <h1 class="brand-title">SDO Staff Portal</h1>
            <div class="brand-subtitle">DepEd Talisay Document Tracking Management System</div>
        </div>

        <div class="login-card">
            <h2>Sign In</h2>
            <p>Authorized personnel access only</p>

            <?php if ($error === 'invalid') : ?>
                <div class="alert-error">Invalid username or password.</div>
            <?php elseif ($error === 'inactive') : ?>
                <div class="alert-error">Your account is inactive. Please contact the administrator.</div>
            <?php elseif ($error === 'required') : ?>
                <div class="alert-error">Please enter your username and password.</div>
            <?php endif; ?>

            <form action="login_process.php" method="POST">
                <div class="form-group">
                    <label class="form-label">Username</label>
                    <div class="input-wrapper">
                        <input type="text" name="username" class="form-control" placeholder="Enter your username" required>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Password</label>
                    <div class="input-wrapper">
                        <input type="password" name="password" id="password" class="form-control password-input" placeholder="Enter your password" required>
                        <button type="button" class="toggle-password" onclick="togglePassword()" aria-label="Toggle password visibility">
                            
                        </button>
                    </div>
                </div>

                <button type="submit" class="login-btn">Sign In</button>
            </form>

            <div class="extra-links">
                <a href="../depedtracker.php">← Back to Public Tracking</a>
            </div>

            <div class="footer-note">
                © <?php echo date('Y'); ?> Department of Education - Talisay City Division
            </div>
        </div>
    </div>
</div>

<script>
function togglePassword() {
    const passwordInput = document.getElementById('password');
    const eyeOpen = document.getElementById('eyeOpen');
    const eyeClosed = document.getElementById('eyeClosed');

    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeOpen.style.display = 'none';
        eyeClosed.style.display = 'block';
    } else {
        passwordInput.type = 'password';
        eyeOpen.style.display = 'block';
        eyeClosed.style.display = 'none';
    }
}
</script>

</body>
</html>