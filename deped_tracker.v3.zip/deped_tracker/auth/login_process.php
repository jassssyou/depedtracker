<?php
session_start();
include '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login.php");
    exit();
}

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    header("Location: login.php?error=required");
    exit();
}

$username_escaped = mysqli_real_escape_string($conn, $username);

$query = "SELECT * FROM users WHERE username = '$username_escaped' LIMIT 1";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) === 0) {
    header("Location: login.php?error=invalid");
    exit();
}

$row = mysqli_fetch_assoc($result);

if (!isset($row['status']) || $row['status'] !== 'Active') {
    header("Location: login.php?error=inactive");
    exit();
}

/*
|--------------------------------------------------------------------------
| Support both plain text and hashed passwords
|--------------------------------------------------------------------------
| Your current database password appears to be plain text.
| This allows login now, and still supports hashed passwords later.
*/
$password_matched = false;

if ($password === $row['password']) {
    $password_matched = true;
} elseif (password_verify($password, $row['password'])) {
    $password_matched = true;
}

if (!$password_matched) {
    header("Location: login.php?error=invalid");
    exit();
}

/*
|--------------------------------------------------------------------------
| Store session data
|--------------------------------------------------------------------------
*/
$_SESSION['user_id'] = $row['user_id'];
$_SESSION['fullname'] = $row['fullname'];
$_SESSION['username'] = $row['username'];
$_SESSION['role'] = $row['role'];
$_SESSION['department_id'] = $row['department_id'];

/*
|--------------------------------------------------------------------------
| Optional system log
|--------------------------------------------------------------------------
*/
$user_id = (int) $row['user_id'];
$activity = mysqli_real_escape_string($conn, "Logged in to the system");

if (mysqli_query($conn, "SHOW TABLES LIKE 'system_logs'") && mysqli_num_rows(mysqli_query($conn, "SHOW TABLES LIKE 'system_logs'")) > 0) {
    @mysqli_query($conn, "INSERT INTO system_logs (user_id, activity, log_time)
                          VALUES ('$user_id', '$activity', NOW())");
}

/*
|--------------------------------------------------------------------------
| Redirect by role
|--------------------------------------------------------------------------
*/
if ($row['role'] === 'Administrator') {
    header("Location: ../admin/dashboard.php");
    exit();
} elseif ($row['role'] === 'Records Personnel') {
    header("Location: ../records/dashboard.php");
    exit();
} else {
    header("Location: ../staff/dashboard.php");
    exit();
}
?>