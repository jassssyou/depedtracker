<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DepEd Talisay Document Tracking System</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            margin: 0;
            min-height: 100vh;
            background: #f5f7fb;
            color: #111827;
            display: flex;
            flex-direction: column;
        }

        .topbar {
            background: #ffffff;
            border-bottom: 1px solid #e5e7eb;
            padding: 15px 45px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .brand-logo {
            width: 65px;
            height: 65px;
            border: 0px;
            border-radius: 14px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .brand-logo img {
            width: 120%;
            height: auto;
        }

        .brand-text h1 {
            margin: 0;
            font-size: 23px;
            color: #0f172a;
        }

        .brand-text p {
            margin: 4px 0 0 0;
            font-size: 13px;
            color: #64748b;
            letter-spacing: 1px;
        }

        .staff-login {
            color: #1d4ed8;
            font-weight: bold;
            text-decoration: none;
            font-size: 16px;
        }

        .staff-login:hover {
            color: #1e40af;
        }

        .hero {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
            position: relative;
            background:
                linear-gradient(rgba(245,247,251,0.92), rgba(245,247,251,0.92)),
                url('assets/images/bg-pattern.png');
            background-size: cover;
            background-position: center;
        }

        .hero-content {
            width: 100%;
            max-width: 980px;
            text-align: center;
        }

        .hero-title {
            font-size: 50px;
            line-height: 1.05;
            font-weight: bold;
            color: #0f172a;
            margin: 0 0 18px 0;
        }

        .hero-subtitle {
            max-width: 760px;
            margin: 0 auto 36px auto;
            font-size: 18px;
            color: #475569;
            line-height: 1.6;
        }

        .track-box {
            max-width: 800px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 22px;
            box-shadow: 0 18px 35px rgba(15, 23, 42, 0.10);
            padding: 12px;
        }

        .track-form {
            display: grid;
            grid-template-columns: 1fr 220px;
            gap: 12px;
            align-items: center;
        }

        .track-input {
            width: 100%;
            border: 1px solid #e5e7eb;
            border-radius: 16px;
            padding: 20px 22px;
            font-size: 18px;
            outline: none;
            color: #111827;
            background: #ffffff;
        }

        .track-input::placeholder {
            color: #94a3b8;
        }

        .track-input:focus {
            border-color: #1d4ed8;
            box-shadow: 0 0 0 4px rgba(29, 78, 216, 0.10);
        }

        .track-btn {
            width: 100%;
            border: none;
            border-radius: 15px;
            background: #1d4ed8;
            color: #ffffff;
            font-size: 18px;
            font-weight: bold;
            padding: 20px 18px;
            cursor: pointer;
            transition: background 0.2s ease;
        }

        .track-btn:hover {
            background: #1e40af;
        }

        .helper-text {
            margin-top: 18px;
            color: #64748b;
            font-size: 14px;
        }

        .features {
            margin-top: 34px;
            display: flex;
            justify-content: center;
            gap: 28px;
            flex-wrap: wrap;
            color: #475569;
            font-size: 15px;
        }

        .footer {
            background: #0f172a;
            color: #cbd5e1;
            text-align: center;
            padding: 20px;
            font-size: 14px;
        }

        @media (max-width: 900px) {
            .hero-title {
                font-size: 46px;
            }

            .hero-subtitle {
                font-size: 18px;
            }

            .track-form {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 520px) {
            .topbar {
                padding: 16px 20px;
            }

            .hero-title {
                font-size: 36px;
            }

            .hero-subtitle {
                font-size: 16px;
            }

            .track-input {
                font-size: 18px;
                padding: 16px 18px;
            }

            .track-btn {
                padding: 16px 18px;
                font-size: 16px;
            }
        }
    </style>
</head>
<body>

<header class="topbar">
    <div class="brand">
        <div class="brand-logo">
            <!-- Replace with your real logo -->
            <img src="assets/images/logo.png" alt="DepEd Logo" onerror="this.style.display='none'; this.parentNode.innerHTML='<span style=&quot;color:#1d4ed8;font-weight:bold;font-size:18px;&quot;>DT</span>';">
        </div>
        <div class="brand-text">
            <h1>DepEd Talisay City</h1>
            <p>DOCUMENT TRACKING SYSTEM</p>
        </div>
    </div>

    <a href="auth/login.php" class="staff-login">Staff Login</a>
</header>

<section class="hero">
    <div class="hero-content">
        <h2 class="hero-title">Track Your Document</h2>
        <p class="hero-subtitle">
            Enter your reference number to view the real-time status and routing history of your submission.
        </p>

        <div class="track-box">
            <form action="public/track.php" method="GET" class="track-form">
                <input
                    type="text"
                    name="ref"
                    class="track-input"
                    placeholder="Enter Reference Number (e.g. DT-20260402-0001)"
                    required
                >
                <button type="submit" class="track-btn">Track Now</button>
            </form>
        </div>

        <div class="helper-text">
            Use the reference number from the confirmation email or scan the QR code provided to you.
        </div>

        <div class="features">
            <span>Real-time status</span>
            <span>Routing history</span>
            <span>Release notifications</span>
        </div>
    </div>
</section>

<footer class="footer">
    © <?php echo date('Y'); ?> Department of Education - Talisay City Division. All rights reserved.
</footer>

</body>
</html>