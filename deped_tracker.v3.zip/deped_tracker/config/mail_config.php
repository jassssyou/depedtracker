<?php

define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_USERNAME', 'bsis2d.bagahansol.jasmin@gmail.com');
define('MAIL_PASSWORD', 'qclh lagr hidp vywd'); 
define('MAIL_PORT', 587);

define('MAIL_FROM', 'bsis2d.bagahansol.jasmin@gmail.com');
define('MAIL_FROM_NAME', 'DepEd Talisay Tracker');